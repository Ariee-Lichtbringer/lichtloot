# LichtBuff Addon

Erster Prototyp fuer Worldbuff- und Hordenbuff-Termine aus LichtLoot.

## Installation

Kopiere den Ordner `LichtBuff` nach:

```text
World of Warcraft/_classic_era_/Interface/AddOns/LichtBuff
```

Falls WoW die Interface-Version als veraltet markiert, aktiviere im Addon-Fenster `Veraltete Addons laden`.

## Nutzung

Im Spiel:

```text
/lichtbuff
/lb
```

Importierte Termine werden lokal in den WoW SavedVariables gespeichert. Das Addon erinnert 30, 15, 5 und 1 Minute vor dem Termin.

Der Import akzeptiert entweder das LichtBuff-Zeilenformat oder eine einfache LichtLoot-JSON-Antwort mit `buffs`.

## Importformat

Eine Zeile pro Termin:

```text
LLB#Typ#Buff#Datum#Tag#Uhrzeit#Gilde#Charakter#Uebernehmer#Status#Notiz
```

Beispiele:

```text
LLB#Worldbuff#Hakkar#22.06.2026#Mo#19:30#Lichtbringer#Merlina##bestaetigt#
LLB#Worldbuff#Ony#22.06.2026#Mo#20:00#Lichtbringer###offen#
LLB#Hordenbuff#Rend#23.06.2026#Di#19:35#Horde#Allychar#Hordechar#offen#Summon bereit
```

`Typ` ist `Worldbuff` oder `Hordenbuff`. `Buff` ist `Hakkar`, `Ony`, `Nef` oder `Rend`.
