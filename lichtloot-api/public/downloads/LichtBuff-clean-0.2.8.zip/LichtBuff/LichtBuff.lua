local ADDON_NAME = ...

local DB_VERSION = 1
local IMPORT_PREFIX = "LLB"
local IMPORT_SEPARATOR = "#"
local REMINDER_MINUTES = { 30, 15, 10 }
local MAX_RENDERED_ROWS = 250

local BUFF_ICONS = {
  Hakkar = "Interface\\Icons\\Ability_Creature_Poison_05",
  Ony = "Interface\\Icons\\INV_Misc_Head_Dragon_01",
  Nef = "Interface\\Icons\\INV_Misc_Head_Dragon_Black",
  Rend = "Interface\\Icons\\Spell_Arcane_TeleportOrgrimmar",
}

local BUFF_COLORS = {
  Hakkar = "ff44dd55",
  Ony = "ffff5555",
  Nef = "ffff5555",
  Rend = "ffff6a45",
}

local WEEKDAYS = {
  "Sonntag",
  "Montag",
  "Dienstag",
  "Mittwoch",
  "Donnerstag",
  "Freitag",
  "Samstag",
}

local frame = CreateFrame("Frame", "LichtBuffFrame", UIParent, "BasicFrameTemplateWithInset")
frame:SetSize(940, 640)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:Hide()

frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
frame.title:SetPoint("LEFT", frame.TitleBg, "LEFT", 5, 0)
frame.title:SetText("LichtBuff")

local tabs = {}
local activeTab = "all"
local searchText = ""
local miniFrame
local renderMini
local minimapButton

local function ensureDb()
  if type(LichtBuffDB) ~= "table" then
    LichtBuffDB = {}
  end

  LichtBuffDB.version = DB_VERSION
  LichtBuffDB.events = LichtBuffDB.events or {}
  LichtBuffDB.reminders = LichtBuffDB.reminders or {}

  if LichtBuffDB.miniShown == nil then
    LichtBuffDB.miniShown = true
  end
end

local function printMessage(message)
  DEFAULT_CHAT_FRAME:AddMessage("|cff22c55eLichtBuff:|r " .. tostring(message or ""))
end

local function fillTexture(texture, r, g, b, a)
  if texture.SetColorTexture then
    texture:SetColorTexture(r, g, b, a)
  else
    texture:SetTexture(r, g, b, a)
  end
end

local function trim(value)
  return tostring(value or ""):match("^%s*(.-)%s*$")
end

local function split(value, separator)
  local parts = {}
  separator = separator or IMPORT_SEPARATOR

  for part in string.gmatch(tostring(value or "") .. separator, "(.-)" .. separator) do
    table.insert(parts, part)
  end

  return parts
end

local function normalizeBuff(value)
  local text = string.lower(trim(value))

  if text == "zg" or string.find(text, "hakkar", 1, true) then
    return "Hakkar"
  end

  if string.find(text, "ony", 1, true) then
    return "Ony"
  end

  if string.find(text, "nef", 1, true) then
    return "Nef"
  end

  if string.find(text, "rend", 1, true) then
    return "Rend"
  end

  return trim(value)
end

local function eventKind(kind, buff, guild)
  local lowerKind = string.lower(trim(kind))
  local lowerGuild = string.lower(trim(guild))
  local normalizedBuff = normalizeBuff(buff)

  if lowerKind == "hordenbuff" or lowerKind == "horde" then
    return "hordenbuff"
  end

  if normalizedBuff == "Rend" and (string.find(lowerGuild, "horde", 1, true) or string.find(lowerGuild, "horden", 1, true)) then
    return "hordenbuff"
  end

  return "worldbuff"
end

local function parseDateTime(dateText, timeText)
  local day, month, year = tostring(dateText or ""):match("^(%d%d?)%.(%d%d?)%.(%d%d%d%d)$")
  local hour, minute = tostring(timeText or ""):match("^(%d%d?)[:%.](%d%d)$")

  if not day or not hour then
    return nil
  end

  return time({
    year = tonumber(year),
    month = tonumber(month),
    day = tonumber(day),
    hour = tonumber(hour),
    min = tonumber(minute),
    sec = 0,
  })
end

local function formatRemaining(seconds)
  if not seconds then
    return "?"
  end

  if seconds <= 0 then
    return "jetzt"
  end

  local minutes = math.floor(seconds / 60)
  local hours = math.floor(minutes / 60)
  local days = math.floor(hours / 24)

  if days > 0 then
    return string.format("%dt %02dh", days, hours % 24)
  end

  if hours > 0 then
    return string.format("%dh %02dm", hours, minutes % 60)
  end

  return string.format("%dm", math.max(minutes, 0))
end

local function formatDateGroup(event)
  local timestamp = event and event.startsAt
  if not timestamp then
    return trim(event and event.date) ~= "" and trim(event.date) or "OHNE DATUM"
  end

  local value = date("*t", timestamp)
  return (WEEKDAYS[value.wday] or "") .. ", " .. date("%d.%m.%Y", timestamp)
end

local function colorText(text, color)
  return "|c" .. color .. tostring(text or "") .. "|r"
end

local function buffColor(buff)
  return BUFF_COLORS[normalizeBuff(buff)] or "fffacc15"
end

local function eventCaster(event)
  if event.kind == "hordenbuff" then
    if event.helper ~= "" then
      return event.helper
    end
    return event.character
  end

  return event.character
end

local function eventGuild(event)
  local guild = trim(event.guild)
  if guild == "" then
    return "-"
  end
  return guild
end

local function cleanSearch(value)
  return string.lower(tostring(value or ""))
end

local function eventMatchesSearch(event)
  if searchText == "" then
    return true
  end

  local haystack = table.concat({
    event.buff,
    event.date,
    event.tag,
    event.time,
    event.guild,
    event.character,
    event.helper,
    event.status,
    event.note,
  }, " ")

  return string.find(cleanSearch(haystack), searchText, 1, true) ~= nil
end

local function midnight(timestamp)
  local value = date("*t", timestamp or time())
  value.hour = 0
  value.min = 0
  value.sec = 0
  return time(value)
end

local function dayGroupLabel(event)
  return formatDateGroup(event)
end

local function statusLabel(event)
  local text = trim(event.status)
  local lower = string.lower(text)

  if text == "" then
    return "geplant"
  end

  if string.find(lower, "best", 1, true) then
    return "bestaetigt"
  end

  if string.find(lower, "offen", 1, true) then
    return "geplant"
  end

  return text
end

local function statusColor(event)
  return statusLabel(event) == "bestaetigt" and "ff7CFC00" or "ffffb000"
end

local function reminderMessage(event, minute)
  local guild = eventGuild(event)
  local caster = eventCaster(event)
  local casterText = caster ~= "" and (" | Werfer: " .. caster) or ""
  return string.format("In %d Minuten: %s - %s um %s%s", minute, guild, event.buff, event.time, casterText)
end

local function makeKey(kind, buff, dateText, timeText, guild, character, helper)
  return table.concat({
    trim(kind),
    normalizeBuff(buff),
    trim(dateText),
    trim(timeText),
    trim(guild),
    trim(character),
    trim(helper),
  }, "|")
end

local function normalizeEvent(raw)
  local event = {
    kind = eventKind(raw.kind, raw.buff, raw.guild),
    buff = normalizeBuff(raw.buff),
    date = trim(raw.date),
    tag = trim(raw.tag),
    time = trim(raw.time),
    guild = trim(raw.guild),
    character = trim(raw.character),
    helper = trim(raw.helper),
    status = trim(raw.status),
    note = trim(raw.note),
  }

  event.startsAt = parseDateTime(event.date, event.time)
  event.key = makeKey(event.kind, event.buff, event.date, event.time, event.guild, event.character, event.helper)
  return event
end

local function sortEvents()
  table.sort(LichtBuffDB.events, function(a, b)
    return (a.startsAt or 0) < (b.startsAt or 0)
  end)
end

local function clearRows()
  if not frame.rows then
    frame.rows = {}
    return
  end

  for _, row in ipairs(frame.rows) do
    row:Hide()
  end
end

local function visibleEvents()
  ensureDb()

  local now = time()
  local result = {}

  for _, event in ipairs(LichtBuffDB.events) do
    if event.startsAt and event.startsAt >= now - 1800 then
      if activeTab == "all" or event.kind == activeTab then
        if eventMatchesSearch(event) then
          table.insert(result, event)
        end
      end
    end
  end

  table.sort(result, function(a, b)
    return (a.startsAt or 0) < (b.startsAt or 0)
  end)

  return result
end

local function upcomingEvents(limit)
  ensureDb()

  local now = time()
  local result = {}

  for _, event in ipairs(LichtBuffDB.events) do
    if event.startsAt and event.startsAt >= now - 1800 then
      table.insert(result, event)
    end
  end

  table.sort(result, function(a, b)
    return (a.startsAt or 0) < (b.startsAt or 0)
  end)

  if limit and #result > limit then
    local limited = {}
    for index = 1, limit do
      table.insert(limited, result[index])
    end
    return limited
  end

  return result
end

local function todayEvents(limit)
  ensureDb()

  local now = time()
  local today = midnight(now)
  local tomorrow = today + 86400
  local result = {}

  for _, event in ipairs(LichtBuffDB.events) do
    if event.startsAt and event.startsAt >= now - 1800 and event.startsAt < tomorrow then
      table.insert(result, event)
    end
  end

  table.sort(result, function(a, b)
    return (a.startsAt or 0) < (b.startsAt or 0)
  end)

  if limit and #result > limit then
    local limited = {}
    for index = 1, limit do
      table.insert(limited, result[index])
    end
    return limited
  end

  return result
end

local function updateMinimapButtonPosition()
  if not minimapButton then
    return
  end

  ensureDb()
  local angle = LichtBuffDB.minimapAngle or 225
  local radius = 82
  local radians = math.rad(angle)
  local x = math.cos(radians) * radius
  local y = math.sin(radians) * radius

  minimapButton:ClearAllPoints()
  minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function updateMinimapButtonDragPosition()
  local centerX, centerY = Minimap:GetCenter()
  local cursorX, cursorY = GetCursorPosition()
  local scale = Minimap:GetEffectiveScale()

  cursorX = cursorX / scale
  cursorY = cursorY / scale

  local angleRadians
  if math.atan2 then
    angleRadians = math.atan2(cursorY - centerY, cursorX - centerX)
  else
    angleRadians = math.atan(cursorY - centerY, cursorX - centerX)
  end

  local angle = math.deg(angleRadians)
  if angle < 0 then
    angle = angle + 360
  end

  ensureDb()
  LichtBuffDB.minimapAngle = angle
  updateMinimapButtonPosition()
end

local function render()
  clearRows()

  local events = visibleEvents()
  local nextEvent = events[1]

  if nextEvent then
    frame.nextBox:Show()
    frame.nextIcon:SetTexture(BUFF_ICONS[nextEvent.buff] or "Interface\\Icons\\INV_Misc_QuestionMark")
    frame.nextLabel:SetText("NAECHSTER BUFF")
    frame.nextBuff:SetText(colorText(nextEvent.buff, buffColor(nextEvent.buff)))
    frame.nextTime:SetText(formatDateGroup(nextEvent) .. " " .. nextEvent.time)
    frame.nextCountdown:SetText(colorText(formatRemaining(nextEvent.startsAt - time()), "fffacc15"))
    frame.nextGuild:SetText(eventGuild(nextEvent))
    frame.nextCaster:SetText("Werfer: " .. (eventCaster(nextEvent) ~= "" and eventCaster(nextEvent) or "-"))
  else
    frame.nextBox:Hide()
  end

  frame.emptyText:SetShown(#events == 0)
  frame.emptyText:SetText(activeTab == "all" and "Keine kommenden Buff-Termine importiert." or "Keine passenden Buff-Termine importiert.")

  local y = 0
  local lastGroup = nil
  local shown = 0

  for index, event in ipairs(events) do
    if shown >= MAX_RENDERED_ROWS then
      break
    end

    local group = dayGroupLabel(event)

    if group ~= lastGroup then
      shown = shown + 1
      local row = frame.rows[shown]

      if row and row.kind ~= "group" then
        row:Hide()
        row = nil
      end

      if not row then
        row = CreateFrame("Frame", nil, frame.content)
        row.kind = "group"
        row:SetSize(850, 24)
        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        row.text:SetPoint("LEFT", 0, 0)
        frame.rows[shown] = row
      end

      row:SetPoint("TOPLEFT", frame.content, "TOPLEFT", 0, -y)
      row.text:SetText(colorText("v " .. group, "fffacc15"))
      row:Show()
      y = y + 28
      lastGroup = group
    end

    if shown >= MAX_RENDERED_ROWS then
      break
    end

    shown = shown + 1

    local row = frame.rows[shown]

    if row and row.kind ~= "event" then
      row:Hide()
      row = nil
    end

    if not row then
      row = CreateFrame("Frame", nil, frame.content)
      row.kind = "event"
      row:SetSize(850, 46)
      row.bg = row:CreateTexture(nil, "BACKGROUND")
      row.bg:SetAllPoints()
      fillTexture(row.bg, 0, 0, 0, 0.24)
      row.icon = row:CreateTexture(nil, "ARTWORK")
      row.icon:SetSize(34, 34)
      row.icon:SetPoint("LEFT", 10, 0)
      row.buff = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
      row.buff:SetPoint("LEFT", 56, 7)
      row.date = row:CreateFontString(nil, "OVERLAY", "GameFontDisable")
      row.date:SetPoint("LEFT", 205, 7)
      row.time = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
      row.time:SetPoint("LEFT", 320, 7)
      row.guild = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
      row.guild:SetPoint("LEFT", 405, 7)
      row.caster = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
      row.caster:SetPoint("LEFT", 560, 7)
      row.status = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
      row.status:SetPoint("LEFT", 705, 7)
      row.remaining = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
      row.remaining:SetPoint("LEFT", 705, -11)
      row.note = row:CreateFontString(nil, "OVERLAY", "GameFontDisable")
      row.note:SetPoint("LEFT", 560, -11)
      frame.rows[shown] = row
    end

    row:SetPoint("TOPLEFT", frame.content, "TOPLEFT", 0, -y)
    row.icon:SetTexture(BUFF_ICONS[event.buff] or "Interface\\Icons\\INV_Misc_QuestionMark")
    row.buff:SetText(colorText(event.buff, buffColor(event.buff)))
    row.date:SetText(event.date)
    row.time:SetText(event.time)
    row.guild:SetText(colorText(eventGuild(event), "ffffffff"))
    row.caster:SetText(colorText(eventCaster(event) ~= "" and eventCaster(event) or "-", "fffacc15"))
    row.status:SetText(colorText(statusLabel(event), statusColor(event)))
    row.remaining:SetText(formatRemaining(event.startsAt - time()))
    row.note:SetText(event.note ~= "" and event.note or "")
    row:Show()
    y = y + 50
  end

  frame.content:SetHeight(math.max(y + 12, 390))

  if #events > shown then
    frame.countText:SetText("Zeige " .. shown .. " von " .. #events .. " Terminen.")
  else
    frame.countText:SetText(#events .. " Termine angezeigt.")
  end

  if renderMini then
    renderMini()
  end
end

local function setTab(tab)
  activeTab = tab

  for name, button in pairs(tabs) do
    if name == tab then
      button:Disable()
    else
      button:Enable()
    end
  end

  render()
end

local function parseImportLine(line)
  line = trim(line)

  if line == "" then
    return nil
  end

  local separator = string.find(line, IMPORT_SEPARATOR, 1, true) and IMPORT_SEPARATOR or "|"
  local parts = split(line, separator)

  if parts[1] ~= IMPORT_PREFIX then
    return nil, "Zeile ignoriert, weil sie nicht mit LLB beginnt: " .. line
  end

  local raw = {
    kind = parts[2],
    buff = parts[3],
    date = parts[4],
    tag = parts[5],
    time = parts[6],
    guild = parts[7],
    character = parts[8],
    helper = parts[9],
    status = parts[10],
    note = parts[11],
  }

  if trim(raw.buff) == "" or trim(raw.date) == "" or trim(raw.time) == "" then
    return nil, "Zeile unvollstaendig: " .. line
  end

  local event = normalizeEvent(raw)

  if not event.startsAt then
    return nil, "Datum/Uhrzeit nicht lesbar: " .. line
  end

  return event
end

local function jsonValue(objectText, key)
  return objectText:match('"' .. key .. '"%s*:%s*"([^"]*)"') or ""
end

local function parseJsonLikeEvents(text)
  local events = {}

  for objectText in tostring(text or ""):gmatch("{(.-)}") do
    local buff = jsonValue(objectText, "buff")
    local dateText = jsonValue(objectText, "datum")
    local timeText = jsonValue(objectText, "uhrzeit")

    if buff ~= "" and dateText ~= "" and timeText ~= "" then
      local raw = {
        kind = jsonValue(objectText, "kind"),
        buff = buff,
        date = dateText,
        tag = jsonValue(objectText, "tag"),
        time = timeText,
        guild = jsonValue(objectText, "gilde"),
        character = jsonValue(objectText, "charakter"),
        helper = jsonValue(objectText, "uebernehmer"),
        status = jsonValue(objectText, "status"),
        note = jsonValue(objectText, "note"),
      }

      if raw.note == "" then
        raw.note = jsonValue(objectText, "notiz")
      end

      table.insert(events, normalizeEvent(raw))
    end
  end

  return events
end

local function importText(text)
  ensureDb()

  local byKey = {}
  local imported = 0
  local warnings = {}

  for _, event in ipairs(LichtBuffDB.events) do
    byKey[event.key] = event
  end

  for line in string.gmatch(tostring(text or "") .. "\n", "([^\n]*)\n") do
    local event, warning = parseImportLine(line)

    if event then
      byKey[event.key] = event
      imported = imported + 1
    elseif warning then
      table.insert(warnings, warning)
    end
  end

  if imported == 0 then
    local jsonImported = 0

    for _, event in ipairs(parseJsonLikeEvents(text)) do
      if event.startsAt then
        byKey[event.key] = event
        imported = imported + 1
        jsonImported = jsonImported + 1
      end
    end

    if jsonImported > 0 then
      warnings = {}
    end
  end

  LichtBuffDB.events = {}

  for _, event in pairs(byKey) do
    table.insert(LichtBuffDB.events, event)
  end

  searchText = ""
  if frame.searchBox then
    frame.searchBox:SetText("")
  end
  if frame.searchLabel then
    frame.searchLabel:Show()
  end

  sortEvents()
  render()

  printMessage(imported .. " Buff-Termine importiert.")

  for index = 1, math.min(#warnings, 3) do
    printMessage(warnings[index])
  end
end

local function clearImported()
  ensureDb()
  LichtBuffDB.events = {}
  LichtBuffDB.reminders = {}
  render()
  printMessage("Importierte Buff-Termine geloescht.")
end

local function toggleWindow()
  if frame:IsShown() then
    frame:Hide()
  else
    frame:Show()
    render()
  end
end

local function createButton(parent, text, width, x, y, onClick)
  local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  button:SetSize(width, 24)
  button:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
  button:SetText(text)
  button:SetScript("OnClick", onClick)
  return button
end

frame.TitleBg:SetHeight(42)
frame.title:ClearAllPoints()
frame.title:SetPoint("LEFT", frame.TitleBg, "LEFT", 18, 0)
frame.title:SetFont(STANDARD_TEXT_FONT, 24, "OUTLINE")
frame.title:SetTextColor(1, .82, 0)

frame.backdrop = frame:CreateTexture(nil, "BACKGROUND")
frame.backdrop:SetPoint("TOPLEFT", 8, -28)
frame.backdrop:SetPoint("BOTTOMRIGHT", -8, 8)
fillTexture(frame.backdrop, 0.015, 0.012, 0.01, 0.92)

tabs.all = createButton(frame, "Alle", 130, 28, -58, function() setTab("all") end)
tabs.worldbuff = createButton(frame, "Worldbuffs", 150, 168, -58, function() setTab("worldbuff") end)
tabs.hordenbuff = createButton(frame, "Hordenbuffs", 150, 328, -58, function() setTab("hordenbuff") end)

frame.searchBox = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
frame.searchBox:SetSize(250, 28)
frame.searchBox:SetPoint("TOPLEFT", frame, "TOPLEFT", 496, -59)
frame.searchBox:SetAutoFocus(false)
frame.searchBox:SetText("")
frame.searchBox:SetScript("OnTextChanged", function(self)
  searchText = cleanSearch(self:GetText())
  render()
end)

frame.searchLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontDisable")
frame.searchLabel:SetPoint("LEFT", frame.searchBox, "LEFT", 8, 0)
frame.searchLabel:SetText("Filter oder Name...")
frame.searchBox:SetScript("OnEditFocusGained", function()
  frame.searchLabel:Hide()
end)
frame.searchBox:SetScript("OnEditFocusLost", function(self)
  frame.searchLabel:SetShown(self:GetText() == "")
end)

createButton(frame, "X", 32, 750, -58, function()
  frame.searchBox:SetText("")
  searchText = ""
  frame.searchLabel:Show()
  render()
end)

frame.importPanel = CreateFrame("Frame", nil, frame)
frame.importPanel:SetSize(760, 72)
frame.importPanel:SetPoint("TOPLEFT", frame, "TOPLEFT", 28, -94)
frame.importPanel:Hide()

frame.importBox = CreateFrame("EditBox", nil, frame.importPanel, "InputBoxTemplate")
frame.importBox:SetSize(600, 52)
frame.importBox:SetPoint("TOPLEFT", frame.importPanel, "TOPLEFT", 0, -8)
frame.importBox:SetAutoFocus(false)
frame.importBox:SetMultiLine(true)
frame.importBox:SetText("")

createButton(frame, "Import", 82, 790, -58, function()
  frame.importPanel:SetShown(not frame.importPanel:IsShown())
end)

createButton(frame, "Mini", 58, 876, -58, function()
  ensureDb()
  LichtBuffDB.miniShown = not LichtBuffDB.miniShown
  if LichtBuffDB.miniShown then
    miniFrame:Show()
  else
    miniFrame:Hide()
  end
  renderMini()
end)

frame.importTitle = frame.importPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
frame.importTitle:SetPoint("TOPLEFT", frame.importPanel, "TOPLEFT", 2, 12)
frame.importTitle:SetText("Export aus LichtLoot hier einfuegen")

createButton(frame.importPanel, "Importieren", 120, 620, -8, function()
  importText(frame.importBox:GetText())
  frame.importBox:SetText("")
  frame.importPanel:Hide()
end)

createButton(frame.importPanel, "Liste leeren", 120, 620, -38, clearImported)

frame.help = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.help:SetPoint("TOPLEFT", frame.importPanel, "TOPLEFT", 2, -62)
frame.help:SetJustifyH("LEFT")
frame.help:SetText("Import: LLB#Worldbuff#Hakkar#22.06.2026#Mo#19:30#Lichtbringer#Charakter###Notiz")

frame.nextBox = CreateFrame("Frame", nil, frame)
frame.nextBox:SetSize(860, 84)
frame.nextBox:SetPoint("TOPLEFT", frame, "TOPLEFT", 32, -104)
frame.nextBg = frame.nextBox:CreateTexture(nil, "BACKGROUND")
frame.nextBg:SetAllPoints()
fillTexture(frame.nextBg, .12, .025, .01, .82)
frame.nextBorder = frame.nextBox:CreateTexture(nil, "BORDER")
frame.nextBorder:SetPoint("TOPLEFT", -2, 2)
frame.nextBorder:SetPoint("BOTTOMRIGHT", 2, -2)
fillTexture(frame.nextBorder, .95, .68, .16, .20)
frame.nextIcon = frame.nextBox:CreateTexture(nil, "ARTWORK")
frame.nextIcon:SetSize(50, 50)
frame.nextIcon:SetPoint("LEFT", 22, 0)
frame.nextLabel = frame.nextBox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
frame.nextLabel:SetPoint("TOPLEFT", 92, -14)
frame.nextLabel:SetTextColor(1, .82, 0)
frame.nextBuff = frame.nextBox:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
frame.nextBuff:SetPoint("LEFT", 92, -7)
frame.nextTime = frame.nextBox:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
frame.nextTime:SetPoint("LEFT", 240, -6)
frame.nextCountdown = frame.nextBox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
frame.nextCountdown:SetPoint("LEFT", 505, -6)
frame.nextGuild = frame.nextBox:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
frame.nextGuild:SetPoint("LEFT", 650, 8)
frame.nextGuild:SetTextColor(1, 1, 1)
frame.nextCaster = frame.nextBox:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
frame.nextCaster:SetPoint("LEFT", 650, -14)

frame.header = CreateFrame("Frame", nil, frame)
frame.header:SetSize(850, 20)
frame.header:SetPoint("TOPLEFT", frame, "TOPLEFT", 42, -194)
frame.headerBuff = frame.header:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.headerBuff:SetPoint("LEFT", 56, 0)
frame.headerBuff:SetText("BUFF")
frame.headerDate = frame.header:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.headerDate:SetPoint("LEFT", 205, 0)
frame.headerDate:SetText("DATUM")
frame.headerTime = frame.header:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.headerTime:SetPoint("LEFT", 320, 0)
frame.headerTime:SetText("ZEIT")
frame.headerGuild = frame.header:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.headerGuild:SetPoint("LEFT", 405, 0)
frame.headerGuild:SetText("GILDE")
frame.headerCaster = frame.header:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.headerCaster:SetPoint("LEFT", 560, 0)
frame.headerCaster:SetText("WERFER")
frame.headerStatus = frame.header:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.headerStatus:SetPoint("LEFT", 705, 0)
frame.headerStatus:SetText("STATUS")

frame.scrollFrame = CreateFrame("ScrollFrame", "LichtBuffScrollFrame", frame, "UIPanelScrollFrameTemplate")
frame.scrollFrame:SetSize(858, 432)
frame.scrollFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 42, -214)

frame.content = CreateFrame("Frame", nil, frame.scrollFrame)
frame.content:SetSize(838, 408)
frame.scrollFrame:SetScrollChild(frame.content)
frame.scrollFrame:EnableMouseWheel(true)
frame.scrollFrame:SetScript("OnMouseWheel", function(self, delta)
  local current = self:GetVerticalScroll()
  local maxScroll = self:GetVerticalScrollRange()
  local nextScroll = current - (delta * 42)
  if nextScroll < 0 then nextScroll = 0 end
  if nextScroll > maxScroll then nextScroll = maxScroll end
  self:SetVerticalScroll(nextScroll)
end)

frame.emptyText = frame.content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
frame.emptyText:SetPoint("TOPLEFT", frame.content, "TOPLEFT", 8, -8)
frame.emptyText:SetText("Keine kommenden Buff-Termine importiert.")

frame.countText = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.countText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 32, 18)
frame.countText:SetText("0 kommende Termine.")

frame.lastUpdateText = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.lastUpdateText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 260, 18)
frame.lastUpdateText:SetText("Letztes Update: Import")

miniFrame = CreateFrame("Frame", "LichtBuffMiniFrame", UIParent)
miniFrame:SetSize(260, 148)
miniFrame:SetPoint("CENTER", UIParent, "CENTER", 360, 140)
miniFrame:Hide()
miniFrame:SetMovable(true)
miniFrame:EnableMouse(true)
miniFrame:RegisterForDrag("LeftButton")
miniFrame:SetScript("OnDragStart", miniFrame.StartMoving)
miniFrame:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  ensureDb()
  local point, _, relativePoint, x, y = self:GetPoint()
  LichtBuffDB.miniPosition = {
    point = point,
    relativePoint = relativePoint,
    x = x,
    y = y,
  }
end)

miniFrame.bg = miniFrame:CreateTexture(nil, "BACKGROUND")
miniFrame.bg:SetAllPoints()
fillTexture(miniFrame.bg, 0, 0, 0, 0.46)

miniFrame.border = miniFrame:CreateTexture(nil, "BORDER")
miniFrame.border:SetPoint("TOPLEFT", -1, 1)
miniFrame.border:SetPoint("BOTTOMRIGHT", 1, -1)
fillTexture(miniFrame.border, .95, .68, .16, .18)

miniFrame.title = miniFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
miniFrame.title:SetPoint("TOPLEFT", 8, -7)
miniFrame.title:SetText("LichtBuff")
miniFrame.title:SetTextColor(1, .82, 0)

miniFrame.close = CreateFrame("Button", nil, miniFrame, "UIPanelCloseButton")
miniFrame.close:SetSize(22, 22)
miniFrame.close:SetPoint("TOPRIGHT", 3, 4)
miniFrame.close:SetScript("OnClick", function()
  ensureDb()
  LichtBuffDB.miniShown = false
  miniFrame:Hide()
end)

miniFrame.rows = {}
for index = 1, 4 do
  local row = CreateFrame("Frame", nil, miniFrame)
  row:SetSize(244, 25)
  row:SetPoint("TOPLEFT", miniFrame, "TOPLEFT", 8, -28 - ((index - 1) * 27))
  row.icon = row:CreateTexture(nil, "ARTWORK")
  row.icon:SetSize(18, 18)
  row.icon:SetPoint("LEFT", 0, 0)
  row.buff = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  row.buff:SetPoint("LEFT", 24, 5)
  row.time = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  row.time:SetPoint("LEFT", 82, 5)
  row.guild = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  row.guild:SetPoint("LEFT", 24, -8)
  row.remaining = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  row.remaining:SetPoint("RIGHT", -2, 5)
  miniFrame.rows[index] = row
end

miniFrame.empty = miniFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
miniFrame.empty:SetPoint("TOPLEFT", 10, -34)
miniFrame.empty:SetText("Heute keine Termine.")

renderMini = function()
  if not miniFrame then
    return
  end

  ensureDb()
  local events = todayEvents(4)
  miniFrame.empty:SetShown(#events == 0)

  for index, row in ipairs(miniFrame.rows) do
    local event = events[index]

    if event then
      row.icon:SetTexture(BUFF_ICONS[event.buff] or "Interface\\Icons\\INV_Misc_QuestionMark")
      row.buff:SetText(colorText(event.buff, buffColor(event.buff)))
      row.time:SetText(event.time)
      row.guild:SetText(eventGuild(event))
      row.remaining:SetText(colorText(formatRemaining(event.startsAt - time()), "fffacc15"))
      row:Show()
    else
      row:Hide()
    end
  end
end

minimapButton = CreateFrame("Button", "LichtBuffMinimapButton", Minimap)
minimapButton:SetSize(31, 31)
minimapButton:SetFrameStrata("LOW")
minimapButton:SetFrameLevel(8)
minimapButton:EnableMouse(true)
minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
minimapButton:RegisterForDrag("LeftButton")

minimapButton.background = minimapButton:CreateTexture(nil, "BACKGROUND")
minimapButton.background:SetSize(20, 20)
minimapButton.background:SetPoint("TOPLEFT", 7, -5)
minimapButton.background:SetTexture("Interface\\Minimap\\UI-Minimap-Background")

minimapButton.icon = minimapButton:CreateTexture(nil, "ARTWORK")
minimapButton.icon:SetSize(20, 20)
minimapButton.icon:SetPoint("TOPLEFT", 7, -5)
minimapButton.icon:SetTexture("Interface\\Icons\\Spell_Holy_InnerFire")
if minimapButton.icon.SetMask then
  minimapButton.icon:SetMask("Interface\\CharacterFrame\\TempPortraitAlphaMask")
end

minimapButton.border = minimapButton:CreateTexture(nil, "OVERLAY")
minimapButton.border:SetSize(54, 54)
minimapButton.border:SetPoint("TOPLEFT", 0, 0)
minimapButton.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

minimapButton:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

minimapButton:SetScript("OnClick", function(_, button)
  if button == "RightButton" then
    ensureDb()
    LichtBuffDB.miniShown = not LichtBuffDB.miniShown
    if LichtBuffDB.miniShown then
      miniFrame:Show()
      renderMini()
    else
      miniFrame:Hide()
    end
    return
  end

  toggleWindow()
end)

minimapButton:SetScript("OnDragStart", function(self)
  self:SetScript("OnUpdate", updateMinimapButtonDragPosition)
end)
minimapButton:SetScript("OnDragStop", function(self)
  self:SetScript("OnUpdate", nil)
  updateMinimapButtonDragPosition()
end)

minimapButton:SetScript("OnEnter", function(self)
  GameTooltip:SetOwner(self, "ANCHOR_LEFT")
  GameTooltip:SetText("LichtBuff")
  GameTooltip:AddLine("Linksklick: Fenster oeffnen", 1, 1, 1)
  GameTooltip:AddLine("Rechtsklick: Mini-Fenster", 1, 1, 1)
  GameTooltip:Show()
end)

minimapButton:SetScript("OnLeave", function()
  GameTooltip:Hide()
end)

local ticker = CreateFrame("Frame")
ticker.elapsed = 0
ticker:SetScript("OnUpdate", function(_, elapsed)
  ticker.elapsed = ticker.elapsed + elapsed

  if ticker.elapsed < 15 then
    return
  end

  ticker.elapsed = 0
  ensureDb()

  local now = time()

  for _, event in ipairs(LichtBuffDB.events) do
    if event.startsAt and event.startsAt >= now then
      for _, minute in ipairs(REMINDER_MINUTES) do
        local delta = event.startsAt - now
        local reminderKey = event.key .. "|" .. tostring(minute)

        if delta <= minute * 60 and delta > (minute * 60 - 20) and not LichtBuffDB.reminders[reminderKey] then
          LichtBuffDB.reminders[reminderKey] = true
          local message = reminderMessage(event, minute)
          RaidNotice_AddMessage(RaidWarningFrame, message, ChatTypeInfo["RAID_WARNING"])
          printMessage(message)

          if UnitName("player") then
            SendChatMessage(message, "WHISPER", nil, UnitName("player"))
          end

          if IsInGuild() then
            SendChatMessage("[LichtBuff] " .. message, "GUILD")
          end
        end
      end
    end
  end

  if frame:IsShown() then
    render()
  elseif renderMini then
    renderMini()
  end
end)

SLASH_LICHTBUFF1 = "/lichtbuff"
SLASH_LICHTBUFF2 = "/lb"
SlashCmdList.LICHTBUFF = function(message)
  message = string.lower(trim(message))

  if message == "clear" or message == "loeschen" then
    clearImported()
    return
  end

  if message == "mini" then
    ensureDb()
    LichtBuffDB.miniShown = not LichtBuffDB.miniShown
    if LichtBuffDB.miniShown then
      miniFrame:Show()
      renderMini()
    else
      miniFrame:Hide()
    end
    return
  end

  toggleWindow()
end

frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function(_, event, addonName)
  if event == "ADDON_LOADED" and addonName == ADDON_NAME then
    ensureDb()
    sortEvents()

    if LichtBuffDB.miniPosition then
      miniFrame:ClearAllPoints()
      miniFrame:SetPoint(
        LichtBuffDB.miniPosition.point or "CENTER",
        UIParent,
        LichtBuffDB.miniPosition.relativePoint or "CENTER",
        LichtBuffDB.miniPosition.x or 360,
        LichtBuffDB.miniPosition.y or 140
      )
    end

    updateMinimapButtonPosition()

    if LichtBuffDB.miniShown then
      miniFrame:Show()
    else
      miniFrame:Hide()
    end

    renderMini()
    setTab("all")
    printMessage("geladen. Oeffne das Fenster mit /lichtbuff oder /lb. Mini-Fenster: /lb mini.")
  end
end)
