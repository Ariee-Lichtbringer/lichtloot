local _,GL=...
GL.prefix="GuildLootEra2"
local function identity(s) return tostring(s or ""):gsub("%s",""):lower() end
function GL.FullName(unit)
    local name,realm=UnitFullName(unit)
    return name and (name.."-"..((realm and realm~="") and realm or GetRealmName())) or nil
end
function GL.RaidMember(name)
    if type(name)~="string" or name=="" then return nil end
    if not name:find("-",1,true) then name=name.."-"..GetRealmName() end
    for i=1,GetNumGroupMembers() do
        local full=GL.FullName("raid"..i)
        if full and identity(full)==identity(name) then return full end
    end
end
-- Match Blizzard's localized loot format strings, including numbered placeholders.
-- Ignore created/pushed/trade messages: only the four ordinary loot formats count.
local function formatPattern(format)
    local parts,order={},{};local i,auto=1,0
    while i<=#format do
        local tail=format:sub(i)
        local token,index,kind=tail:match("^(%%(%d+)%$([sd]))")
        if not token then token,kind=tail:match("^(%%([sd]))");if token then auto=auto+1;index=auto end end
        if token then parts[#parts+1]=kind=="d" and "(%d+)" or "(.-)";order[#order+1]=tonumber(index);i=i+#token
        elseif tail:sub(1,2)=="%%" then parts[#parts+1]="%%";i=i+2
        else local c=format:sub(i,i);parts[#parts+1]=(c:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])","%%%1"));i=i+1 end
    end
    return "^"..table.concat(parts).."$",order
end
function GL.ParseLootMessage(text)
    if type(text)~="string" or #text>3000 then return nil end
    local variants={{"LOOT_ITEM_SELF_MULTIPLE",true,true},{"LOOT_ITEM_SELF",true,false},{"LOOT_ITEM_MULTIPLE",false,true},{"LOOT_ITEM",false,false}}
    for _,v in ipairs(variants) do
        local fmt=_G[v[1]]
        if fmt then
            local pattern,order=formatPattern(fmt);local matches={text:match(pattern)}
            if #matches>0 then
                local args={};for n,val in ipairs(matches) do args[order[n]]=val end
                local player=v[2] and GL.FullName("player") or args[1]
                -- Some locales put a player hyperlink in the recipient placeholder.
                player=player and (player:match("|Hplayer:([^:|]+)") or player)
                local link=args[v[2] and 1 or 2]
                local id=link and tonumber(link:match("|Hitem:(%d+)"))
                local quantity=v[3] and tonumber(args[v[2] and 2 or 3]) or 1
                if id and id>0 and id<=1000000 and quantity and quantity>=1 and quantity<=10000 and quantity==math.floor(quantity) then
                    return {recipient=player,itemId=id,itemName=link:match("%[(.-)%]") or tostring(id),quantity=quantity}
                end
            end
        end
    end
end
function GL.RecordLootMessage(text,lineId)
    local r=GL.Active();if not r or not GL.InInstance(r) then return end
    local e=GL.ParseLootMessage(text);if not e then return end
    local member=GL.RaidMember(e.recipient);if not member then return end
    GL.chatLines=GL.chatLines or {}
    if type(lineId)=="number" and lineId>0 then
        if GL.chatLines[lineId] then return end
        GL.chatLines[lineId]=true
    end
    r.receipts=r.receipts or {};r.receiptSequence=(r.receiptSequence or 0)+1
    if #r.receipts>=5000 then r.captureWarning=true;return end
    e.id=r.sessionId..":receipt:"..r.receiptSequence;e.recipient=member;e.observedAt=GetServerTime()
    -- Loot chat has no source GUID. Never invent a boss or add another boss drop.
    r.receipts[#r.receipts+1]=e
end
local function encode(s) return (tostring(s):gsub("([^A-Za-z0-9%-%._])",function(c) return string.format("%%%02X",c:byte()) end)) end
local function fields(text)
    local out={}
    for s in (text.."\t"):gmatch("(.-)\t") do
        if s:gsub("%%[%x][%x]",""):find("%%") then return nil end
        out[#out+1]=s:gsub("%%(%x%x)",function(h) return string.char(tonumber(h,16)) end)
    end
    return out
end
local function validText(s,max) return type(s)=="string" and #s>0 and #s<=max and not s:find("[%z\1-\31]") end
local function number(s,min,max) local n=tonumber(s);return n and n==math.floor(n) and n>=min and n<=max and n end
GL.outbox={};GL.pending={};GL.inbox={};GL.requestTimes={};GL.wireSequence=0;GL.wireNonce=math.random(1,999999)
function GL.QueueWire(r,values,key)
    if not C_ChatInfo or not C_ChatInfo.SendAddonMessage then return end
    local encoded={};for i,v in ipairs(values) do encoded[i]=encode(v) end
    local payload=table.concat(encoded,"\t")
    if #payload>3000 then r.syncWarning=true;return end
    key=r.sessionId..":"..key
    if GL.pending[key]==payload then return end
    local total=math.ceil(#payload/200)
    if #GL.outbox+total>3000 then r.syncWarning=true;return end
    GL.pending[key]=payload
    GL.wireSequence=GL.wireSequence+1
    local wireId=GetServerTime().."-"..GL.wireNonce.."-"..GL.wireSequence
    for part=1,total do
        GL.outbox[#GL.outbox+1]={r=r,key=key,payload=payload,last=part==total,
            text=table.concat({"2",wireId,part,total,payload:sub((part-1)*200+1,part*200)},"\t"),attempts=0}
    end
end
function GL.ShareDrop(r,d)
    GL.QueueWire(r,{"DROP",r.guild,r.raidId,r.instanceId,d.sourceGuid,d.itemId,d.itemName,d.quantity,d.sourceName,d.sourceEvidence},d.id)
end
function GL.RequestSync()
    local r=GL.Active();if not r or not GL.InInstance(r) then return end
    local now=GetServerTime();if GL.lastRequest and now-GL.lastRequest<10 then return end
    GL.lastRequest=now;GL.QueueWire(r,{"REQUEST",r.guild,r.raidId,r.instanceId},"request")
end
function GL.CaptureStarted()
    GL.chatLines={};GL.inbox={};GL.lastRequest=nil;GL.RequestSync()
end
function GL.ApplyWire(payload,sender)
    local r=GL.Active();if not r or not GL.InInstance(r) then return end
    local v=fields(payload)
    if not v or v[2]~=r.guild or v[3]~=r.raidId or tonumber(v[4])~=r.instanceId then return end
    if v[1]=="REQUEST" and #v==4 then
        local now=GetServerTime()
        if GL.lastReplay and now-GL.lastReplay<10 then return end
        GL.lastReplay=now
        for _,d in pairs(r.localDrops or {}) do GL.ShareDrop(r,d) end
        return
    end
    if v[1]~="DROP" or #v~=10 then return end
    local guid,id,quantity=v[5],number(v[6],1,1000000),number(v[8],1,10000)
    if not validText(guid,100) or not (guid:match("^Creature%-[%x%-]+$") or guid:match("^GameObject%-[%x%-]+$")) or not id or not quantity then return end
    if not validText(v[7],250) or not validText(v[9],160) or not ({observed=true,manual=true,unknown=true})[v[10]] then return end
    local key=guid..":"..id;local found
    for _,d in ipairs(r.drops) do if d.id==key then found=d;break end end
    if not found then
        if #r.drops>=5000 then r.captureWarning=true;return end
        found={id=key,sourceGuid=guid,itemId=id,itemName=v[7],quantity=quantity,sourceName=v[9],sourceEvidence=v[10],observedAt=GetServerTime(),capture="shared",reportedBy=sender}
        r.drops[#r.drops+1]=found
    else
        found.quantity=math.max(found.quantity,quantity)
        if found.capture=="shared" and (found.sourceEvidence=="unknown" or found.reportedBy==sender) then
            found.sourceName=v[9];found.sourceEvidence=v[10];found.reportedBy=sender
        end
    end
    r.sharedMessages=(r.sharedMessages or 0)+1
end
function GL.ReceiveAddon(prefix,text,channel,sender)
    if prefix~=GL.prefix or channel~="RAID" or type(text)~="string" or #text>255 then return end
    local r=GL.Active();if not r or not GL.InInstance(r) then return end
    local member=GL.RaidMember(sender)
    if not member or identity(member)==identity(GL.FullName("player")) then return end
    local wireId,part,total,chunk=text:match("^2\t([%d%-]+)\t(%d+)\t(%d+)\t(.*)$")
    part=number(part,1,15);total=number(total,1,15)
    if not wireId or #wireId>40 or not part or not total or part>total or #chunk>200 then return end
    local now=GetServerTime();local pending=0
    for key,b in pairs(GL.inbox) do if now-b.at>30 then GL.inbox[key]=nil else pending=pending+1 end end
    local key=identity(member)..":"..wireId;local b=GL.inbox[key]
    if not b then if pending>=80 then return end;b={at=now,total=total,parts={},count=0};GL.inbox[key]=b end
    if b.total~=total then GL.inbox[key]=nil;return end
    if b.parts[part] and b.parts[part]~=chunk then GL.inbox[key]=nil;return end
    if not b.parts[part] then b.parts[part]=chunk;b.count=b.count+1 end
    if b.count==total then GL.inbox[key]=nil;GL.ApplyWire(table.concat(b.parts),member) end
end
function GL.PumpSync()
    local entry=GL.outbox[1];if not entry then return end
    if not GL.InInstance(entry.r) then GL.outbox={};GL.pending={};entry.r.syncWarning=true;return end
    local ok,result=pcall(C_ChatInfo.SendAddonMessage,GL.prefix,entry.text,"RAID")
    local success=ok and (result==nil or result==true or result==0 or (Enum and Enum.SendAddonMessageResult and result==Enum.SendAddonMessageResult.Success))
    entry.attempts=entry.attempts+1
    if success or entry.attempts>=10 then
        if not success then entry.r.syncWarning=true end
        table.remove(GL.outbox,1)
        if entry.last and GL.pending[entry.key]==entry.payload then GL.pending[entry.key]=nil end
    end
end
function GL.CaptureStatus()
    local r=GL.Active() or GL.Current()
    if not r then return "Lootmeldungen und Raid-Synchronisierung sind beim Raidstart aktiv." end
    return string.format("%d Lootmeldungen | %d empfangene Dropmeldungen | %d Sendepakete offen",#(r.receipts or {}),r.sharedMessages or 0,#GL.outbox)
end
local eventFrame=CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
local elapsed=0
eventFrame:SetScript("OnUpdate",function(_,dt)
    elapsed=elapsed+dt;if elapsed<0.25 then return end;elapsed=0
    if #GL.outbox>0 then GL.PumpSync() end
end)
function GL.InitializeCapture()
    if GL.captureInitialized or not GL.db then return end
    GL.captureInitialized=true
    if C_ChatInfo then C_ChatInfo.RegisterAddonMessagePrefix(GL.prefix) end
    eventFrame:RegisterEvent("CHAT_MSG_LOOT");eventFrame:RegisterEvent("CHAT_MSG_ADDON");eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
    eventFrame:UnregisterEvent("ADDON_LOADED")
    GL.chatLines={}
    local r=GL.Active()
    -- Preserve and share locally captured history when upgrading an active 0.1 raid.
    if r and not r.localDrops then
        r.localDrops={}
        for _,d in ipairs(r.drops) do if d.capture~="shared" then
            r.localDrops[d.id]={id=d.id,sourceGuid=d.sourceGuid,itemId=d.itemId,itemName=d.itemName,quantity=d.quantity,sourceName=d.sourceName,sourceEvidence=d.sourceEvidence}
        end end
    end
    if r then GL.lastRequest=nil;GL.RequestSync() end
end
eventFrame:SetScript("OnEvent",function(self,event,...)
    if event=="ADDON_LOADED" then
        if (...)~="GuildLootEra" then return end
        GL.InitializeCapture()
    elseif event=="CHAT_MSG_LOOT" then GL.RecordLootMessage((...),select(11,...))
    elseif event=="CHAT_MSG_ADDON" then GL.ReceiveAddon(...)
    elseif event=="GROUP_ROSTER_UPDATE" then GL.RequestSync() end
end)
