local _,GL=...
local function copy(value,seen)
    if type(value)~='table' then return value end
    seen=seen or {};if seen[value] then return seen[value] end
    local result={};seen[value]=result
    for k,v in pairs(value) do result[copy(k,seen)]=copy(v,seen) end
    return result
end
function GL.ApplyCompanionSync(inbox)
    if not GL.db or type(inbox)~='table' then return 0 end
    local recording=GL.Active()~=nil
    if recording and not inbox.activeRaids and not inbox.receipts then return nil,'Charakterimport wird bis nach der Raidaufzeichnung zurückgestellt.' end
    if inbox.schema~=1 or type(inbox.bundles)~='table' or #inbox.bundles<1 or #inbox.bundles>60 then return nil,'Unbekanntes Sync-Format.' end
    local old=GL.db;local selected=old.selectedGuild;local pointRaid=GL.pointRaid
    local staged=copy(old);local count=0;local keys={};local bytes=0
    staged.companionHashes=staged.companionHashes or {}
    GL.db=staged
    local ok,err=pcall(function()
        for _,bundle in ipairs(inbox.bundles) do
            if type(bundle)~='table' or type(bundle.key)~='string' or #bundle.key>500 or keys[bundle.key] or type(bundle.hash)~='string' or #bundle.hash~=64 or not bundle.hash:match('^%x+$') or type(bundle.text)~='string' or not bundle.text:match('^GLME1;') then error('Ungültiges Sync-Paket.') end
            keys[bundle.key]=true;bytes=bytes+#bundle.text
            if bytes>16000000 then error('Sync-Paket zu groß.') end
            if not recording and staged.companionHashes[bundle.key]~=bundle.hash then
                GL.ImportPersonal(bundle.text)
                staged.companionHashes[bundle.key]=bundle.hash;count=count+1
            end
        end
        if inbox.activeRaids~=nil then
            if type(inbox.activeRaids)~='table' then error('Ungültige Raidübersicht.') end
            for guild,data in pairs(inbox.activeRaids) do
                if not staged.guildProfiles[guild] or type(data)~='table' or type(data.rows)~='table' or #data.rows>200 or type(data.exportedAt)~='number' then error('Ungültige Raidübersicht.') end
                for _,r in ipairs(data.rows) do
                    if type(r.id)~='string' or type(r.name)~='string' or #r.name>250 or type(r.date)~='string' or not r.date:match('^%d%d%d%d%-%d%d%-%d%d$') or type(r.clock)~='string' or type(r.kind)~='string' or type(r.count)~='number' then error('Ungültiger Raidtermin.') end
                end
                staged.guildProfiles[guild].activeRaids=copy(data)
            end
        end
        if type(inbox.receipts)=='table' then
            staged.outgoingReceipts=staged.outgoingReceipts or {}
            for id,receipt in pairs(inbox.receipts) do
                local request=staged.outgoingRequests and staged.outgoingRequests[id]
                if request and type(receipt)=='table' and receipt.guild==request.guild and receipt.player==request.player and receipt.realm==request.realm and receipt.raidId==request.raidId and ({success=true,failed=true,unknown=true})[receipt.state] and type(receipt.message)=='string' then
                    staged.outgoingReceipts[id]=copy(receipt)
                    if request.kind=='access' and receipt.state=='success' and type(receipt.at)=='number' then
                        staged.masterAccess=staged.masterAccess or {}
                        local key=request.guild..'\031'..request.player..'\031'..request.realm..'\031'..(receipt.accessScope=='guild' and '*' or request.raidId)
                        if receipt.at>(staged.masterRevokedAt and staged.masterRevokedAt[key] or 0) then staged.masterAccess[key]=receipt.persistentAccess and receipt.accessScope=='guild' and 4102444800 or receipt.at+8*3600 end
                    end
                    if receipt.accessRevoked and type(receipt.at)=='number' then
                        local key=request.guild..'\031'..request.player..'\031'..request.realm..'\031*'
                        staged.masterRevokedAt=staged.masterRevokedAt or {};staged.masterRevokedAt[key]=math.max(staged.masterRevokedAt[key] or 0,receipt.at)
                        staged.masterAccess=staged.masterAccess or {};staged.masterAccess[key]=nil
                    end
                    if (request.kind=='publish' or request.kind=='access' or request.kind=='upload') and type(request.payload)=='table' then request.payload.leadPin=nil end
                end
            end
        end
        for guild,profile in pairs(old.guildProfiles or {}) do
            if profile.personalSelection and staged.guildProfiles[guild] then staged.guildProfiles[guild].personalSelection=profile.personalSelection end
        end
        if not recording and selected and selected~='__unassigned' and staged.guildProfiles[selected] then GL.SelectGuild(selected) end
    end)
    GL.pointRaid=pointRaid
    if not ok then GL.db=old;return nil,'Sync nicht übernommen: '..tostring(err) end
    if count==0 and not inbox.activeRaids and not inbox.receipts then GL.db=old;return 0 end
    if recording then staged.raids=old.raids;staged.active=old.active;staged.priorities=old.priorities;staged.pointRaids=old.pointRaids end
    if GL.ArchiveConfirmedUploads then GL.ArchiveConfirmedUploads() end
    GuildLootEraDB=staged
    if GL.RefreshSyncAccess then GL.RefreshSyncAccess() end
    return count
end
local frame=CreateFrame('Frame')
frame:RegisterEvent('PLAYER_LOGIN')
frame:SetScript('OnEvent',function()
    local count,err=GL.ApplyCompanionSync(GuildLootSyncInbox)
    if err then print('|cffffcc40GuildLoot Sync: '..err..'|r')
    elseif count and count>0 then print('|cff2de3d0GuildLoot Sync: '..count..' Charaktere aktualisiert. /gle öffnet deine Übersicht.|r') end
    GuildLootSyncInbox=nil
end)
