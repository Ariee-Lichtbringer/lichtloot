local _,GL=...
local A={};GL.ArmorRequests=A
local masks={WARRIOR=1,PALADIN=2,HUNTER=4,ROGUE=8,PRIEST=16,SHAMAN=64,MAGE=128,WARLOCK=256,DRUID=1024}
function A.Items(profile,tier)
 local token=GL.CharacterIdentity(profile);local mask=masks[token];local rows={}
 for _,item in ipairs(GL.ArmorCatalog or {}) do if mask and item.classMask==mask and (not tier or item.tier==tier) then rows[#rows+1]=item end end
 return rows
end
function A.Queue(item,materials,profile)
 local current=GL.DisplayProfile()
 if profile and profile.guild and profile.guild~=GL.db.selectedGuild then error('Gilde wurde geändert. Bitte Fenster erneut öffnen.') end
 if not current or not profile or current.player~=profile.player or current.realm~=profile.realm then error('Charakter wurde geändert. Bitte Fenster erneut öffnen.') end
 local found=false;for _,r in ipairs(A.Items(profile)) do if r.itemId==item.itemId then found=true end end
 if not found then error('Dieses Rüstungsteil gehört nicht zu deiner Klasse.') end
 if #materials==0 then error('Bitte benötigte Materialien auswählen.') end
 local seen={}
 for _,m in ipairs(materials) do
  local match;for _,r in ipairs(item.requirements) do if r.itemId==m.itemId then match=r end end
  if not match or seen[m.itemId] or type(m.quantity)~='number' or m.quantity<1 or m.quantity>match.quantity or m.quantity~=math.floor(m.quantity) then error('Bitte gültige Materialmengen eintragen.') end
  seen[m.itemId]=true
 end
 return GL.QueueWebsiteAction({id='armor:'..item.itemId},'armor',{itemId=item.itemId,materials=materials})
end
function A.Open()
 if GL.HasGuildSync and not GL.HasGuildSync() then GL.ShowGuildSyncHelp();return end
 if A.window then A.window:Hide() end
 local original=GL.DisplayProfile();local profile=original and {player=original.player,realm=original.realm,guild=GL.db.selectedGuild};if not profile then print('|cff79e6c5GuildLoot:|r Bitte zuerst deinen Charakter synchronisieren.');return end
 if #A.Items(profile)==0 then print('|cff79e6c5GuildLoot:|r Klasse noch unbekannt. Bitte den gespielten Charakter auswählen und synchronisieren.');return end
 if not A.window then
  local f=CreateFrame('Frame','GuildLootArmorRequests',UIParent);A.window=f;f:SetSize(640,540);f:SetPoint('CENTER');f:SetFrameStrata('DIALOG');f:SetClampedToScreen(true);f:SetMovable(true);f:EnableMouse(true);f:RegisterForDrag('LeftButton')
  f:SetScript('OnDragStart',f.StartMoving);f:SetScript('OnDragStop',f.StopMovingOrSizing)
  local bg=f:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.025,.05,.09,.98)
  local function label(text,x,y,w) local t=f:CreateFontString(nil,'OVERLAY','GameFontHighlight');t:SetPoint('TOPLEFT',x,y);t:SetWidth(w);t:SetJustifyH('LEFT');t:SetText(text);return t end
  label('GuildLoot · Rüstungsteile beantragen',18,-18,530)
  local close=CreateFrame('Button',nil,f,'UIPanelCloseButton');close:SetPoint('TOPRIGHT');close:SetScript('OnClick',function() f:Hide() end)
  f.character=label('',18,-48,600);f.status=label('',18,-459,600);f.status:SetHeight(60)
  label('Benötigte Materialien aus der Gildenbank auswählen:',18,-143,600)
  f.tier=CreateFrame('Frame','GuildLootArmorTier',f,'UIDropDownMenuTemplate');f.tier:SetPoint('TOPLEFT',2,-82);UIDropDownMenu_SetWidth(f.tier,90)
  f.item=CreateFrame('Frame','GuildLootArmorItem',f,'UIDropDownMenuTemplate');f.item:SetPoint('TOPLEFT',126,-82);UIDropDownMenu_SetWidth(f.item,420)
  f.rows={}
  for i=1,5 do
   local row={};f.rows[i]=row;local y=-180-(i-1)*45
   row.check=CreateFrame('CheckButton',nil,f,'UICheckButtonTemplate');row.check:SetPoint('TOPLEFT',18,y);row.check:SetSize(28,28)
   row.icon=CreateFrame('Button',nil,f);row.icon:SetPoint('TOPLEFT',54,y);row.icon:SetSize(28,28);row.texture=row.icon:CreateTexture(nil,'ARTWORK');row.texture:SetAllPoints()
   row.icon:SetScript('OnEnter',function(self) if row.material then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetHyperlink('item:'..row.material.itemId);GameTooltip:Show() end end);row.icon:SetScript('OnLeave',function() GameTooltip:Hide() end)
   row.name=label('',92,y-5,370)
   row.quantity=CreateFrame('EditBox',nil,f,'InputBoxTemplate');row.quantity:SetPoint('TOPLEFT',480,y);row.quantity:SetSize(50,26);row.quantity:SetAutoFocus(false);row.quantity:SetNumeric(true);row.quantity:SetMaxLetters(3)
   row.maximum=label('',544,y-5,70)
   row.check:SetScript('OnClick',function() row.quantity:SetEnabled(row.check:GetChecked());if row.check:GetChecked() then row.quantity:SetFocus() else row.quantity:ClearFocus() end end)
  end
  local send=CreateFrame('Button',nil,f,'UIPanelButtonTemplate');f.send=send;send:SetPoint('TOPLEFT',18,-416);send:SetSize(270,30);send:SetText('In Discord anfragen')
  send:SetScript('OnClick',function()
   local materials={};for _,row in ipairs(f.rows) do if row.material and row.check:GetChecked() then materials[#materials+1]={itemId=row.material.itemId,quantity=tonumber(row.quantity:GetText())} end end
   local ok,result=pcall(A.Queue,f.selection,materials,f.profile)
   if ok then f.status:SetText('Antrag vorgemerkt. Bitte /reload eingeben; GuildLoot Sync überträgt ihn an den PO Bot.');send:Disable() else f.status:SetText(tostring(result):gsub('^.-:%d+: ','')) end
  end)
  f:SetScript('OnHide',function() GameTooltip:Hide();CloseDropDownMenus();for _,row in ipairs(f.rows) do row.quantity:ClearFocus() end end)
 end
 local f=A.window;f.profile=profile;f.selectedTier='T3';f.character:SetText(profile.player..' – '..profile.realm..' · Gilde: '..GL.GuildName(profile.guild))
 local function render(item)
  f.selection=item;UIDropDownMenu_SetText(f.item,'|TInterface\\Icons\\'..item.icon..':20|t '..item.name);f.status:SetText(GL.WebsiteActionStatus('armor:'..item.itemId));f.send:Enable()
  for i,row in ipairs(f.rows) do local m=item.requirements[i];row.material=m
   row.check:SetShown(m~=nil);row.icon:SetShown(m~=nil);row.name:SetShown(m~=nil);row.quantity:SetShown(m~=nil);row.maximum:SetShown(m~=nil)
   if m then row.check:SetChecked(false);row.quantity:SetEnabled(false);row.quantity:SetText(tostring(m.quantity));row.name:SetText(m.name..(m.itemId==item.tokenId and ' (Token)' or ''));row.texture:SetTexture('Interface\\Icons\\'..m.icon);row.maximum:SetText('von '..m.quantity) end
  end
 end
 local function refresh()
  UIDropDownMenu_SetText(f.tier,f.selectedTier)
  UIDropDownMenu_Initialize(f.item,function()
   for _,item in ipairs(A.Items(f.profile,f.selectedTier)) do local entry=item;local info=UIDropDownMenu_CreateInfo();info.text=entry.name;info.icon='Interface\\Icons\\'..entry.icon;info.checked=f.selection==entry;info.func=function() render(entry) end;UIDropDownMenu_AddButton(info) end
  end);render(A.Items(f.profile,f.selectedTier)[1])
 end
 UIDropDownMenu_Initialize(f.tier,function() for _,tier in ipairs({'T3','T2,5'}) do local value=tier;local info=UIDropDownMenu_CreateInfo();info.text=value;info.checked=value==f.selectedTier;info.func=function() f.selectedTier=value;refresh() end;UIDropDownMenu_AddButton(info) end end)
 refresh();f:Show()
end
SLASH_GUILDLOOTARMOR1='/glarmor';SlashCmdList.GUILDLOOTARMOR=function() A.Open() end
