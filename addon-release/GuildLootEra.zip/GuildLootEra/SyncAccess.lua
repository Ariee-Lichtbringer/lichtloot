local _,GL=...
GL.GuildSyncURL='https://lichtloot.de/start.html'
GL.GuildSyncHint='Diese Funktion ist nur mit der GuildLoot Sync-App nutzbar.'
local controls={}
function GL.HasGuildSync()
 local db=GL.db
 if not db then return false end
 -- Only companion imports write these hashes; a manual character import does not.
 for _,hash in pairs(db.companionHashes or {}) do
  if type(hash)=='string' and #hash==64 and hash:match('^%x+$') then return true end
 end
 return false
end
function GL.RequireGuildSync()
 if not GL.HasGuildSync() then error(GL.GuildSyncHint..' Download: '..GL.GuildSyncURL,2) end
end
function GL.ShowGuildSyncHelp()
 local f=GL.guildSyncHelp
 if not f then
  f=CreateFrame('Frame','GuildLootSyncRequired',UIParent,'BasicFrameTemplateWithInset');GL.guildSyncHelp=f;f:SetSize(490,220);f:SetPoint('CENTER');f:SetFrameStrata('DIALOG');f:SetClampedToScreen(true)
  f.TitleText:SetText('GuildLoot Sync erforderlich')
  local hint=f:CreateFontString(nil,'OVERLAY','GameFontHighlight');hint:SetPoint('TOPLEFT',18,-40);hint:SetWidth(454);hint:SetJustifyH('LEFT')
  hint:SetText(GL.GuildSyncHint..'\n\nNoch keine Synchronisierung erkannt. Auf der Website „Addon Download & Installation“ öffnen, Sync installieren und verbinden. Danach synchronisieren und in WoW /reload eingeben.')
  local edit=CreateFrame('EditBox',nil,f,'InputBoxTemplate');edit:SetPoint('BOTTOMLEFT',24,44);edit:SetSize(442,26);edit:SetAutoFocus(false);edit:SetText(GL.GuildSyncURL)
  edit:SetScript('OnEscapePressed',function() f:Hide() end);edit:SetScript('OnEnterPressed',function() edit:ClearFocus() end)
  local caption=f:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');caption:SetPoint('BOTTOMLEFT',18,18);caption:SetText('Adresse kopieren (Strg+C / Cmd+C) und im Browser öffnen.')
  f.address=edit
 end
 f:Show();f.address:SetText(GL.GuildSyncURL);f.address:SetFocus();f.address:HighlightText()
end
function GL.GateSyncControl(b)
 if b.guildSyncGate then return b end
 b.guildSyncGate=true
 local enabled=b.SetEnabled;local desired=not b.IsEnabled or b:IsEnabled()
 local overlay=CreateFrame('Frame',nil,b);overlay:SetAllPoints();overlay:EnableMouse(true);overlay:SetFrameLevel(b:GetFrameLevel()+5)
 local function refresh()
  local available=GL.HasGuildSync();enabled(b,desired and available);b:SetAlpha(available and (desired and 1 or .4) or .4);overlay:SetShown(not available)
 end
 b.SetEnabled=function(_,value) desired=value and true or false;refresh() end
 b.Enable=function() desired=true;refresh() end
 b.Disable=function() desired=false;refresh() end
 overlay:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText(GL.GuildSyncHint);GameTooltip:AddLine('Noch keine Synchronisierung erkannt.\nKlicken: Downloadadresse und Einrichtung.',1,1,1,true);GameTooltip:Show() end)
 overlay:SetScript('OnLeave',function() GameTooltip:Hide() end)
 overlay:SetScript('OnMouseUp',function(_,key) if key=='LeftButton' then GL.ShowGuildSyncHelp() end end)
 b:HookScript('OnShow',refresh);controls[#controls+1]=refresh;refresh();return b
end
local labels={
 ['Berufe']=true,['Addon aktualisieren']=true,['Aktive Raids']=true,['Mit PIN entsperren']=true,['Prio öffnen']=true,
 ['Protokoll hochladen']=true,['Berufe synchronisieren']=true,['Rüstungsteile beantragen']=true,
 ['Anmeldung absenden']=true,['Prios absenden']=true,['Raid erstellen und absenden']=true,['+ Raid erstellen']=true,
 ['Raidsheet']=true,
}
function GL.GateSyncButton(b,title)
 if labels[title] then GL.GateSyncControl(b) end
 return b
end
function GL.RefreshSyncAccess() for _,refresh in ipairs(controls) do refresh() end end
