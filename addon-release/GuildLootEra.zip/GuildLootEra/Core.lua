local _, GL = ...
GuildLootEra = GL
GL.version = "0.24.12-beta"
local function trim(v) return (tostring(v or ""):gsub("^%s+", ""):gsub("%s+$", "")) end
local function split(s, sep)
    local out = {}; for v in (s .. sep):gmatch("(.-)" .. sep) do out[#out+1] = v end; return out
end
local function decode(s)
    if s:gsub("%%[%x][%x]", ""):find("%%") then error("Ungültige Zeichenkodierung.") end
    return (s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h,16)) end))
end
local function integer(v, min, max)
    local n=tonumber(v); return n and n==math.floor(n) and n>=min and n<=max and n or nil
end
function GL.ParsePriorities(text)
    if type(text)~="string" or #text>1000000 then error("Prioliste zu groß.") end
    text=text:gsub("^\239\187\191", ""):gsub("\r\n", "\n"):gsub("\r", "\n")
    -- WoW may escape literal pipes when pasting into an EditBox.
    if text:match("^GLP1||") then text=text:gsub("||", "|") end
    if not text:match("^GLP1[;|\t]") then return GL.ParseLegacyPriorities(text:gsub("\r", "")) end
    local lines=split(text:gsub("\r", ""):gsub("\n+$", ""), "\n")
    local separator=text:sub(5,5)
    local head=split(lines[1] or "", separator)
    if #head~=8 or head[1]~="GLP1" then error("Export-Kopfzeile hat "..#head.." statt 8 Felder. Bitte den Export neu von der Website kopieren.") end
    local p={guild=decode(head[2]),raidId=decode(head[3]),raidName=decode(head[4]),
        exportedAt=integer(head[5],1,9999999999),instanceId=integer(head[6],1,10000),
        realm=decode(head[7]),raidDate=decode(head[8]),rows={}}
    if p.guild=="" or p.raidId=="" or not p.exportedAt or not p.instanceId then error("Raidangaben fehlen.") end
    local seen={}
    for i=2,#lines do
        local f=split(lines[i],separator)
        if #f~=8 and #f~=9 then error("Ungültige Zeile "..i) end
        f[5]=decode(f[5])
        local item=integer(f[1],1,1000000); local points=tonumber(f[6])
        if not item or not points or points~=points or math.abs(points)>1000000 or not ({P1=true,P2=true,P3=true,P0=true,["P0+"]=true,Punkte=true})[f[5]] then error("Ungültige Werte in Zeile "..i) end
        if f[8]~="0" and f[8]~="1" then error("Ungültige Bankangabe.") end
        local row={itemId=item,itemName=decode(f[2]),player=decode(f[3]),realm=decode(f[4]),priority=f[5],points=points,class=decode(f[7]),bench=f[8]=="1"}
        if f[9] and f[9]~="" then
            row.createdAt=integer(f[9],1,4102444800)
            if not row.createdAt then error("Ungültiger Prio-Zeitpunkt in Zeile "..i) end
        end
        if row.player=="" or #row.player>100 or #row.itemName>250 then error("Ungültiger Spieler oder Itemname.") end
        local key=table.concat({item,row.player,row.realm,row.priority},"|")
        if seen[key] then error("Doppelter Prioeintrag.") end; seen[key]=true
        p.rows[#p.rows+1]=row
        if #p.rows>5000 then error("Zu viele Einträge.") end
    end
    return p
end
local function guildKey(guild)
    return type(guild)=="string" and guild~="" and guild~="Noch nicht zugeordnet" and guild or "__unassigned"
end
function GL.Guilds()
    local keys={};for key in pairs(GL.db.guildProfiles or {}) do keys[#keys+1]=key end;table.sort(keys);return keys
end
function GL.GuildName(key) return key=="__unassigned" and "Noch nicht zugeordnet" or key or "Noch keine Gilde importiert" end
function GL.SelectGuild(key)
    if not GL.db.guildProfiles[key] then error("Gilde nicht gefunden.") end
    local active=GL.Active()
    if active and key~=active.guild then error("Während der Aufzeichnung bleibt die Gilde "..active.guild.." ausgewählt. Bitte den Raid zuerst beenden.") end
    GL.db.selectedGuild=key
    local profile=GL.db.guildProfiles[key]
    GL.db.priorities=profile.priorities;GL.db.pointRaids=profile.pointRaids
end
function GL.InitializeGuilds()
        if GL.InitializeMinimap then GL.InitializeMinimap() end
        if GL.InitializeSheetShortcut then GL.InitializeSheetShortcut() end
    GL.db.guildProfiles=GL.db.guildProfiles or {}
    if not GL.db.guildProfilesMigrated then
        local p=GL.db.priorities
        if p then local key=guildKey(p.guild);GL.db.guildProfiles[key]=GL.db.guildProfiles[key] or {};GL.db.guildProfiles[key].priorities=p;GL.db.selectedGuild=key end
        for raid,points in pairs(GL.db.pointRaids or {}) do
            local key=guildKey(points.guild);local profile=GL.db.guildProfiles[key] or {};GL.db.guildProfiles[key]=profile
            profile.pointRaids=profile.pointRaids or {};profile.pointRaids[raid]=points
            GL.db.selectedGuild=GL.db.selectedGuild or key
        end
        for _,raid in ipairs(GL.db.raids) do local key=guildKey(raid.guild);GL.db.guildProfiles[key]=GL.db.guildProfiles[key] or {} end
        GL.db.guildProfilesMigrated=true
    end
    local active=GL.Active();local key=active and active.guild or GL.db.selectedGuild
    if key and GL.db.guildProfiles[key] then GL.SelectGuild(key) else local keys=GL.Guilds();if keys[1] then GL.SelectGuild(keys[1]) end end
end
function GL.StoreGuildData(guild,field,data)
    local key=guildKey(guild);local active=GL.Active()
    if active and key~=active.guild then error("Der Import gehört zu einer anderen Gilde. Bitte den laufenden Raid zuerst beenden.") end
    GL.db.guildProfiles[key]=GL.db.guildProfiles[key] or {}
    GL.db.guildProfiles[key][field]=data;GL.SelectGuild(key)
end
GL.PointRaids={"mc","bwl","ony","zg","aq20","aq40","naxx","zg-mittwoch","zg-prime","zg-late"}
local basePointRaids={"mc","bwl","ony","zg","aq20","aq40","naxx"}
function GL.DisplayPriorities()
    if GL.pointRaid then return GL.db.pointRaids and GL.db.pointRaids[GL.pointRaid] end
    return GL.db.priorities
end
function GL.ParseAllPoints(text)
        if #text>4000000 then error("Punkteexport zu groß.") end
        local blocks,current={},nil
        for line in text:gmatch("[^\n]+") do
            if line:match("^GLP1;") then current={line};blocks[#blocks+1]=current
            elseif line~="GLPA1" then
                if not current then error("Ungültiger Punkteexport.") end
                current[#current+1]=line
            end
        end
        local raids,total,guild={},0,nil
        for _,block in ipairs(blocks) do
            local p=GL.ParsePriorities(table.concat(block,"\n"))
            local key=p.raidId:match("^points:([%w%-]+)$")
            local allowed=false;for _,r in ipairs(GL.PointRaids) do if r==key then allowed=true end end
            if not allowed or raids[key] or (guild and guild~=p.guild) then error("Ungültige Raidzuordnung im Punkteexport.") end
            for _,r in ipairs(p.rows) do if r.priority~="Punkte" then error("Punkteexport enthält Raid-Prios.") end end
            guild=p.guild;raids[key]=p;total=total+#p.rows
        end
        for _,key in ipairs(basePointRaids) do if not raids[key] then error("Punkteexport unvollständig: "..key) end end
    return raids,total,guild
end
function GL.Import(text)
    if type(text)=="string" then text=text:gsub("^\239\187\191", ""):gsub("\r\n","\n"):gsub("\r","\n") end
    if type(text)=="string" and text:match("^GLME1;") then return GL.ImportPersonal(text) end
    if type(text)=="string" and text:match("^GLPA1\n") then
        local raids,total,guild=GL.ParseAllPoints(text)
        -- Old seven-raid exports have no information about separate ZG accounts.
        -- Keep those accounts until a new export explicitly supplies them.
        local previous=GL.db.guildProfiles[guild] and GL.db.guildProfiles[guild].pointRaids
        for _,key in ipairs(GL.PointRaids) do if not raids[key] and previous then raids[key]=previous[key] end end
        GL.StoreGuildData(guild,"pointRaids",raids);GL.pointRaid="mc";return total
    end
    if GL.db.active then error("Bitte den laufenden Raid zuerst beenden. Die Prioliste bleibt für diesen Raid eingefroren.") end
    local p=GL.ParsePriorities(text); GL.StoreGuildData(p.guild,"priorities",p);GL.pointRaid=nil;return #p.rows
end
local function quote(s)
    return '"'..tostring(s):gsub('[%z\1-\31\\"]',function(c)
        local escapes={['"']='\\"',['\\']='\\\\',['\n']='\\n',['\r']='\\r',['\t']='\\t'}
        return escapes[c] or string.format('\\u%04x',string.byte(c))
    end)..'"'
end
function GL.JSON(v)
    if type(v)=="string" then return quote(v) end
    if type(v)=="number" then assert(v==v and math.abs(v)<math.huge); return tostring(v) end
    if type(v)=="boolean" then return tostring(v) end
    if type(v)~="table" then return "null" end
    local out={}
    if #v>0 then for _,x in ipairs(v) do out[#out+1]=GL.JSON(x) end; return "["..table.concat(out,",").."]" end
    for k,x in pairs(v) do out[#out+1]=quote(k)..":"..GL.JSON(x) end
    table.sort(out); return "{"..table.concat(out,",").."}"
end
local function sameRecording(a,b)
 return a and b and a.guild==b.guild and a.raidId==b.raidId and a.raidDate==b.raidDate and a.instanceId==b.instanceId and a.recorder==b.recorder
end
local function cloneRecording(value)
 if type(value)~='table' then return value end
 local copy={};for k,v in pairs(value) do copy[k]=cloneRecording(v) end;return copy
end
function GL.MergeRecentRecordings()
 local raids=GL.db.raids;local latest=raids[#raids]
 if GL.db.active and GL.db.active~=#raids then return end
 if not latest or latest.archivedAt or GetServerTime()-(latest.endedAt or latest.startedAt)>21600 then return end
 local first=#raids
 while first>1 do
  local before,after=raids[first-1],raids[first]
  if before.archivedAt or not sameRecording(before,latest) or not before.endedAt or after.startedAt-before.endedAt<0 or after.startedAt-before.endedAt>21600 then break end
  first=first-1
 end
 if first==#raids then return end
 local merged=cloneRecording(raids[first]);local wasActive=GL.db.active==#raids
 GL.db.recordingBackups=GL.db.recordingBackups or {}
 for i=first,#raids do GL.db.recordingBackups[#GL.db.recordingBackups+1]=cloneRecording(raids[i]) end
 merged.interruptions=merged.interruptions or {}
 for i=first+1,#raids do
  local part=raids[i]
  merged.interruptions[#merged.interruptions+1]={from=merged.endedAt,to=part.startedAt}
  for _,gap in ipairs(part.interruptions or {}) do merged.interruptions[#merged.interruptions+1]=cloneRecording(gap) end
  for _,key in ipairs({'receipts','trades','chatEvidence','buffChecks'}) do
   merged[key]=merged[key] or {};for _,e in ipairs(part[key] or {}) do merged[key][#merged[key]+1]=cloneRecording(e) end
  end
  local dropIds={};for _,d in ipairs(merged.drops) do dropIds[d.id]=d end
  for _,d in ipairs(part.drops or {}) do
   local old=dropIds[d.id]
   if old then old.quantity=math.max(old.quantity,d.quantity) else local copy=cloneRecording(d);merged.drops[#merged.drops+1]=copy;dropIds[d.id]=copy end
  end
  for _,key in ipairs({'names','manualSources','localDrops'}) do
   merged[key]=merged[key] or {};for k,v in pairs(part[key] or {}) do
    if key=='localDrops' and merged[key][k] then merged[key][k].quantity=math.max(merged[key][k].quantity,v.quantity) else merged[key][k]=cloneRecording(v) end
   end
  end
  merged.participants=merged.participants or {};local seen={};for _,e in ipairs(merged.participants) do seen[e.guid]=e end
  for _,e in ipairs(part.participants or {}) do
   if seen[e.guid] then seen[e.guid].firstSeen=math.min(seen[e.guid].firstSeen,e.firstSeen);seen[e.guid].lastSeen=math.max(seen[e.guid].lastSeen,e.lastSeen)
   else local copy=cloneRecording(e);merged.participants[#merged.participants+1]=copy;seen[e.guid]=copy end
  end
  for _,key in ipairs({'unresolvedLoot','syncWarning','captureWarning','buffCheckLimit'}) do merged[key]=merged[key] or part[key] end
  merged.endedAt=part.endedAt
 end
 for key,prefix in pairs({receipts='receipt',trades='trade',chatEvidence='evidence'}) do
  for n,e in ipairs(merged[key] or {}) do e.id=merged.sessionId..':'..prefix..':'..n end
 end
 merged.receiptSequence=#(merged.receipts or {});merged.tradeSequence=#(merged.trades or {})
 merged.captureWarning=true -- The stop/start gap was not observed.
 for i=#raids,first,-1 do raids[i]=nil end
 raids[first]=merged;if wasActive then GL.db.active=first end
end
function GL.Start()
    if GL.db.active then error("Ein Raid läuft bereits.") end
    local p=GL.db.priorities
    local profile=(GL.db.guildProfiles or {})[GL.db.selectedGuild] or {}
    local data=profile.activeRaids or {};local selected
    for _,raid in ipairs(data.rows or {}) do if GL.masterRaidId and (raid.id==GL.masterRaidId or raid.internalId==GL.masterRaidId) then selected=raid;break end end
    if GL.masterRaidId and not selected then error("Der ausgewählte Raid ist nicht mehr verfügbar. Bitte die Raid-Auswahl prüfen.") end
    if selected then
        local instances={mc=409,bwl=469,ony=249,zg=309,aq20=509,aq40=531,naxx=533}
        local key=selected.raid;local id=instances[key] or (key and key:match('^zg%-') and 309)
        if not id then error("Instanz des ausgewählten Raids unbekannt.") end
        p={guild=GL.db.selectedGuild,raidId=selected.id,raidName=selected.name,raidDate=selected.date,instanceId=id,exportedAt=data.exportedAt}
    end
    if not p then error("Bitte zuerst den Raid unter Plündermeister → Prioliste auswählen.") end
    if p.legacy and not p.raidId then error("Prio3-Liste importiert. Vor der Aufzeichnung bitte mit Raid zuordnen die Gildenkennung, Raid-ID und Instanz ergänzen.") end
    if p.guild~=GL.db.selectedGuild then error("Die Prioliste gehört zu einer anderen Gilde. Bitte den Raid neu auswählen.") end
    if not p.raidId or p.raidId:match('^points:') then error("Bitte einen konkreten Raidtermin auswählen.") end
    local _,kind,_,_,_,_,_,instanceId=GetInstanceInfo()
    if not IsInRaid() then error("Bitte zuerst einer Schlachtzugsgruppe beitreten.") end
    if kind=="raid" and instanceId~=p.instanceId then error("Du bist in einer anderen Raidinstanz als der ausgewählte Raid.") end
    local name,realm=UnitFullName("player"); realm=realm or GetRealmName()
    local last=GL.db.raids[#GL.db.raids]
    local now=GetServerTime()
    local resume=last and not last.archivedAt and sameRecording(last,{guild=p.guild,raidId=p.raidId,raidDate=p.raidDate,instanceId=p.instanceId,recorder=name..'-'..realm}) and last.endedAt and now-last.endedAt>=0 and now-last.endedAt<=21600
    if p.raidDate~=date("%Y-%m-%d",now) and not (resume and p.raidDate==date("%Y-%m-%d",now-86400)) then
        error("Der ausgewählte Raidtermin ist nicht heute. Bitte die heutigen Raids synchronisieren und den richtigen Termin auswählen.")
    end
    GL.MergeRecentRecordings()
    local previous=GL.db.raids[#GL.db.raids]
    local expected={guild=p.guild,raidId=p.raidId,raidDate=p.raidDate,instanceId=p.instanceId,recorder=name..'-'..realm}
    if sameRecording(previous,expected) and not previous.archivedAt and previous.endedAt and GetServerTime()-previous.endedAt>=0 and GetServerTime()-previous.endedAt<=21600 then
        previous.interruptions=previous.interruptions or {}
        previous.interruptions[#previous.interruptions+1]={from=previous.endedAt,to=GetServerTime()}
        previous.endedAt=nil;previous.captureWarning=true;GL.db.active=#GL.db.raids
        if GL.CaptureStarted then GL.CaptureStarted() end
        return previous
    end
    GL.db.sequence=(GL.db.sequence or 0)+1
    local now=GetServerTime()
    local r={sessionId=table.concat({UnitGUID("player"),now,GL.db.sequence},":"),guild=p.guild,
        raidId=p.raidId,raidName=p.raidName,raidDate=p.raidDate,realm=realm,recorder=name.."-"..realm,
        instanceId=p.instanceId,startedAt=now,priorityExportedAt=p.exportedAt,drops={},names={},manualSources={}}
    GL.db.raids[#GL.db.raids+1]=r; GL.db.active=#GL.db.raids
    if GL.CaptureStarted then GL.CaptureStarted() end
    return r
end
function GL.Stop()
    local r=GL.Active(); if not r then error("Kein Raid aktiv.") end
    r.endedAt=GetServerTime(); GL.db.active=nil; return r
end
function GL.Active() return GL.db and GL.db.active and GL.db.raids[GL.db.active] end
function GL.Current()
    local active=GL.Active();if active then return active end
    for i=#GL.db.raids,1,-1 do local r=GL.db.raids[i];if not r.archivedAt and (not GL.db.selectedGuild or r.guild==GL.db.selectedGuild) then return r end end
end
function GL.InInstance(r)
    local _,kind,_,_,_,_,_,id=GetInstanceInfo(); return kind=="raid" and id==r.instanceId and IsInRaid()
end
-- Names come from GUID-bearing game events, never from the most recent boss kill.
function GL.ObserveName(guid,name)
    local r=GL.Active(); if not r or not guid or not name or not GL.InInstance(r) then return end
    if not guid:match("^Creature%-") then return end
    r.names[guid]=name
    for _,d in ipairs(r.drops) do if d.sourceGuid==guid and d.sourceEvidence=="unknown" then d.sourceName=name;d.sourceEvidence="observed" end end
    for _,d in pairs(r.localDrops or {}) do if d.sourceGuid==guid and d.sourceEvidence=="unknown" then d.sourceName=name;d.sourceEvidence="observed";if GL.ShareDrop then GL.ShareDrop(r,d) end end end
end
-- One snapshot may contain several slots with the same item. Keep their total,
-- and the largest observed total over subsequent opens of that same source.
function GL.RecordSnapshot(r,entries)
    r.localDrops=r.localDrops or {}
    local totals={}
    for _,e in ipairs(entries) do
        local key=e.sourceGuid..":"..e.itemId
        if not totals[key] then totals[key]={sourceGuid=e.sourceGuid,itemId=e.itemId,itemName=e.itemName,itemLink=e.itemLink,quantity=0} end
        totals[key].quantity=totals[key].quantity+e.quantity
    end
    local existing={}; for _,d in ipairs(r.drops) do existing[d.id]=d end
    for key,e in pairs(totals) do
        local d=existing[key]
        local localDrop=r.localDrops[key]
        local quantity=math.max(localDrop and localDrop.quantity or 0,e.quantity)
        local name=r.manualSources[e.sourceGuid] or r.names[e.sourceGuid]
        local evidence=r.manualSources[e.sourceGuid] and "manual" or (name and "observed" or "unknown")
        local changed=not localDrop or localDrop.quantity~=quantity or localDrop.sourceName~=(name or "Unbekannte Quelle")
        r.localDrops[key]={id=key,sourceGuid=e.sourceGuid,itemId=e.itemId,itemName=e.itemName,quantity=quantity,sourceName=name or "Unbekannte Quelle",sourceEvidence=evidence}
        if changed and GL.ShareDrop then GL.ShareDrop(r,r.localDrops[key]) end
        if d then
            d.quantity=math.max(d.quantity,e.quantity)
            if d.capture=="shared" and evidence~="unknown" then d.sourceName=name;d.sourceEvidence=evidence;d.capture="local";d.reportedBy=nil end
        else
            local name=r.manualSources[e.sourceGuid] or r.names[e.sourceGuid]
            e.id=key;e.sourceName=name or "Unbekannte Quelle";e.sourceEvidence=r.manualSources[e.sourceGuid] and "manual" or (name and "observed" or "unknown")
            e.observedAt=GetServerTime();e.capture="local";r.drops[#r.drops+1]=e
        end
    end
    table.sort(r.drops,function(a,b) if a.observedAt==b.observedAt then return a.id<b.id end return a.observedAt<b.observedAt end)
end
function GL.ScanLoot()
    local r=GL.Active(); if not r or not GL.InInstance(r) then return end
    GL.ObserveName(UnitGUID("target"),UnitName("target"))
    local entries={};local sourceSet={}
    for slot=1,GetNumLootItems() do
        local link=GetLootSlotLink(slot)
        local itemId=link and tonumber(link:match("item:(%d+)"))
        if itemId then
            local _,name,quantity=GetLootSlotInfo(slot)
            local sources={GetLootSourceInfo(slot)}
            if #sources==0 then r.unresolvedLoot=true end
            for n=1,#sources,2 do
                local guid,count=sources[n],tonumber(sources[n+1])
                if type(guid)=="string" and (guid:match("^Creature%-") or guid:match("^GameObject%-")) and count and count>0 then
                    entries[#entries+1]={sourceGuid=guid,itemId=itemId,itemName=name or link:match("%[(.-)%]") or tostring(itemId),itemLink=link,quantity=count}
                    sourceSet[guid]=true
                end
            end
        end
    end
    GL.lastSources=sourceSet
    GL.RecordSnapshot(r,entries)
end
function GL.SetSourceName(name)
    local r=GL.Active(); name=trim(name)
    if not r or name=="" or #name>120 then error("Aktiver Raid und Quellenname erforderlich.") end
    local source,count=nil,0;for guid in pairs(GL.lastSources or {}) do source=guid;count=count+1 end
    if count~=1 then error("Bitte das Lootfenster genau einer Quelle öffnen und dann zuordnen.") end
    r.manualSources[source]=name
    for _,d in ipairs(r.drops) do if d.sourceGuid==source then d.sourceName=name;d.sourceEvidence="manual";d.capture="local";d.reportedBy=nil end end
    for _,d in pairs(r.localDrops or {}) do if d.sourceGuid==source then d.sourceName=name;d.sourceEvidence="manual";if GL.ShareDrop then GL.ShareDrop(r,d) end end end
end
function GL.Export(index,lootOnly)
    local r=index and GL.db.raids[index] or GL.Current(); if not r then error("Noch kein Raid aufgezeichnet.") end
    if GL.db.selectedGuild and r.guild~=GL.db.selectedGuild then error("Dieses Protokoll gehört zu einer anderen Gilde. Bitte zuerst die Gilde wechseln.") end
    if not r.endedAt then error("Bitte den Raid vor dem Export beenden.") end
    local payload={schema="guildloot.raid.v3",addonVersion=GL.version,sessionId=r.sessionId,guild=r.guild,raidId=r.raidId,
        raidName=r.raidName,raidDate=r.raidDate,realm=r.realm,recorder=r.recorder,instanceId=r.instanceId,
        startedAt=r.startedAt,endedAt=r.endedAt,priorityExportedAt=r.priorityExportedAt,unresolvedLoot=r.unresolvedLoot==true,drops=r.drops,participants=r.participants or {},buffChecks=r.buffChecks or {},buffCheckLimit=r.buffCheckLimit==true,receipts=r.receipts or {},trades=r.trades or {},chatEvidence=r.chatEvidence or {},syncWarning=r.syncWarning==true,captureWarning=r.captureWarning==true}
    if lootOnly then
        payload.participants={};payload.buffChecks=nil;payload.buffCheckLimit=nil;payload.trades=nil;payload.chatEvidence=nil
    end
    local json=GL.JSON(payload)
    if #r.drops==0 then json=json:gsub('"drops":{}','"drops":[]') end
    if not r.receipts or #r.receipts==0 then json=json:gsub('"receipts":{}','"receipts":[]') end
    if lootOnly or not r.participants or #r.participants==0 then json=json:gsub('"participants":{}','"participants":[]') end
    if not r.trades or #r.trades==0 then json=json:gsub('"trades":{}','"trades":[]') end
    if not r.chatEvidence or #r.chatEvidence==0 then json=json:gsub('"chatEvidence":{}','"chatEvidence":[]') end
    -- Keep WoW's hyperlink/color syntax out of the copy field without changing JSON values.
    json=json:gsub('|', '\\u007c')
    return json
end
function GL.PriorityText(search)
    local p=GL.db.priorities;if not p then return "Noch keine Prioliste importiert." end
    search=trim(search):lower();local rows={}
    for _,row in ipairs(p.rows) do
        if search=="" or tostring(row.itemId)==search or row.itemName:lower():find(search,1,true) or row.player:lower():find(search,1,true) then rows[#rows+1]=row end
    end
    table.sort(rows,function(a,b) if a.itemId~=b.itemId then return a.itemId<b.itemId end if a.points~=b.points then return (a.points or -math.huge)>(b.points or -math.huge) end return a.player<b.player end)
    local out={p.raidName.." | "..p.guild.." | "..p.raidDate,(p.legacy and "Importiert: " or "Stand: ")..date("%d.%m.%Y %H:%M",p.exportedAt),"Punkte sind der importierte Stand; Vergaben ändern sie nicht automatisch.",""}
    if p.legacy then out[#out+1]="Prio3 enthält keine Punkte, P0+-Kennzeichnung oder Bankspieler. Diese Angaben sind unbekannt.";if not p.raidId then out[#out+1]="Für die Aufzeichnung zuerst Raid zuordnen (Gilde, Raid-ID, Instanz)." end end
    for _,r in ipairs(rows) do out[#out+1]=string.format("%s [%d]\n  %s-%s | %s | Punkte: %s%s",r.itemName,r.itemId,r.player,r.realm,r.priority,r.points~=nil and tostring(r.points) or "nicht enthalten",r.bench and " | BANK" or "") end
    return table.concat(out,"\n")
end
function GL.HistoryText()
    local out={"RAIDPROTOKOLLE","Eigene/geteilte Drops und empfangene Lootmeldungen. Empfangsmeldungen werden nicht als zusätzliche Drops gezählt.",""}
    for i,r in ipairs(GL.db.raids) do
        if not GL.db.selectedGuild or r.guild==GL.db.selectedGuild then
        out[#out+1]=string.format("#%d %s | %s | %s",i,r.raidName,date("%d.%m.%Y %H:%M",r.startedAt),r.endedAt and "beendet" or "läuft")
        for _,d in ipairs(r.drops) do out[#out+1]=string.format("  %s: %dx %s [%d]%s",d.sourceName,d.quantity,d.itemName,d.itemId,(d.capture=="shared" and " (von "..(d.reportedBy or "Raid")..")" or "")..(d.sourceEvidence=="manual" and " (manuell)" or "")) end
        for _,check in ipairs(r.buffChecks or {}) do
            out[#out+1]="  BUFFCHECK "..date("%H:%M:%S",check.at).." · "..check.reason
            out[#out+1]="    "..#(check.players or {}).." Spieler · Details über Buffübersicht"
        end
        out[#out+1]="  EMPFANGSMELDUNGEN (Quelle nicht bestätigt):"
        for _,e in ipairs(r.receipts or {}) do out[#out+1]=string.format("  %s: %dx %s [%d]",e.recipient,e.quantity,e.itemName,e.itemId) end
        if r.syncWarning or r.captureWarning then out[#out+1]="  HINWEIS: Aufzeichnung/Übertragung war eingeschränkt. Vor dem Beenden /gle sync ausführen." end
        if r.unresolvedLoot then out[#out+1]="  HINWEIS: Beute ohne Quellen-GUID beobachtet; Protokoll möglicherweise unvollständig." end
        out[#out+1]=""
        end
    end
    return table.concat(out,"\n")
end
local f=CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent",function(self,event,...)
    if event=="ADDON_LOADED" then
        if (...)~="GuildLootEra" then return end
        GuildLootEraDB=GuildLootEraDB or {schema=1,raids={}}
        if GuildLootEraDB.schema~=1 then print("GuildLoot: Unbekanntes Speicherformat. Addon bitte aktualisieren.");return end
        GL.db=GuildLootEraDB
        GL.InitializeGuilds()
        GL.MergeRecentRecordings()
        if GL.InitializeMinimap then GL.InitializeMinimap() end
        if GL.InitializeSheetShortcut then GL.InitializeSheetShortcut() end
        if GL.InitializeCapture then GL.InitializeCapture() end
        for _,e in ipairs({"LOOT_READY","LOOT_OPENED","LOOT_SLOT_CHANGED","LOOT_CLOSED","COMBAT_LOG_EVENT_UNFILTERED","PLAYER_TARGET_CHANGED"}) do self:RegisterEvent(e) end
        self:UnregisterEvent("ADDON_LOADED")
    elseif event=="LOOT_CLOSED" then GL.lastSources=nil
    elseif event=="LOOT_READY" or event=="LOOT_OPENED" or event=="LOOT_SLOT_CHANGED" then GL.ScanLoot()
    elseif event=="PLAYER_TARGET_CHANGED" then GL.ObserveName(UnitGUID("target"),UnitName("target"))
    elseif event=="COMBAT_LOG_EVENT_UNFILTERED" and GL.Active() then
        local _,_,_,src,name,_,_,dst,dstName=CombatLogGetCurrentEventInfo()
        GL.ObserveName(src,name);GL.ObserveName(dst,dstName)
    end
end)
