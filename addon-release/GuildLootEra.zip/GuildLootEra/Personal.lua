local _,GL=...
local function fields(line)
    local result={}
    for value in (line..';'):gmatch('(.-);') do
        if value:gsub('%%[%x][%x]',''):find('%%') then error('Ungültige Exportkodierung.') end
        result[#result+1]=value:gsub('%%(%x%x)',function(h) return string.char(tonumber(h,16)) end)
    end
    return result
end
function GL.ImportPersonal(text)
    if #text>8000000 then error('Persönlicher Export zu groß.') end
    if GL.Active() then error('Bitte zuerst die laufende Raidaufzeichnung beenden.') end
    local lines={};for line in text:gmatch('[^\n]+') do lines[#lines+1]=fields(line) end
    local h=lines[1];local stamp=tonumber(h[5])
    if #h~=5 or not h[2]:match('^[%w_-]+$') or #h[2]>100 or h[3]=='' or #h[3]>100 or #h[4]>100 or not stamp or stamp<1 or stamp>4102444800 or stamp~=math.floor(stamp) then error('Ungültiger persönlicher Export.') end
    local personal={player=h[3],realm=h[4],exportedAt=stamp,releases={},history={},calendar={},events={}}
    local prios,points,total,guild
    for i=2,#lines do local f=lines[i]
        if f[1]=='R' and #f==3 and ({approved=true,pending=true,open=true})[f[3]] and not personal.releases[f[2]] then personal.releases[f[2]]=f[3]
        elseif f[1]=='C' and #f==8 and (f[7]=='0' or f[7]=='1') and (f[8]=='0' or f[8]=='1') then
            local starts=f[6]~='' and tonumber(f[6]) or nil
            if f[6]~='' and (not starts or starts<1 or starts>4102444800 or starts~=math.floor(starts)) then error('Ungültiger Raidtermin.') end
            personal.calendar[#personal.calendar+1]={id=f[2],name=f[3],date=f[4],clock=f[5],startsAt=starts,hasPrio=f[7]=='1',needsPrio=f[8]=='1'}
        elseif f[1]=='E' and #f==6 and (f[2]=='reset' or f[2]=='dmf') then
            local starts=tonumber(f[6]);if not starts or starts<1 or starts>4102444800 or starts~=math.floor(starts) then error('Ungültiger Resettermin.') end
            personal.events[#personal.events+1]={kind=f[2],name=f[3],date=f[4],clock=f[5],startsAt=starts}
        elseif f[1]=='H' and #f==6 and ({P1=true,P2=true,P3=true,P0=true,['P0+']=true})[f[4]] then
            local entered=f[6]~='' and tonumber(f[6]) or nil
            if f[6]~='' and (not entered or entered<1 or entered>4102444800 or entered~=math.floor(entered)) then error('Ungültiger Prio-Zeitpunkt.') end
            if #personal.history>=5000 then error('Zu viele persönliche Prios.') end
            personal.history[#personal.history+1]={raid=f[2],raidDate=f[3],priority=f[4],itemName=f[5],createdAt=entered}
        elseif f[1]=='PRIOS' and #f==2 and not prios then prios=GL.ParsePriorities(f[2])
        elseif f[1]=='POINTS' and #f==2 and not points and f[2]:match('^GLPA1\n') then points,total,guild=GL.ParseAllPoints(f[2])
        else error('Ungültiger oder doppelter Abschnitt im persönlichen Export.') end
    end
    if not points or guild~=h[2] or (prios and prios.guild~=h[2]) then error('Unvollständiger Export oder abweichende Gilde.') end
    -- Validate every section before committing any state.
    if prios then GL.StoreGuildData(guild,'priorities',prios) end
    GL.StoreGuildData(guild,'pointRaids',points)
    local profile=GL.db.guildProfiles[guild];profile.personal=profile.personal or {}
    local previous=profile.personal[personal.player..'\031'..personal.realm]
    personal.reminded=previous and previous.reminded or {}
    profile.personal[personal.player..'\031'..personal.realm]=personal
    profile.personalSelection=personal.player..'\031'..personal.realm
    GL.pointRaid=nil
    return (prios and #prios.rows or 0)+total+#personal.history
end
local function playerIdentity()
    local name,realm
    if UnitFullName then name,realm=UnitFullName('player') end
    name=name or UnitName('player');if not realm or realm=='' then realm=(GetRealmName and GetRealmName()) or '' end
    return name,realm
end
local function normalized(s) return tostring(s or ''):lower():gsub('%s','') end
function GL.MyProfile()
    local profile=GL.db.guildProfiles[GL.db.selectedGuild];if not profile then return nil end
    local name,realm=playerIdentity()
    for _,p in pairs(profile.personal or {}) do
        if normalized(name)==normalized(p.player) and normalized(realm)==normalized(p.realm) then return p end
    end
end
function GL.DisplayProfile()
    local profile=GL.db.guildProfiles[GL.db.selectedGuild];if not profile then return nil end
    local selected=profile.personal and profile.personal[profile.personalSelection]
    if selected then return selected end
    local current=GL.MyProfile();if current then return current end
    local newest
    for _,p in pairs(profile.personal or {}) do if not newest or p.exportedAt>newest.exportedAt then newest=p end end
    return newest
end
function GL.CyclePersonalProfile()
    local profile=GL.db.guildProfiles[GL.db.selectedGuild];if not profile then return end
    local keys={};for key in pairs(profile.personal or {}) do keys[#keys+1]=key end;table.sort(keys)
    if #keys==0 then return end
    local shown=GL.DisplayProfile();local index=0
    for i,key in ipairs(keys) do if profile.personal[key]==shown then index=i end end
    profile.personalSelection=keys[index%#keys+1]
end
function GL.MyOverview()
    local p=GL.DisplayProfile()
    if not p then return 'Für diesen Charakter ist noch kein persönlicher Export importiert.\n\nAuf der Lootseite anmelden, diesen Charakter auswählen und „Mein GuildLoot“ exportieren.\nAnschließend hier unter Daten importieren einfügen.\n\nDer Ausrüstungsmanager ist oben über Ausrüstung erreichbar.' end
    local out={'ANSICHT: '..p.player..' – '..p.realm,'Stand: '..date('%d.%m.%Y %H:%M',p.exportedAt)..' (letzter Import)','','P0-FREIGABEN'}
    local labels={recruit='Rekrutenstatus',p1p3='P1–P3',mc='MC',bwl='BWL',aq40='AQ40',aq20='AQ20',naxx='Naxx',ony='Onyxia',zg='ZG',['zg-mittwoch']='ZG Mittwoch',['zg-prime']='ZG Prime',['zg-late']='ZG Late'}
    local statuses={approved='|cff79e6a2Freigegeben|r',pending='|cffffcc40In Prüfung|r',open='|cff9aabbcOffen|r'}
    local keys={};for key in pairs(p.releases) do keys[#keys+1]=key end;table.sort(keys)
    for _,key in ipairs(keys) do out[#out+1]=(labels[key] or key)..': '..statuses[p.releases[key]] end
    out[#out+1]='';out[#out+1]='MEINE RAID-PRIOS'
    local prios=GL.db.priorities;local hasPrio=false
    if prios then
        out[#out+1]=(prios.raidName or '')..' · '..(prios.raidDate or '')
        for _,r in ipairs(prios.rows) do
            if r.priority~='Punkte' and normalized(r.player)==normalized(p.player) and normalized(r.realm)==normalized(p.realm) then
                hasPrio=true;out[#out+1]=r.priority..': '..r.itemName
                out[#out+1]=r.createdAt and ('  Eingetragen: '..date('%d.%m.%Y %H:%M',r.createdAt)) or '  Eintragungszeit nicht enthalten'
            end
        end
    end
    if not hasPrio then out[#out+1]='Keine eigenen Prios in der importierten Raid-Liste.' end
    if #(p.history or {})>0 then
        out[#out+1]='';out[#out+1]='AKTUELLE PERSÖNLICHE PRIOS (WEBSITE)'
        for _,r in ipairs(p.history) do
            out[#out+1]=r.raid..' · '..r.raidDate..' · '..r.priority..': '..r.itemName
            out[#out+1]=r.createdAt and ('  Eingetragen: '..date('%d.%m.%Y %H:%M',r.createdAt)) or '  Eintragungszeit nicht enthalten'
        end
    end
    out[#out+1]='';out[#out+1]='MEINE P0+-PUNKTE' 
    local any=false
    for _,raid in ipairs(GL.PointRaids) do
        local data=GL.db.pointRaids and GL.db.pointRaids[raid];local entries={}
        for _,r in ipairs(data and data.rows or {}) do if normalized(r.player)==normalized(p.player) and normalized(r.realm)==normalized(p.realm) then entries[#entries+1]=r end end
        table.sort(entries,function(a,b) return a.itemName<b.itemName end)
        if #entries>0 then any=true;out[#out+1]='';out[#out+1]=labels[raid] or raid
            for _,r in ipairs(entries) do out[#out+1]='  '..r.itemName..'  |cffffcc40'..r.points..' P0+|r' end
        end
    end
    if not any then out[#out+1]='Keine Punkte für diesen Charakter im Export.' end
    out[#out+1]='';out[#out+1]='Ausrüstung und gespeicherte Sets: oben Ausrüstung öffnen.'
    return table.concat(out,'\n')
end
