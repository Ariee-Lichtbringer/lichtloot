local _,GL=...
local window,editor,status,search,contextWindow,priorityView,textScroll,metadata,applyButton,viewMode
local raidTabs,nav,controls={},{},{}
local lastPointRaid="mc"
local lootTable
local sheetView
local syncedPriorityView
local moreOptions=false
local function syncText()
    local profile=GL.db.guildProfiles[GL.db.selectedGuild] or {}
    local data=profile.activeRaids
    local lines={"SYNCHRONISIERUNG · "..GL.GuildName(GL.db.selectedGuild),""}
    lines[#lines+1]=data and ("Geladener Datenstand: "..date("%d.%m.%Y %H:%M:%S",data.exportedAt)) or "Noch kein Datenstand aus GuildLoot Sync geladen."
    local chars=0;for _ in pairs(profile.personal or {}) do chars=chars+1 end
    lines[#lines+1]=chars.." Charaktere · "..(data and #data.rows or 0).." aktive Raids"
    lines[#lines+1]=""
    lines[#lines+1]="ÜBERTRAGUNGEN DIESER GILDE"
    local pending,success,failed,unknown=0,0,0,0
    for id,request in pairs(GL.db.outgoingRequests or {}) do
        if request.guild==GL.db.selectedGuild then
            local receipt=(GL.db.outgoingReceipts or {})[id]
            if not receipt then pending=pending+1 elseif receipt.state=="success" then success=success+1 elseif receipt.state=="failed" then failed=failed+1 else unknown=unknown+1 end
        end
    end
    lines[#lines+1]="Wartend: "..pending.." · Bestätigt: "..success.." · Fehlgeschlagen: "..failed.." · Unklar: "..unknown
    lines[#lines+1]="Status der noch gespeicherten Aufträge; ältere Bestätigungen werden bereinigt."
    lines[#lines+1]=""
    lines[#lines+1]="Die geöffnete Sync-App ruft Daten alle 30 Sekunden ab."
    lines[#lines+1]="1. /reload speichert deine Aufträge für die Sync-App."
    lines[#lines+1]="2. Die Sync-App überträgt sie und zeigt das Ergebnis."
    lines[#lines+1]="3. Ein weiteres /reload lädt Daten und Serverbestätigungen."
    lines[#lines+1]=""
    lines[#lines+1]="Das Addon kann nicht erkennen, ob die Sync-App gerade läuft."
    lines[#lines+1]="Bei Fehlern oder unklarem Ergebnis bitte den Status in GuildLoot Sync prüfen."
    lines[#lines+1]="Download und Einrichtung: "..(GL.GuildSyncURL or "https://lichtloot.de/start.html")
    return table.concat(lines,"\n")
end
local gearView,personalView,calendarView,activeRaidsView
local function message(text) if status then status:SetText(text) end; print("|cff79e6c5GuildLoot:|r "..text) end
local function run(fn) local ok,result=pcall(fn); if not ok then message(tostring(result):gsub("^.-:%d+: ","")) end end
local function refreshControls()
    local guilds=GL.Guilds();local active=GL.Active()
    controls.guildName:SetWidth(460);controls.guildName:SetWordWrap(false);controls.guildName:SetText("GILDE: "..GL.GuildName(GL.db.selectedGuild)..(active and "  ·  Aufzeichnung läuft" or ""))
    local guildWidth=controls.guildName.GetStringWidth and controls.guildName:GetStringWidth() or 190
    controls.whisperShortcut:ClearAllPoints();controls.whisperShortcut:SetPoint('LEFT',controls.guildName,'LEFT',math.min(460,guildWidth)+8,0)
    controls.guildPrevious:SetEnabled(#guilds>1 and not active);controls.guildNext:SetEnabled(#guilds>1 and not active)
    controls.updateAddon:SetShown(viewMode=='home')
    controls.syncHelp:SetShown(viewMode=='sync' and not moreOptions)
    controls.personalCharacter:Hide()
    local list=viewMode=="prios"
    local points=list and GL.pointRaid~=nil
    for _,b in ipairs(raidTabs) do b:SetShown(points);b:Select(b.raid==GL.pointRaid) end
    local synced=viewMode=="raidlist" or viewMode=="masterlist"
    local master=viewMode=="masterlist" or viewMode=="log" or viewMode=="export" or viewMode=="prio3"
    local raidSection=list or viewMode=="raidlist" or viewMode=="sheet" or viewMode=="archive"
    nav.master:Select(master or viewMode=="masterlocked")
    controls.unlock:SetShown(viewMode=="masterlocked")
    controls.archive:SetShown(raidSection);controls.archive:Select(viewMode=="archive")
    controls.archiveManual:SetShown(viewMode=="log")
    controls.sheet:SetShown(raidSection);controls.sheet:Select(viewMode=="sheet")
    nav.raids:Select(raidSection)
    for _,b in ipairs({nav.prios,nav.points}) do b:SetShown(raidSection) end
    nav.log:SetShown(master);nav.masterList:SetShown(master);nav.masterList:Select(viewMode=="masterlist")
    controls.publish:SetShown(master)
    controls.prio3:SetShown(master)
    controls.prio3:ClearAllPoints();controls.prio3:SetPoint("TOPLEFT",master and 690 or 468,-128)
    nav.active:Select(viewMode=="active");nav.calendar:Select(viewMode=="calendar");nav.home:Select(viewMode=="home" or viewMode=="gear");nav.home.text:SetText(GL.db.selectedGuild=="nachtloot" and "Mein Nachtloot" or GL.db.selectedGuild=="lichtloot" and "Mein Lichtloot" or "Mein GuildLoot");
    metadata:SetShown(viewMode~="sheet" and not synced and viewMode~="gear" and viewMode~="home" and viewMode~="calendar" and viewMode~="active")
    nav.prios:Select((list and not points) or viewMode=="raidlist");nav.points:Select(points);nav.log:Select(viewMode=="log" or viewMode=="export");nav.import:Select(viewMode=="import" or viewMode=="sync")
    controls.more:SetShown(viewMode=="sync" or viewMode=="import")
    controls.manualImport:SetShown((viewMode=="sync" or viewMode=="import") and moreOptions)
    controls.manualExport:SetShown((viewMode=="sync" or viewMode=="import") and moreOptions)
    search:SetShown(list);controls.searchLabel:SetShown(list);controls.clear:SetShown(list)
    controls.start:SetShown(viewMode=="log");controls.stop:SetShown(viewMode=="log");controls.export:SetShown(viewMode=="log")
    controls.buffReport:SetShown(viewMode=="log")
    controls.upload:SetShown(viewMode=="log" or viewMode=="export");controls.upload:SetEnabled(GL.Current()~=nil and not GL.Active())
    controls.start:SetEnabled(not GL.Active());controls.stop:SetEnabled(GL.Active()~=nil)
    controls.sync:SetShown(list and not points);controls.bind:SetShown(list and not points and GL.db.priorities and GL.db.priorities.legacy or false)
    controls.hint:SetShown(viewMode~="sheet" and not synced and not points and viewMode~="gear" and viewMode~="home" and viewMode~="calendar" and viewMode~="active")
    controls.hint:SetText(viewMode=="import" and "1. Website-Export kopieren     2. Hier einfügen     3. Import übernehmen" or viewMode=="log" and (GL.Active() and (GL.InInstance(GL.Active()) and "|cff79e6a2Aufzeichnung läuft|r · Drops und empfangene Beute werden mitgeschrieben." or "Aufzeichnung vorbereitet · Warte auf Eintritt in die passende Raidinstanz.") or "Keine Aufzeichnung aktiv · Raid unter Prioliste auswählen; Start auch vor dem Eingang möglich.") or viewMode=="archive" and "Raidarchiv · Gespeicherte Protokolle bleiben erhalten. Erfolgreiche Sync-Uploads werden automatisch archiviert." or viewMode=="sync" and "Automatische Datenübertragung mit GuildLoot Sync" or viewMode=="prio3" and "Prio3-CSV: Spieler;Klasse;P1-ID;P2-ID;P3-ID · Markieren und kopieren" or viewMode=="export" and "Export markieren und auf der Gildenleitungsseite einfügen." or "|cff79e6a2P0 / P0+ gesetzt|r = gesetzte Raid-Prio     |cffffcc40Gold|r = importierter Punktestand")
end
local function showText(text,mode)
    mode=mode or "log"
    if mode=="export" and #text>32000 then
        text="Das Lootprotokoll ist für die Textanzeige zu groß. Bitte Protokoll hochladen verwenden. Die vollständigen Lootdaten werden ohne Textanzeige an GuildLoot Sync übergeben."
    end
    if lootTable then lootTable:Hide() end
    if sheetView then sheetView:Hide() end
    if (mode=="log" or mode=="export" or mode=="masterlist" or mode=="prio3") and not GL.HasMasterAccess(GL.masterRaidId) then
        mode="masterlocked";text="Plündermeisterbereich gesperrt.\n\nBitte den Lead-PIN des Raids oder den Gildenleitungs-PIN eingeben.\nDie Website prüft den Zugang über die Sync-App.\n\nRaid-Freigaben gelten acht Stunden. Der Gildenleitungszugang kann dauerhaft in GuildLoot Sync gespeichert werden."
    end
    if syncedPriorityView then syncedPriorityView:Hide() end
    if activeRaidsView then activeRaidsView:Hide() end
    if personalView then personalView:Hide() end
    if calendarView then calendarView:Hide() end
    if mode=="log" or mode=="archive" then
        if gearView then gearView:Hide() end
        viewMode=mode;priorityView:Hide();textScroll:Hide();applyButton:Hide();editor:ClearFocus()
        if not lootTable then lootTable=GL.CreateLootTable(window) end
        lootTable.archived=mode=="archive";lootTable:ClearAllPoints();lootTable:SetPoint("TOPLEFT",24,mode=="archive" and -284 or -326);lootTable:Show();lootTable:Refresh();metadata:SetText("");refreshControls();return
    end
    if mode=="sheet" then
        if gearView then gearView:Hide() end
        viewMode="sheet";priorityView:Hide();textScroll:Hide();applyButton:Hide();editor:ClearFocus()
        if not sheetView then sheetView=GL.CreateRaidSheetView(window) end
        sheetView:Show();sheetView:Refresh();refreshControls();return
    end
    if mode=="raidlist" or mode=="masterlist" then
        if gearView then gearView:Hide() end
        viewMode=mode;priorityView:Hide();textScroll:Hide();applyButton:Hide();editor:ClearFocus()
        if not syncedPriorityView then syncedPriorityView=GL.CreateSyncedPriorityView(window) end
        syncedPriorityView.master=mode=="masterlist";syncedPriorityView:Show();syncedPriorityView:Refresh();refreshControls();return
    end
    if mode=="active" then
        if gearView then gearView:Hide() end
        viewMode="active";priorityView:Hide();textScroll:Hide();applyButton:Hide();editor:ClearFocus()
        if not activeRaidsView then activeRaidsView=GL.CreateActiveRaidsView(window) end
        activeRaidsView:Show();activeRaidsView:Refresh();refreshControls();return
    end
    if mode=="calendar" then
        if gearView then gearView:Hide() end
        viewMode="calendar";priorityView:Hide();textScroll:Hide();applyButton:Hide();editor:ClearFocus()
        if not calendarView then calendarView=GL.CreateCalendarView(window) end
        calendarView:Show();calendarView:Refresh();refreshControls();return
    end
    if mode=="home" then
        if gearView then gearView:Hide() end
        viewMode="home";priorityView:Hide();textScroll:Hide();applyButton:Hide();editor:ClearFocus()
        if not personalView then personalView=GL.CreatePersonalView(window,{gear=function() GL.ShowGearForItem() end,calendar=function() if RequestRaidInfo then RequestRaidInfo() end;showText(GL.CalendarText(),"calendar") end}) end
        personalView:Show();personalView:Refresh(true);refreshControls();return
    end
    if gearView then gearView:Hide() end
    viewMode=mode or "log";priorityView:Hide();textScroll:Show();applyButton:SetShown(viewMode=="import")
    editor:Show();editor:SetHeight(360);editor:SetText(text);editor:SetCursorPosition(0);textScroll:SetVerticalScroll(0);editor:ClearFocus()
    metadata:SetText(viewMode=="sync" and "Datenstand und Übertragungsstatus\nManueller Import und Export unter Weitere Optionen" or viewMode=="calendar" and "Raidkalender\nLive-Raid-IDs, persönliche Anmeldungen und EU-Terminplanung" or viewMode=="home" and "Dein persönlicher Bereich\nFreigaben und Punkte gehören zur ausgewählten Gilde und deinem aktuellen Charakter." or viewMode=="import" and "Prios oder alle P0+-Punkte importieren\nRaid-Prios: Gildenleitung · Alle Punkte: Startseite → P0+-Fenster" or viewMode=="prio3" and "Prio3-Export\nCSV wie auf GuildLoot · nur veröffentlichte oder vollständig importierte Prios" or viewMode=="export" and "Raid-Export\nDen vollständigen Text kopieren." or "Deine Raidprotokolle\nAufgezeichnete Beute und Empfänger")
    refreshControls()
end
local function showPrios(term)
    if lootTable then lootTable:Hide() end
    if sheetView then sheetView:Hide() end
    if not GL.pointRaid and ((GL.db.guildProfiles[GL.db.selectedGuild] or {}).activeRaids) then showText("","raidlist");return end
    if syncedPriorityView then syncedPriorityView:Hide() end
    if activeRaidsView then activeRaidsView:Hide() end
    if calendarView then calendarView:Hide() end
    if personalView then personalView:Hide() end
    if gearView then gearView:Hide() end
    viewMode="prios";textScroll:Hide();applyButton:Hide();editor:ClearFocus();priorityView:Show()
    local count=priorityView:Refresh(term or "")
    local p=GL.DisplayPriorities()
    metadata:SetText(p and ((p.raidName or "Raid").." · "..p.guild.."   |   "..count.." Items\n"..(GL.pointRaid and "Punkteübersicht · keine Raid-Anmeldungen" or "Raid vom "..p.raidDate).." · "..(p.legacy and "Punkte nicht enthalten" or "Stand "..date("%d.%m.%Y %H:%M",p.exportedAt))) or (GL.pointRaid and "Noch keine Punkte importiert\nStartseite → P0+-Fenster → Alle Raid-Punkte fürs Addon" or "Noch keine Raid-Prios importiert\nGildenleitung → Raid öffnen → GuildLoot-Export"))
    refreshControls()
end
local function showGear(item)
    if lootTable then lootTable:Hide() end
    if sheetView then sheetView:Hide() end
    if syncedPriorityView then syncedPriorityView:Hide() end
    if activeRaidsView then activeRaidsView:Hide() end
    if calendarView then calendarView:Hide() end
    if personalView then personalView:Hide() end
    viewMode="gear";priorityView:Hide();textScroll:Hide();applyButton:Hide();editor:ClearFocus()
    if not gearView then gearView=GL.CreateGearView(window,message) end
    gearView:Show();gearView:Refresh();refreshControls()
    if item then gearView:PreviewItem(item) end
end
function GL.ShowGearForItem(item) GL.Show();run(function() showGear(item) end) end
function GL.Show()
    if not GL.db then print("GuildLoot ist noch nicht geladen.");return end
    if window then window:Show();refreshControls();return end
    window=CreateFrame("Frame","GuildLootEraWindow",UIParent,"BasicFrameTemplateWithInset")
    window:SetSize(940,740);window:SetScale(math.min(1.15,(UIParent:GetWidth()-32)/940,(UIParent:GetHeight()-32)/740));window:SetPoint("CENTER");window:SetClampedToScreen(true)
    window:SetMovable(true);window:EnableMouse(true);window:RegisterForDrag("LeftButton")
    window:SetScript("OnDragStart",window.StartMoving);window:SetScript("OnDragStop",window.StopMovingOrSizing)
    if GL.EnableMainWindowSizing then GL.EnableMainWindowSizing(window) end
    window.TitleText:SetText("GuildLoot Era · "..GL.version);tinsert(UISpecialFrames,"GuildLootEraWindow")
    local surface=window:CreateTexture(nil,"BACKGROUND");surface:SetPoint("TOPLEFT",8,-28);surface:SetPoint("BOTTOMRIGHT",-8,8);surface:SetColorTexture(.025,.045,.065,.96)
    local function label(x,y,width,size)
        local l=window:CreateFontString(nil,"OVERLAY","GameFontHighlight");l:SetFont(STANDARD_TEXT_FONT,size or 13);l:SetPoint("TOPLEFT",x,y-40);l:SetWidth(width);l:SetJustifyH("LEFT");l:SetTextColor(.65,.74,.82);return l
    end
    local function button(title,x,y,width,fn)
        local b=CreateFrame("Button",nil,window);b:SetSize(width,26);b:SetPoint("TOPLEFT",x,y-40)
        b.bg=b:CreateTexture(nil,"BACKGROUND");b.bg:SetAllPoints()
        b.accent=b:CreateTexture(nil,"ARTWORK");b.accent:SetPoint("BOTTOMLEFT");b.accent:SetPoint("BOTTOMRIGHT");b.accent:SetHeight(2);b.accent:SetColorTexture(.95,.75,.25,1)
        b.text=b:CreateFontString(nil,"OVERLAY","GameFontHighlight");b.text:SetFont(STANDARD_TEXT_FONT,12);b.text:SetPoint("CENTER");b.text:SetText(title)
        function b:Select(active) self.selected=active;self.bg:SetColorTexture(active and .18 or .08,active and .23 or .12,active and .26 or .16,1);self.accent:SetShown(active);self.text:SetTextColor(active and 1 or .78,active and .84 or .84,active and .4 or .9) end
        b:Select(false)
        b:SetScript("OnEnter",function(self) self.bg:SetColorTexture(.18,.25,.3,1) end)
        b:SetScript("OnLeave",function(self) self:Select(self.selected) end)
        b:SetScript("OnEnable",function(self) self:SetAlpha(1) end);b:SetScript("OnDisable",function(self) self:SetAlpha(.4) end)
        b:SetScript("OnClick",function() run(fn) end);if GL.GateSyncButton then GL.GateSyncButton(b,title) end;return b
    end
    local function changeGuild(direction)
        local guilds=GL.Guilds();if #guilds==0 then return end
        local index=1;for i,key in ipairs(guilds) do if key==GL.db.selectedGuild then index=i end end
        GL.SelectGuild(guilds[(index-1+direction)%#guilds+1]);GL.masterRaidId=nil
        search:SetText("");showText(GL.MyOverview(),"home");message("Gilde gewechselt: "..GL.GuildName(GL.db.selectedGuild))
    end
    controls.guildName=label(24,-9,650,15)
    controls.whisperShortcut=CreateFrame('Button',nil,window);controls.whisperShortcut:SetSize(28,28)
    local whisperIcon=controls.whisperShortcut:CreateTexture(nil,'ARTWORK');whisperIcon:SetAllPoints();whisperIcon:SetTexture('Interface\\ChatFrame\\UI-ChatIcon-Chat-Up')
    controls.whisperShortcut:SetScript('OnClick',function() run(function() local shown=GL.Whispers.ToggleLauncher();message(shown and 'Whisper-Symbol eingeblendet. Darüber öffnest du deine Gespräche.' or 'Whisper-Symbol ausgeblendet. /gl whisper öffnet weiterhin den Chat.') end) end)
    controls.whisperShortcut:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText('Whisper-Symbol ein- / ausblenden');GameTooltip:Show() end)
    controls.whisperShortcut:SetScript('OnLeave',function() GameTooltip:Hide() end)
    controls.sheetToggle=CreateFrame('Button',nil,window);controls.sheetToggle:SetSize(28,28)
    controls.sheetToggle:SetPoint('LEFT',controls.whisperShortcut,'RIGHT',34,0)
    local sheetIcon=controls.sheetToggle:CreateTexture(nil,'ARTWORK');sheetIcon:SetAllPoints();sheetIcon:SetTexture('Interface\\AddOns\\GuildLootEra\\Media\\GuildLootLogo');sheetIcon:SetTexCoord(0,.37,0,1)
    controls.sheetToggle:SetScript('OnClick',function() run(function() local shown=GL.ToggleSheetShortcut();message(shown and 'Sheet-Symbol eingeblendet. Ziehen zum Verschieben, klicken zum Öffnen.' or 'Sheet-Symbol ausgeblendet.') end) end)
    controls.sheetToggle:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText('Sheet-Symbol ein- / ausblenden');GameTooltip:Show() end)
    controls.sheetToggle:SetScript('OnLeave',function() GameTooltip:Hide() end)
    controls.professionToggle=CreateFrame('Button',nil,window);controls.professionToggle:SetSize(28,28);controls.professionToggle:SetPoint('LEFT',controls.sheetToggle,'RIGHT',34,0)
    local professionIcon=controls.professionToggle:CreateTexture(nil,'ARTWORK');professionIcon:SetAllPoints();professionIcon:SetTexture('Interface\\AddOns\\GuildLootEra\\Media\\GuildSkills')
    controls.professionToggle:SetScript('OnClick',function() run(function() local shown=GL.ToggleProfessionShortcut();message(shown and 'Berufe-Symbol eingeblendet. Ziehen zum Verschieben, klicken zum Öffnen.' or 'Berufe-Symbol ausgeblendet.') end) end)
    controls.professionToggle:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText('Berufe-Symbol ein- / ausblenden');GameTooltip:Show() end)
    controls.professionToggle:SetScript('OnLeave',function() GameTooltip:Hide() end)
    controls.raidcheckToggle=CreateFrame('Button',nil,window);controls.raidcheckToggle:SetSize(28,28);controls.raidcheckToggle:SetPoint('LEFT',controls.professionToggle,'RIGHT',34,0)
    local raidcheckIcon=controls.raidcheckToggle:CreateTexture(nil,'ARTWORK');raidcheckIcon:SetAllPoints();raidcheckIcon:SetTexture('Interface\\AddOns\\GuildLootEra\\Media\\GuildRaidBag')
    controls.raidcheckToggle:RegisterForClicks('LeftButtonUp','RightButtonUp')
    controls.raidcheckToggle:SetScript('OnClick',function(_,which) if which=='RightButton' then GL.RaidChecklist.Report();return end;run(function() local shown=GL.RaidChecklist.ToggleLauncher();message(shown and 'Raidcheck-Symbol eingeblendet. Ziehen zum Verschieben, klicken zum Öffnen.' or 'Raidcheck-Symbol ausgeblendet. /glcheck öffnet weiterhin die Checkliste.') end) end)
    controls.raidcheckToggle:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText('Linksklick: Raidcheck-Symbol ein- / ausblenden');GameTooltip:AddLine('Rechtsklick: Checkliste prüfen und Ergebnis im Chat anzeigen.',1,1,1,true);GameTooltip:Show() end)
    controls.raidcheckToggle:SetScript('OnLeave',function() GameTooltip:Hide() end)
    controls.buffToggle=CreateFrame('Button',nil,window);controls.buffToggle:SetSize(28,28);controls.buffToggle:SetPoint('LEFT',controls.raidcheckToggle,'RIGHT',34,0)
    local buffIcon=controls.buffToggle:CreateTexture(nil,'ARTWORK');buffIcon:SetAllPoints();buffIcon:SetTexture('Interface\\AddOns\\GuildLootEra\\Media\\GuildBuff')
    controls.buffToggle:RegisterForClicks('LeftButtonUp','RightButtonUp')
    controls.buffToggle:SetScript('OnClick',function(_,which) run(function() if which=='RightButton' then GL.Buffs.ShowReport();return end;GL.ToggleBuffs() end) end)
    controls.buffToggle:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText('Linksklick: Buffleiste öffnen / schließen');GameTooltip:AddLine('Rechtsklick: Buffübersicht des Raids. Auch per /gle buffs oder Rechtsklick auf das Minimap-Symbol.',1,1,1,true);GameTooltip:Show() end)
    controls.buffToggle:SetScript('OnLeave',function() GameTooltip:Hide() end)



    -- Mini-addon checkboxes reuse the existing persisted launcher settings.
    local function miniCheck(icon,title,isEnabled)
      local check=CreateFrame('CheckButton',nil,window,'UICheckButtonTemplate');check:SetSize(24,24);check:SetPoint('LEFT',icon,'RIGHT',2,0)
      local function update()check:SetChecked(isEnabled()==true)end
      check:SetScript('OnClick',function()local handler=icon:GetScript('OnClick');if handler then handler(icon,'LeftButton')end;update()end)
      check:SetScript('OnEnter',function(self)GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText(title);GameTooltip:AddLine('Haken an: Mini-Addon-Symbol anzeigen. Haken aus: Symbol ausblenden. Deine Auswahl wird gespeichert.',1,1,1,true);GameTooltip:Show()end)
      check:SetScript('OnLeave',function()GameTooltip:Hide()end)
      local elapsed=0;check:SetScript('OnUpdate',function(_,dt)elapsed=elapsed+dt;if elapsed>=.25 then elapsed=0;update()end end)
      icon:HookScript('OnClick',update);check:SetScript('OnShow',update);update();return check
    end
    controls.whisperEnabled=miniCheck(controls.whisperShortcut,'Whisper',function()return GL.Whispers and GL.Whispers.db and GL.Whispers.db.launcherShown==true end)
    controls.sheetEnabled=miniCheck(controls.sheetToggle,'Raidsheets',function()return GL.db.sheetShortcutShown~=false end)
    controls.professionEnabled=miniCheck(controls.professionToggle,'Berufe',function()local s=GL.db.professionShortcuts;local p=s and s[UnitGUID('player')or 'player'];return p and p.shown==true end)
    controls.raidcheckEnabled=miniCheck(controls.raidcheckToggle,'RaidCheck',function()return GL.RaidChecklist.Store().launcherShown~=false end)
    controls.buffEnabled=miniCheck(controls.buffToggle,'Buffs',function()return GL.db.buffPanelVisible==true end)

    controls.guildPrevious=button("<",750,-4,44,function() changeGuild(-1) end)
    controls.guildNext=button("Nächste Gilde >",802,-4,112,function() changeGuild(1) end)
    controls.syncHelp=button('Sync-App herunterladen',270,-88,260,function() GL.ShowGuildSyncHelp() end)
    controls.updateAddon=button('Addon aktualisieren',24,-88,230,function() run(function() GL.QueueWebsiteAction({id='addon-update'},'update',{});message('Update angefordert. /reload eingeben; GuildLoot Sync ab 0.3.5 muss geöffnet sein. Danach WoW neu starten.') end) end)
    nav.home=button("Mein GuildLoot",24,-44,154,function() showText(GL.MyOverview(),"home") end)
    nav.active=button("Aktive Raids",186,-44,146,function() showText("","active") end)
    nav.raids=button("Raids",340,-44,92,function() GL.pointRaid=nil;showPrios(search:GetText()) end)
    nav.calendar=button("Kalender",622,-44,112,function() if RequestRaidInfo then RequestRaidInfo() end;showText(GL.CalendarText(),"calendar") end)
    nav.master=button("Plündermeister",440,-44,174,function() GL.ShowMaster() end)
    controls.unlock=button("Mit PIN entsperren",24,-88,260,function() GL.ShowMasterAccessDialog() end)
    controls.archive=button("Raidarchiv",690,-88,224,function() showText("","archive") end)
    controls.sheet=button("Raidsheet",468,-88,210,function() GL.ShowRaidSheet() end)
    controls.publish=button("Prio öffnen",468,-88,210,function() GL.ShowPublishDialog() end)
    controls.prio3=button("Prio3 exportieren",468,-88,210,function() GL.ShowPrio3Export() end)
    nav.prios=button("Raid-Prios",24,-88,210,function() GL.pointRaid=nil;showPrios(search:GetText()) end)
    nav.points=button("P0+-Punkte",246,-88,210,function() GL.pointRaid=lastPointRaid;showPrios(search:GetText()) end)
    nav.masterList=button("Prioliste",246,-88,210,function() showText("","masterlist") end)
    nav.log=button("Raidprotokoll",24,-88,210,function() showText(GL.HistoryText(),"log") end)
    nav.import=button("Synchronisierung",742,-44,172,function() moreOptions=false;showText(syncText(),"sync") end)
    controls.more=button("Weitere Optionen",24,-88,210,function() moreOptions=not moreOptions;refreshControls() end)
    controls.manualImport=button("Manuell importieren",246,-88,210,function() showText("","import");editor:SetFocus() end)
    controls.manualExport=button("Raid manuell exportieren",468,-88,230,function() showText(GL.Export(nil,true),"export");editor:SetFocus();editor:HighlightText() end)
    controls.personalCharacter=button("Importierten Charakter wechseln",24,-106,310,function()
        GL.CyclePersonalProfile()
        if viewMode=="calendar" then showText(GL.CalendarText(),"calendar") else showText(GL.MyOverview(),"home") end
    end)
    controls.searchLabel=label(24,-138,420,12);controls.searchLabel:SetText("ITEM ODER SPIELER SUCHEN")
    search=CreateFrame("EditBox",nil,window,"InputBoxTemplate");search:SetSize(400,28);search:SetPoint("TOPLEFT",30,-196);search:SetAutoFocus(false)
    search:SetScript("OnTextChanged",function(self) if viewMode=="prios" then showPrios(self:GetText()) end end)
    search:SetScript("OnEnterPressed",function(self) self:ClearFocus() end)
    controls.clear=button("Zurücksetzen",446,-154,124,function() search:SetText("") end)
    controls.sync=button("Raid synchronisieren",720,-154,194,function() GL.RequestSync();message(GL.CaptureStatus()) end)
    controls.bind=button("Raid zuordnen",580,-154,130,function() GL.ShowRaidContext() end)
    controls.start=button("Aufzeichnung starten",24,-154,210,function() if not GL.HasMasterAccess(GL.masterRaidId) then GL.ShowMaster();return end;GL.Start();showText(GL.HistoryText(),"log");message("Raidaufzeichnung gestartet.") end)
    controls.buffReport=button("Buffübersicht",470,-154,180,function() GL.Buffs.ShowHistory() end)
    controls.stop=button("Aufzeichnung beenden",246,-154,210,function() GL.Stop();showText(GL.HistoryText(),"log");message("Raid gespeichert.") end)
    controls.export=button("Raid exportieren",720,-154,194,function() showText(GL.Export(nil,true),"export");editor:SetFocus();editor:HighlightText() end)
    controls.archiveManual=button("Ins Archiv verschieben",24,-228,250,function() local r=lootTable and lootTable:GetRecording();GL.ArchiveRecording(r,'manual');showText("","log");message("Protokoll archiviert. Unter Raids → Raidarchiv weiter einsehbar. Kein Upload ausgelöst.") end)
    controls.upload=button("Protokoll hochladen",650,-228,264,function() GL.ShowUploadDialog() end)
    controls.hint=label(24,-202,890,12)
    local tabLabels={mc="MC",bwl="BWL",ony="Onyxia",zg="ZG",aq20="AQ20",aq40="AQ40",naxx="Naxx",["zg-mittwoch"]="ZG Mi.",["zg-prime"]="ZG Prime",["zg-late"]="ZG Late"}
    for i,key in ipairs(GL.PointRaids) do
        local raid=key
        local tab=button(tabLabels[raid],24+(i-1)*89,-194,84,function() GL.pointRaid=raid;lastPointRaid=raid;showPrios(search:GetText()) end)
        tab.raid=raid;raidTabs[#raidTabs+1]=tab
    end
    metadata=label(24,-238,890,13)
    priorityView=GL.CreatePriorityView(window)
    textScroll=CreateFrame("ScrollFrame",nil,window,"UIPanelScrollFrameTemplate");textScroll:SetPoint("TOPLEFT",28,-334);textScroll:SetPoint("BOTTOMRIGHT",-42,90)
    editor=CreateFrame("EditBox",nil,textScroll);editor:SetMultiLine(true);editor:SetHeight(360);editor:SetPoint("TOPLEFT",0,0);editor:SetFontObject(ChatFontNormal);editor:SetWidth(850);editor:SetAutoFocus(false);editor:SetMaxLetters(0)
    editor:SetScript("OnEscapePressed",function(self) self:ClearFocus() end);textScroll:SetScrollChild(editor)
    applyButton=button("Import übernehmen",24,-620,210,function() local n=GL.Import(editor:GetText());search:SetText("");if GL.DisplayProfile() then showText(GL.MyOverview(),"home") else showPrios("") end;message(n.." Einträge importiert.") end)
    window:RegisterEvent("UPDATE_INSTANCE_INFO");window:SetScript("OnEvent",function() if viewMode=="calendar" then run(function() showText(GL.CalendarText(),"calendar") end) end end)
    status=label(24,-672,730,12);status:SetText("Item-Tooltip: Maus über das Item · Mausrad: blättern · Fenster am Titel verschieben · Größe unten rechts ändern")
    local copyright=window:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");copyright:SetPoint("BOTTOMLEFT",24,14);copyright:SetText("© Ariee - Everlook")
    showText(GL.MyOverview(),"home")
end
function GL.ShowPrio3Export(raidId)
    raidId=raidId or GL.masterRaidId
    if not GL.HasMasterAccess(raidId) then GL.ShowMaster();return end
    GL.Show();run(function() showText(GL.ExportPrio3(raidId),"prio3");editor:SetFocus();editor:HighlightText() end)
end
function GL.ShowPublishDialog(accessOnly)
    if GL.HasGuildSync and not GL.HasGuildSync() then GL.ShowGuildSyncHelp();return end
    local data=(GL.db.guildProfiles[GL.db.selectedGuild] or {}).activeRaids or {};local rows=data.rows or {}
    if #rows==0 then error("Bitte zuerst aktive Raids synchronisieren.") end
    local f=CreateFrame("Frame",nil,UIParent,"BasicFrameTemplateWithInset");f:SetSize(540,300);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:EnableMouse(true)
    f.TitleText:SetText(accessOnly and "Plündermeisterzugang" or "Prio auf GuildLoot öffnen")
    local index=1;local selected
    for i,raid in ipairs(rows) do if raid.id==GL.masterRaidId then index=i end end
    local choose=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");choose:SetPoint("TOPLEFT",20,-50);choose:SetSize(500,32)
    local info=f:CreateFontString(nil,"OVERLAY","GameFontHighlight");info:SetPoint("TOPLEFT",20,-92);info:SetWidth(500);info:SetJustifyH("LEFT")
    local function refresh() selected=rows[index];GL.masterRaidId=selected.id;choose:SetText(selected.name.." · "..selected.date.." "..selected.clock.." >");info:SetText(GL.GuildName(GL.db.selectedGuild)..(GL.HasPersistentMasterAccess() and " · Gespeicherter Zugang: PIN-Feld leer lassen.\n" or " · Lead-PIN oder Gildenleitungs-PIN eingeben:\n")..GL.WebsiteActionStatus(selected.id)) end
    choose:SetScript("OnClick",function() index=index%#rows+1;refresh() end)
    local pin=CreateFrame("EditBox",nil,f,"InputBoxTemplate");pin:SetPoint("TOPLEFT",26,-143);pin:SetSize(485,28);pin:SetAutoFocus(false);pin:SetMaxLetters(100);if pin.SetPassword then pin:SetPassword(true) end
    local send=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");send:SetPoint("TOPLEFT",20,-184);send:SetSize(500,30);send:SetText(accessOnly and "Zugang prüfen" or "Prio auf GuildLoot öffnen")
    send:SetScript("OnClick",function() local secret=(pin:GetText() or ''):gsub('^%s+',''):gsub('%s+$','');if secret=='' and not GL.HasPersistentMasterAccess() then info:SetText('Bitte den Lead-PIN eingeben.');return end
        local ok,err=pcall(GL.QueueWebsiteAction,selected,accessOnly and 'access' or 'publish',{leadPin=secret,useSavedMaster=secret==''});pin:SetText('');pin:ClearFocus()
        info:SetText(ok and 'Vorgemerkt. /reload zum Senden. Serverbestätigung in der Sync-App prüfen.' or tostring(err))
    end)
    local hint=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");hint:SetPoint("TOPLEFT",20,-231);hint:SetWidth(500);hint:SetJustifyH("LEFT");hint:SetText(accessOnly and "Nach /reload prüft die Sync-App den PIN. Danach erneut /reload und Plündermeister öffnen. Gildenleitungszugang bleibt verschlüsselt in GuildLoot Sync gespeichert; der PIN wird aus dem Addonauftrag entfernt." or "Die Website prüft Lead-PIN und Öffnungsfrist. Nach Bestätigung erneut /reload: veröffentlichte Prios und Prio3-Export werden verfügbar.")
    f:SetScript('OnHide',function() pin:SetText('');pin:ClearFocus() end);refresh()
end
function GL.ShowRaidSheet(raidId)
    if GL.HasGuildSync and not GL.HasGuildSync() then GL.ShowGuildSyncHelp();return end
    if raidId then GL.masterRaidId=raidId end
    GL.Show();showText("","sheet")
end
local sheetWindow
function GL.ShowSheetWindow(raidId)
    if raidId then GL.masterRaidId=raidId end
    if not sheetWindow then
        local f=CreateFrame('Frame','GuildLootEraSheetWindow',UIParent,'BasicFrameTemplateWithInset');sheetWindow=f
        f:SetSize(1100,850);f:SetScale(math.min(1,(UIParent:GetWidth()-32)/1100,(UIParent:GetHeight()-32)/850));f:SetPoint('CENTER');f:SetClampedToScreen(true)
        f:SetMovable(true);f:EnableMouse(true);f:RegisterForDrag('LeftButton');f:SetScript('OnDragStart',f.StartMoving);f:SetScript('OnDragStop',f.StopMovingOrSizing)
        f.TitleText:SetText('GuildLoot · Raidsheet');tinsert(UISpecialFrames,'GuildLootEraSheetWindow')
        f.sheet=GL.CreateRaidSheetView(f,true)
    end
    if window then window:Hide() end
    sheetWindow:Show();sheetWindow.sheet:Refresh()
end
function GL.ShowMaster()
    GL.Show()
    local data=(GL.db.guildProfiles[GL.db.selectedGuild] or {}).activeRaids or {}
    GL.masterRaidId=GL.masterRaidId or (data.rows and data.rows[1] and data.rows[1].id)
    showText(GL.HistoryText(),"log")
end
function GL.ShowMasterAccessDialog() GL.ShowPublishDialog(true) end
function GL.ShowRaidContext()
    if contextWindow then contextWindow:Show();return end
    local f=CreateFrame("Frame",nil,UIParent,"BasicFrameTemplateWithInset");contextWindow=f
    f:SetSize(450,290);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:EnableMouse(true)
    f.TitleText:SetText("Prio3-Liste einem GuildLoot-Raid zuordnen")
    local inputs={}
    for i,label in ipairs({"GuildLoot-Gildenkennung (z. B. lichtloot)","Raid-ID von Website / Exportdateiname","Instanz: mc / bwl / ony / zg / aq20 / aq40 / naxx"}) do
        local text=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");text:SetPoint("TOPLEFT",20,-38-(i-1)*62);text:SetText(label)
        local box=CreateFrame("EditBox",nil,f,"InputBoxTemplate");box:SetSize(395,25);box:SetPoint("TOPLEFT",24,-57-(i-1)*62);box:SetAutoFocus(false);inputs[i]=box
    end
    local save=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");save:SetSize(170,26);save:SetPoint("BOTTOM",0,18);save:SetText("Zuordnung übernehmen")
    save:SetScript("OnClick",function() run(function() GL.BindLegacy(inputs[1]:GetText(),inputs[2]:GetText(),inputs[3]:GetText());f:Hide();showPrios("");message("Raid zugeordnet. Punkte sind im Prio3-Export nicht enthalten.") end) end)
end
SLASH_GUILDLOOTERA1="/gle"
SLASH_GUILDLOOTERA2="/guildloot"
SlashCmdList.GUILDLOOTERA=function(input)
    run(function()
        local cmd,arg=(input or ""):match("^(%S*)%s*(.-)$")
        if cmd=="whisper" or cmd=="whispers" then GL.Whispers.Toggle();return end
        if cmd=="buffs" or cmd=="buff" then GL.ToggleBuffs();return end
        if cmd=="berufe" or cmd=="skills" then GL.ShowProfessions();return end
        if cmd=="check" or cmd=="raidcheck" or cmd=="bag" then GL.RaidChecklist.Open();return end
        if cmd=="hilfe" or cmd=="help" or cmd=="?" then
            for _,line in ipairs({"|cffffcc40GuildLoot Befehle:|r","/gle – Hauptfenster","/gle buffs – Buffleiste (auch Rechtsklick auf das Minimap-Symbol)","/gle berufe – Berufsübersicht","/gle check – Raidcheck (auch /glcheck)","/gle whisper – Whisper-Fenster (auch /glw)","/gle kalender – Raidkalender","/gle prios [Suche] – Raid-Prios","/gle status – Aufzeichnungsstatus","/gle bank – Gildenbank-Bestand exportieren (Bankcharaktere, Bank vorher öffnen)","/glarmor – Rüstungsteile beantragen"}) do print(line) end
            return
        end
        GL.Show()
        if cmd=="quelle" then GL.SetSourceName(arg);showText(GL.HistoryText());message("Quellenname gespeichert (manuell).")
        elseif cmd=="sync" then GL.RequestSync();message(GL.CaptureStatus())
        elseif cmd=="status" then message(GL.CaptureStatus())
        elseif cmd=="export" then
            local index=arg~="" and tonumber(arg) or nil
            if arg~="" and (not index or index~=math.floor(index) or not GL.db.raids[index]) then error("Ungültige Protokollnummer.") end
            showText(GL.Export(index,true),"export");editor:SetFocus();editor:HighlightText()
        elseif cmd=="start" then GL.Start();message("Aufzeichnung gestartet.")
        elseif cmd=="stop" then GL.Stop();showText(GL.HistoryText())
        elseif cmd=="prios" then showPrios(arg)
        elseif cmd=="kalender" then showText(GL.CalendarText(),"calendar")
        elseif cmd=="erinnerung" then GL.db.prioReminders=GL.db.prioReminders==false;message(GL.db.prioReminders and "Prio-Erinnerungen aktiviert." or "Prio-Erinnerungen deaktiviert.")
        elseif cmd=="gear" or cmd=="ausruestung" then showGear(arg~="" and arg or nil)
        elseif cmd=="bank" then
            local text,count,missing,age,sources=GL.GuildBankExport()
            showText(text,"export");editor:SetFocus();editor:HighlightText()
            message(count.." Gegenstände exportiert ("..table.concat(sources,", ").."). Text kopieren und auf lichtloot.de unter Gildenleitung → Gildenbank einfügen."..(missing>0 and (" "..missing.." Itemnamen fehlen noch; bei Bedarf /gle bank erneut ausführen.") or ""))
        elseif cmd=="log" then showText(GL.HistoryText()) end
    end)
end

function GL.InitializeMinimap()
    if not Minimap or GL.minimapButton then return end
    local b=CreateFrame('Button','GuildLootEraMinimapButton',Minimap);GL.minimapButton=b
    b:SetSize(32,32);b:SetFrameStrata('MEDIUM');b:SetFrameLevel(Minimap:GetFrameLevel()+8)
    b:RegisterForClicks('LeftButtonUp','RightButtonUp');b:RegisterForDrag('LeftButton');b:EnableMouse(true)
    local icon=b:CreateTexture(nil,'ARTWORK');icon:SetPoint('CENTER',0,0);icon:SetSize(26,28)
    icon:SetTexture('Interface\\AddOns\\GuildLootEra\\Media\\GuildLootLogo')
    -- Use the shield/chest part of the original GuildLoot wordmark.
    icon:SetTexCoord(0,.37,0,1)
    b:SetHighlightTexture('Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight')
    local function position()
        local angle=math.rad(tonumber(GL.db.minimapAngle) or 220)
        b:ClearAllPoints();b:SetPoint('CENTER',Minimap,'CENTER',math.cos(angle)*(Minimap:GetWidth()/2+8),math.sin(angle)*(Minimap:GetHeight()/2+8))
    end
    b:SetScript('OnClick',function(_,mouse) if mouse=='RightButton' then GL.ToggleBuffs();return end;if window and window:IsShown() then window:Hide() else GL.Show() end end)
    b:SetScript('OnEnter',function() GameTooltip:SetOwner(b,'ANCHOR_LEFT');GameTooltip:AddLine('GuildLoot',1,.8,.3);GameTooltip:AddLine('Linksklick: öffnen / schließen',1,1,1);GameTooltip:AddLine('Rechtsklick: Buffleiste',1,1,1);GameTooltip:AddLine('Ziehen: Position an der Minimap ändern',.7,.8,.9);GameTooltip:Show() end)
    b:SetScript('OnLeave',function() GameTooltip:Hide() end)
    b:SetScript('OnDragStart',function()
        GameTooltip:Hide();b:SetScript('OnUpdate',function()
            local x,y=GetCursorPosition();local cx,cy=Minimap:GetCenter();local scale=Minimap:GetEffectiveScale()
            GL.db.minimapAngle=math.deg(math.atan2(y/scale-cy,x/scale-cx));position()
        end)
    end)
    b:SetScript('OnDragStop',function() b:SetScript('OnUpdate',nil) end)
    position()
end

function GL.CurrentSheetRaidId()
 local data=((GL.db.guildProfiles or {})[GL.db.selectedGuild] or {}).activeRaids or {}
 local _,kind,_,_,_,_,_,instance=GetInstanceInfo()
 local ids={mc=409,bwl=469,ony=249,zg=309,aq20=509,aq40=531,naxx=533}
 local active=GL.Active();local today=date('%Y-%m-%d',GetServerTime());local best,bestScore
 for _,r in ipairs(data.rows or {}) do
  local id=ids[r.raid] or (r.raid and r.raid:match('^zg%-') and 309)
  if kind~='raid' or id==instance then
   local score=(r.date and r.date:sub(1,10)==today) and 10 or 0
   if r.id==GL.masterRaidId then score=score+2 end
   if active and active.guild==GL.db.selectedGuild and active.raidId==r.id then score=score+20 end
   if not bestScore or score>bestScore then best,bestScore=r.id,score end
  end
 end
 return best
end
function GL.InitializeSheetShortcut()
 if GL.sheetShortcut or not UIParent or not GL.db then return end
 local b=CreateFrame('Button','GuildLootEraSheetShortcut',UIParent);GL.sheetShortcut=b
 b:SetSize(44,44);b:SetFrameStrata('HIGH');b:SetFrameLevel(100);b:SetMovable(true);b:SetClampedToScreen(true);b:EnableMouse(true);b:RegisterForDrag('LeftButton');b:RegisterForClicks('LeftButtonUp')
 local icon=b:CreateTexture(nil,'ARTWORK');icon:SetAllPoints();icon:SetTexture('Interface\\AddOns\\GuildLootEra\\Media\\GuildLootLogo');icon:SetTexCoord(0,.37,0,1)
 b:SetHighlightTexture('Interface\\Buttons\\ButtonHilight-Square','ADD')
 local label=b:CreateFontString(nil,'OVERLAY','GameFontNormalSmall');label:SetPoint('TOP',b,'BOTTOM',0,-2);label:SetText('Sheet')
 local pos=GL.db.sheetShortcutPosition
 b:SetPoint('CENTER',UIParent,'CENTER',pos and pos.x or -22,pos and pos.y or 0)
 b:SetScript('OnDragStart',function() GameTooltip:Hide();b:StartMoving() end)
 b:SetScript('OnDragStop',function() b:StopMovingOrSizing();local x,y=b:GetCenter();local px,py=UIParent:GetCenter();GL.db.sheetShortcutPosition={x=x-px,y=y-py} end)
 b:SetScript('OnClick',function()
  local id=GL.CurrentSheetRaidId()
  if not id then print('GuildLoot: Für diesen Raid ist noch kein Raid synchronisiert.');return end
  GL.ShowSheetWindow(id)
 end)
 b:SetScript('OnEnter',function() GameTooltip:SetOwner(b,'ANCHOR_RIGHT');GameTooltip:AddLine('GuildLoot · Raidsheet',1,.8,.2);GameTooltip:AddLine('Klicken: Sheet des aktuellen Raids',1,1,1);GameTooltip:AddLine('Ziehen: Button verschieben',.7,.8,.9);GameTooltip:Show() end)
 b:SetScript('OnLeave',function() GameTooltip:Hide() end)
 b:SetShown(GL.db.sheetShortcutShown~=false)
end

function GL.ToggleSheetShortcut()
 GL.InitializeSheetShortcut();local b=GL.sheetShortcut;if not b then return false end
 if not GL.db.sheetShortcutPosition then b:ClearAllPoints();b:SetPoint('CENTER',UIParent,'CENTER',-22,0)end
 GL.db.sheetShortcutShown=not b:IsShown();b:SetShown(GL.db.sheetShortcutShown);return GL.db.sheetShortcutShown
end

SLASH_GUILDLOOTSHEETBUTTON1='/glesheet'
SlashCmdList.GUILDLOOTSHEETBUTTON=function()
 GL.InitializeSheetShortcut();local b=GL.sheetShortcut;if not b then return end
 GL.db.sheetShortcutShown=true;GL.db.sheetShortcutPosition=nil;b:ClearAllPoints();b:SetPoint('CENTER',UIParent,'CENTER',-22,0);b:Show()
end

function GL.ShowUploadDialog()
    if GL.HasGuildSync and not GL.HasGuildSync() then GL.ShowGuildSyncHelp();return end
    local recording=lootTable and lootTable:IsShown() and lootTable:GetRecording() or GL.Current()
    if not recording or not recording.endedAt then error('Bitte zuerst eine Aufzeichnung beenden.') end
    local f=CreateFrame('Frame',nil,UIParent,'BasicFrameTemplateWithInset');f:SetSize(540,280);f:SetPoint('CENTER');f:SetFrameStrata('DIALOG');f:EnableMouse(true)
    f.TitleText:SetText('Protokoll mit GuildLoot Sync hochladen')
    local info=f:CreateFontString(nil,'OVERLAY','GameFontHighlight');info:SetPoint('TOPLEFT',20,-48);info:SetWidth(500);info:SetJustifyH('LEFT')
    info:SetText(recording.raidName..' · '..recording.raidDate..(GL.HasPersistentMasterAccess() and '\nGespeicherter Zugang wird verwendet; anderer PIN optional.\n' or '\nLead-PIN oder Plündermeister-PIN eingeben.\n')..GL.WebsiteActionStatus(recording.raidId))
    local pin=CreateFrame('EditBox',nil,f,'InputBoxTemplate');pin:SetPoint('TOPLEFT',26,-120);pin:SetSize(485,28);pin:SetAutoFocus(false);pin:SetMaxLetters(100);pin:SetPassword(true)
    local send=CreateFrame('Button',nil,f,'UIPanelButtonTemplate');send:SetPoint('TOPLEFT',20,-165);send:SetSize(500,30);send:SetText('Upload vormerken')
    send:SetScript('OnClick',function()
        local ok,err=pcall(GL.QueueRaidUpload,recording,pin:GetText());pin:SetText('');pin:ClearFocus()
        info:SetText(ok and 'Upload vorgemerkt. Bitte /reload ausführen.\nGuildLoot Sync überträgt das Protokoll und zeigt die Bestätigung.' or tostring(err))
        if ok then send:Disable() end
    end)
    local hint=f:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');hint:SetPoint('TOPLEFT',20,-215);hint:SetWidth(500);hint:SetText('GuildLoot Sync muss laufen. Loot und Teilnahme werden übernommen. P0+-Punkte anschließend wie gewohnt prüfen und abschließen.')
    f:SetScript('OnHide',function() pin:SetText('');pin:ClearFocus() end)
end


-- Profession launcher and a read-only search of the currently opened profession.
do
 local iconPath='Interface\\AddOns\\GuildLootEra\\Media\\GuildSkills'
 local frame,launcher,search,summary,detail,rows,buttons,kind
 local chosen,action,reagents,recipeIcon,scanTooltip
 local database,dbButtons,viewed,remoteProfession,characterButton,exportButton,remoteButtons
 local refreshing=false
 local dbHeader,skillHeader,skillButtons,searchLabel
 local dbExpanded,skillExpanded=true,false
 local guideActive=false
 local actionY=782
 local borrowed={}
 local quantityControls
 local offset=0
 local spellIds={2259,2018,7411,4036,2108,3908,2575,2366,8613,2550,3273,7620,2842}
 local function setting()
  GL.db.professionShortcuts=GL.db.professionShortcuts or {}
  local key=UnitGUID('player') or 'player';GL.db.professionShortcuts[key]=GL.db.professionShortcuts[key] or {}
  return GL.db.professionShortcuts[key]
 end
 local function text(parent,value,x,y,w)
  local t=parent:CreateFontString(nil,'OVERLAY','GameFontHighlight');t:SetPoint('TOPLEFT',x,y);t:SetWidth(w);t:SetJustifyH('LEFT');t:SetText(value);return t
 end
 local function button(parent,value,x,y,w,secure)
  local b=CreateFrame('Button',nil,parent,secure and 'SecureActionButtonTemplate' or nil);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,30)
  local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.08,.17,.21,1);b.background=bg
  b.label=text(b,value,8,-8,w-16);b:SetHighlightTexture('Interface\\Buttons\\ButtonHilight-Square');return b
 end
 local function closeGuide()
  guideActive=false;GL.HideProfessionGuide()
  if searchLabel then searchLabel:Show();search:Show();summary:Show();detail:Show() end
 end
 local function recipes()
  local result={};local query=string.lower(search:GetText() or '')
  if database then return GL.GetProfessionDatabaseEntries(database,query) end
  if remoteProfession then
   local bySpell={};for _,r in ipairs(GL.GetProfessionDatabaseEntries(remoteProfession.id,'')) do bySpell[r.spellId]=r end
   for _,known in ipairs(remoteProfession.recipes or {}) do
    local r=bySpell[known.spellId] or {spellId=known.spellId,itemId=known.itemId,name=known.name,reagents={},skill=0}
    r.kind='snapshot';r.index=known.spellId~=0 and known.spellId or known.name;r.name=known.name
    if query=='' or string.find(string.lower(r.name),query,1,true) then result[#result+1]=r end
   end
   table.sort(result,function(a,b) return a.name<b.name end);return result
  end
  local count=kind=='trade' and GetNumTradeSkills and GetNumTradeSkills() or kind=='craft' and GetNumCrafts and GetNumCrafts() or 0
  for i=1,count do
   local name,typ,available
   if kind=='trade' then name,typ,available=GetTradeSkillInfo(i)
   else local sub;name,sub,typ,available=GetCraftInfo(i) end
   if name and typ~='header' and typ~='subheader' then
    local materials={};local reagentData={};local n=kind=='trade' and GetTradeSkillNumReagents(i) or GetCraftNumReagents(i)
    for j=1,n do
     local rn,texture,need,have
     if kind=='trade' then rn,texture,need,have=GetTradeSkillReagentInfo(i,j) else rn,texture,need,have=GetCraftReagentInfo(i,j) end
     reagentData[#reagentData+1]={name=rn or '?',texture=texture,need=need or 0,have=have or 0}
     materials[#materials+1]=(rn or '?')..': '..(have or 0)..' / '..(need or 0)
    end
    local description=table.concat(materials,'\n')
    if query=='' or string.find(string.lower(name..' '..description),query,1,true) then result[#result+1]={index=i,name=name,available=available or 0,details=description,reagents=reagentData,kind=kind} end
   end
  end
  return result
 end
 local function restoreButtons()
  if quantityControls then quantityControls:Hide() end
  if InCombatLockdown() then return end
  for b,state in pairs(borrowed) do
   b:Hide();b:SetParent(state.parent);b:ClearAllPoints();for _,point in ipairs(state.points) do b:SetPoint(unpack(point)) end;b:SetSize(state.w,state.h);b:Show()
  end
  borrowed={}
 end
 local function hideNative()
  if not frame or not frame:IsShown() or InCombatLockdown() then return end
  local native=kind=='craft' and CraftFrame or kind=='trade' and TradeSkillFrame
  if native and native:IsShown() then
   local handler=native:GetScript('OnHide');native:SetScript('OnHide',nil);HideUIPanel(native);native:SetScript('OnHide',handler)
  end
 end
 local function selectRecipe(r)
  chosen=r
  if quantityControls then quantityControls:Select(r) end
  if not r then detail:SetText('Rezept auswählen.');recipeIcon:Hide();for _,b in ipairs(reagents) do b:Hide() end;restoreButtons();return end
  if r.kind=='database' or r.kind=='snapshot' then
   restoreButtons();recipeIcon:SetTexture(r.texture);recipeIcon:Show()
   detail:SetText(r.name..'\n\nBenötigte Berufsfertigkeit: '..r.skill..(r.kind=='snapshot' and ('\nBekannt: '..viewed.player..'\nStand: '..date('%d.%m.%Y %H:%M',remoteProfession.scannedAt)) or '\nDatenbank · auch unbekannte Rezepte')..'\nShift + Linksklick: Link in den Chat')
   for i,b in ipairs(reagents) do
    local mat=r.reagents[i];b:SetShown(mat~=nil);b.itemId=mat and mat.itemId or nil
    if mat then b.icon:SetTexture(mat.texture or 'Interface\\Icons\\INV_Misc_QuestionMark');b.label:SetText(mat.name..'\n'..(r.kind=='snapshot' and ('Benötigt: '..mat.need) or (mat.have..' / '..mat.need)));b.label:SetTextColor(.9,.85,.65) end
   end
   return
  end
  if InCombatLockdown() then return end
  -- The native selection routine also refreshes the borrowed Create button.
  -- SelectTradeSkill/SelectCraft alone leave its enabled state on the old recipe,
  -- because Blizzard's normal update handler skips the hidden profession frame.
  if kind=='craft' then
   if CraftFrame_SetSelection then CraftFrame_SetSelection(r.index) else SelectCraft(r.index) end
  else
   if TradeSkillFrame_SetSelection then TradeSkillFrame_SetSelection(r.index) else SelectTradeSkill(r.index) end
  end
  local description=kind=='craft' and GetCraftDescription and GetCraftDescription(r.index) or ''
  local texture=kind=='craft' and GetCraftIcon and GetCraftIcon(r.index) or kind=='trade' and GetTradeSkillIcon and GetTradeSkillIcon(r.index)
  recipeIcon:SetTexture(texture);recipeIcon:Show()
  if kind=='trade' and scanTooltip then
   scanTooltip:ClearLines();scanTooltip:SetOwner(frame,'ANCHOR_NONE');scanTooltip:SetTradeSkillItem(r.index)
   local lines={};for i=2,scanTooltip:NumLines() do local t=_G['GuildLootProfessionScanTextLeft'..i];local value=t and t:GetText();if value and value~='' then lines[#lines+1]=value end end
   description=table.concat(lines,'\n');scanTooltip:Hide()
  end
  detail:SetText(r.name..'\n\n'..(description~='' and description or 'Werte und Wirkung: Maus über das Rezept.'))
  for i,b in ipairs(reagents) do
   local mat=r.reagents[i];b:SetShown(mat~=nil)
   b.itemId=nil;if mat then b.icon:SetTexture(mat.texture);b.label:SetText(mat.name..'\n'..mat.have..' / '..mat.need);b.label:SetTextColor(mat.have>=mat.need and .7 or 1,mat.have>=mat.need and 1 or .35,.4) end
  end
  local original=kind=='craft' and CraftCreateButton or TradeSkillCreateButton
  restoreButtons()
  if original then
   local points={};for i=1,original:GetNumPoints() do points[#points+1]={original:GetPoint(i)} end
   borrowed[original]={parent=original:GetParent(),points=points,w=original:GetWidth(),h=original:GetHeight()}
   original:SetParent(frame);original:ClearAllPoints();original:SetPoint('TOPLEFT',frame,'TOPLEFT',430,-actionY);original:SetSize(305,30);original:Show()
   if quantityControls then quantityControls:ShowFor(r,actionY) end
  end
 end
 local function refresh()
  if refreshing then return end
  if not frame or not frame:IsShown() then return end
  if guideActive then
   searchLabel:Hide();search:Hide();summary:Hide();detail:Hide();recipeIcon:Hide()
   for _,b in ipairs(rows) do b:Hide() end;for _,b in ipairs(reagents) do b:Hide() end
   return
  end
  refreshing=true
  local entries=recipes();if chosen then local updated;for _,r in ipairs(entries) do if r.index==chosen.index and r.kind==chosen.kind and r.name==chosen.name then updated=r;break end end;selectRecipe(updated) end
  offset=math.min(offset,math.max(0,#entries-9))
  for i,b in ipairs(rows) do
   local r=entries[offset+i];b:SetShown(r~=nil)
   if r then b.background:SetColorTexture(database and .36 or .08,database and .17 or .17,database and .035 or .21,1);b.icon:SetTexture(r.texture or (r.kind=='craft' and GetCraftIcon and GetCraftIcon(r.index)) or (r.kind=='trade' and GetTradeSkillIcon and GetTradeSkillIcon(r.index)) or 'Interface\\Icons\\INV_Misc_QuestionMark');b.label:SetText(r.name..(database and ('  · '..r.skill) or (remoteProfession and '  · bekannt' or ('  ('..r.available..')'))));b:SetScript('OnClick',function(_,which) if which=='LeftButton' and IsShiftKeyDown() then search:ClearFocus();GL.InsertProfessionRecipeLink(r);return end;if not InCombatLockdown() then refreshing=true;selectRecipe(r);refreshing=false end end);b:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');if r.kind=='database' or r.kind=='snapshot' then local link=GL.ProfessionRecipeLink(r);if link:find('|H',1,true) or link:match('^item:') then GameTooltip:SetHyperlink(link) else GameTooltip:SetText(r.name) end elseif r.kind=='craft' then GameTooltip:SetCraftSpell(r.index) else GameTooltip:SetTradeSkillItem(r.index) end;GameTooltip:Show() end);b:SetScript('OnLeave',function() GameTooltip:Hide() end) end
  end
  if database then summary:SetText(#entries..' Rezepte · Datenbank · Shift + Linksklick: Chatlink · Mausrad: blättern');if #entries==0 and search:GetText()=='' then detail:SetText('Dieser Sammelberuf hat keine herstellbaren Rezepte.') end
  elseif remoteProfession then summary:SetText(#entries..' bekannte Rezepte · '..viewed.player..' · Shift + Linksklick: Chatlink')
  else summary:SetText(kind and (#entries..' Rezepte · Klammer: herstellbare Menge · Mausrad: blättern') or 'Öffne oben einen Beruf, um seine Rezepte einzulesen.') end
  refreshing=false
 end
 local function layoutSections()
  if InCombatLockdown() then return end
  local function at(w,x,y) w:ClearAllPoints();w:SetPoint('TOPLEFT',x,-y) end
  local y=206;at(dbHeader,18,y);dbHeader.label:SetText((dbExpanded and '[-] ' or '[+] ')..'Berufe Datenbank');y=y+32
  for i,b in ipairs(dbButtons) do b:SetShown(dbExpanded);at(b,18+((i-1)%4)*183,y+math.floor((i-1)/4)*30) end
  if dbExpanded then y=y+120 end
  y=y+6;at(skillHeader,18,y);skillHeader.label:SetText((skillExpanded and '[-] ' or '[+] ')..'Berufe skillen');y=y+32
  for i,b in ipairs(skillButtons) do b:SetShown(skillExpanded);at(b,18+((i-1)%4)*183,y+math.floor((i-1)/4)*30) end
  if skillExpanded then y=y+90 end
  y=y+14;GL.LayoutProfessionGuide(y);at(searchLabel,24,y);at(search,24,y+22);at(summary,18,y+59)
  for i,b in ipairs(rows) do at(b,18,y+85+(i-1)*32) end
  at(detail,474,y+91);at(recipeIcon,430,y+91)
  for i,b in ipairs(reagents) do at(b,430+((i-1)%2)*156,y+224+math.floor((i-1)/2)*45) end
  actionY=y+477;frame:SetHeight(actionY+51);frame:SetScale(math.min(1,(UIParent:GetHeight()-40)/(actionY+51)))
  for b in pairs(borrowed) do b:ClearAllPoints();b:SetPoint('TOPLEFT',frame,'TOPLEFT',430,-actionY) end
  if quantityControls and chosen then quantityControls:ShowFor(chosen,actionY) end
 end
 local function updateCharacterButtons()
  local choices=GL.ProfessionCharacterList();local valid
  for _,c in ipairs(choices) do if viewed and c.player==viewed.player and c.realm==viewed.realm then valid=c;break end end
  viewed=valid or choices[1]
  local token=GL.CharacterIdentity(viewed);characterButton.icon:SetTexture(token and ('Interface\\Icons\\ClassIcon_'..token) or 'Interface\\Icons\\INV_Misc_QuestionMark')
  characterButton.label:SetText('Charakter: '..viewed.player..' – '..viewed.realm..'  >')
  local snapshot=GL.GetProfessionCharacter(viewed.player,viewed.realm)
  for _,b in ipairs(buttons) do if not viewed.current then b:Hide() end end
  for i,b in ipairs(remoteButtons) do
   local p=not viewed.current and snapshot and snapshot.professions[i]
   b:SetShown(p and true or false)
   if p then
    local icon;for _,t in ipairs(GL.ProfessionDatabaseTypes) do if t[1]==p.id then icon=select(3,GetSpellInfo(t[2]));break end end
    b.icon:SetTexture(icon);b.label:SetText(p.name..'  '..p.rank..' / '..p.maxRank)
    b:SetScript('OnClick',function()
     if InCombatLockdown() then return end
     closeGuide();restoreButtons();database=nil;kind=nil;chosen=nil;remoteProfession=p;offset=0;search:SetText('');selectRecipe(nil);refresh()
     if not p.scannedAt or p.scannedAt==0 then detail:SetText('Rezepte noch nicht eingelesen. Diesen Charakter in WoW spielen und den Beruf einmal öffnen, danach Berufe synchronisieren.') end
    end)
   end
  end
  exportButton:SetShown(viewed.current==true)
  if not viewed.current and not snapshot then detail:SetText('Für '..viewed.player..' wurden noch keine Berufe übertragen. Mit diesem Charakter Berufe öffnen und synchronisieren.') end
 end
 function GL.ShowProfessions()
  if not frame then
   if InCombatLockdown() then print('GuildLoot: Berufsübersicht bitte nach dem Kampf öffnen.');return end
   frame=CreateFrame('Frame','GuildLootEraProfessions',UIParent,'BasicFrameTemplateWithInset');frame:SetSize(760,833);frame:SetScale(math.min(1,(UIParent:GetHeight()-40)/833));frame:SetPoint('CENTER');frame:SetFrameStrata('DIALOG');frame:SetClampedToScreen(true);frame:SetMovable(true);frame:EnableMouse(true);frame:RegisterForDrag('LeftButton');frame:SetScript('OnDragStart',frame.StartMoving);frame:SetScript('OnDragStop',frame.StopMovingOrSizing);frame.TitleText:SetText('GuildLoot · Berufe')
   buttons={};rows={};dbButtons={};remoteButtons={}
   characterButton=button(frame,'Charakter',18,-36,440)
   characterButton.icon=characterButton:CreateTexture(nil,'ARTWORK');characterButton.icon:SetPoint('TOPLEFT',4,-3);characterButton.icon:SetSize(24,24)
   characterButton.label:ClearAllPoints();characterButton.label:SetPoint('TOPLEFT',36,-8);characterButton.label:SetWidth(395)
   text(frame,'Meine Berufe',18,-76,724):SetTextColor(.65,.83,1)
   characterButton:SetScript('OnClick',function()
    if InCombatLockdown() then return end
    local choices=GL.ProfessionCharacterList();local index=1
    for i,c in ipairs(choices) do if viewed and c.player==viewed.player and c.realm==viewed.realm then index=i;break end end
    if kind=='trade' and CloseTradeSkill then CloseTradeSkill() elseif kind=='craft' and CloseCraft then CloseCraft() end
    closeGuide();viewed=choices[index%#choices+1];kind=nil;chosen=nil;database=nil;remoteProfession=nil;offset=0;search:SetText('');selectRecipe(nil);GL.ShowProfessions()
   end)
   exportButton=button(frame,'Berufe synchronisieren',470,-36,264)
   if GL.GateSyncButton then GL.GateSyncButton(exportButton,'Berufe synchronisieren') end
   exportButton:SetScript('OnClick',function()
    local ok,err=pcall(GL.QueueProfessionExport)
    summary:SetText(ok and 'Gespeichert. /reload → GuildLoot Sync → /reload zum Laden des Serverstands.' or tostring(err))
   end)
   for i=1,12 do
    local b=button(frame,'',18+((i-1)%3)*244,-100-math.floor((i-1)/3)*34,236,true);b:RegisterForClicks('AnyUp','AnyDown');buttons[i]=b
    b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',4,-3);b.icon:SetSize(24,24);b.label:ClearAllPoints();b.label:SetPoint('TOPLEFT',36,-8);b.label:SetWidth(194)
    b:SetScript('PreClick',function() if not InCombatLockdown() then closeGuide();database=nil;remoteProfession=nil;chosen=nil;offset=0;search:SetText('') end end)
   end
   for i=1,12 do
    local b=button(frame,'',18+((i-1)%3)*244,-100-math.floor((i-1)/3)*34,236);remoteButtons[i]=b
    b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',4,-3);b.icon:SetSize(24,24)
    b.label:ClearAllPoints();b.label:SetPoint('TOPLEFT',36,-8);b.label:SetWidth(194);b:Hide()
   end
   dbHeader=button(frame,'Berufe Datenbank',18,-206,724);dbHeader.background:SetColorTexture(.16,.10,.03,1);dbHeader.label:SetTextColor(1,.55,.15)
   dbHeader:SetScript('OnClick',function() if InCombatLockdown() then return end;dbExpanded=not dbExpanded;layoutSections() end)
   for i,prof in ipairs(GL.ProfessionDatabaseTypes) do
    local id,spell=prof[1],prof[2]
    local name,_,icon=GetSpellInfo(spell)
    local b=button(frame,name or prof[3],18+((i-1)%4)*183,-229-math.floor((i-1)/4)*30,176)
    b:SetHeight(27);b.background:SetColorTexture(.36,.17,.035,1)
    b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',4,-3);b.icon:SetSize(22,22);b.icon:SetTexture(icon)
    b.label:ClearAllPoints();b.label:SetPoint('TOPLEFT',32,-7);b.label:SetWidth(139);b.label:SetFontObject('GameFontHighlightSmall');b.label:SetWordWrap(false)
    b:SetScript('OnClick',function()
     if InCombatLockdown() then return end
     closeGuide();restoreButtons()
     if kind=='trade' and CloseTradeSkill then CloseTradeSkill() elseif kind=='craft' and CloseCraft then CloseCraft() end
     kind=nil;chosen=nil;remoteProfession=nil;database=id;offset=0;search:SetText('');selectRecipe(nil);refresh()
    end)
    dbButtons[i]=b
   end
   skillHeader=button(frame,'Berufe skillen',18,-365,724);skillHeader.background:SetColorTexture(.18,.16,.025,1);skillHeader.label:SetTextColor(1,.86,.25)
   skillHeader:SetScript('OnClick',function() if InCombatLockdown() then return end;skillExpanded=not skillExpanded;layoutSections() end)
   skillButtons={}
   for _,prof in ipairs(GL.ProfessionDatabaseTypes) do
    if prof[1]~=13 then
     local id,spell=prof[1],prof[2];local name,_,icon=GetSpellInfo(spell)
     local b=button(frame,name or prof[3],18,0,176);b:SetHeight(27);b.background:SetColorTexture(.58,.45,.035,1)
     b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',4,-3);b.icon:SetSize(22,22);b.icon:SetTexture(icon)
     b.label:ClearAllPoints();b.label:SetPoint('TOPLEFT',32,-7);b.label:SetWidth(139);b.label:SetFontObject('GameFontHighlightSmall');b.label:SetWordWrap(false)
     b:SetScript('OnClick',function()
      local rank=1;local snapshot=viewed and GL.GetProfessionCharacter(viewed.player,viewed.realm)
      for _,p in ipairs(snapshot and snapshot.professions or {}) do if p.id==id then rank=p.rank;break end end
      if InCombatLockdown() then return end
      restoreButtons()
      if kind=='trade' and CloseTradeSkill then CloseTradeSkill() elseif kind=='craft' and CloseCraft then CloseCraft() end
      kind=nil;chosen=nil;database=nil;remoteProfession=nil;guideActive=true
      GL.ShowProfessionGuide(id,rank,frame);layoutSections();refresh()
     end)
     skillButtons[#skillButtons+1]=b
    end
   end
   search=CreateFrame('EditBox',nil,frame,'InputBoxTemplate');search:SetPoint('TOPLEFT',24,-387);search:SetSize(710,28);search:SetAutoFocus(false);search:SetMaxLetters(100);search:SetScript('OnTextChanged',function() offset=0;detail:SetText('Rezept auswählen, um die Zutaten zu sehen.');refresh() end);search:SetScript('OnEscapePressed',search.ClearFocus)
   searchLabel=text(frame,'Rezept oder Zutat suchen',24,-369,710)
   summary=text(frame,'',18,-424,724);detail=text(frame,'Rezept auswählen, um die Zutaten zu sehen.',430,-456,310);detail:SetHeight(122);detail:SetJustifyV('TOP');detail:ClearAllPoints();detail:SetPoint('TOPLEFT',474,-456);detail:SetWidth(262)
   recipeIcon=frame:CreateTexture(nil,'ARTWORK');recipeIcon:SetPoint('TOPLEFT',430,-456);recipeIcon:SetSize(36,36)
   quantityControls=GL.CreateProfessionQuantity(frame)
   scanTooltip=CreateFrame('GameTooltip','GuildLootProfessionScan',UIParent,'GameTooltipTemplate')
   reagents={};for i=1,8 do local b=button(frame,'',430+((i-1)%2)*156,-589-math.floor((i-1)/2)*45,150);b:SetHeight(42);b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',2,-3);b.icon:SetSize(30,30);b.label:ClearAllPoints();b.label:SetPoint('TOPLEFT',36,-3);b.label:SetWidth(111);b.label:SetHeight(38);b:SetScript('OnEnter',function(self) if self.itemId then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetHyperlink('item:'..self.itemId);GameTooltip:Show() end end);b:SetScript('OnLeave',function() GameTooltip:Hide() end);b:Hide();reagents[i]=b end
   for i=1,9 do rows[i]=button(frame,'',18,-450-(i-1)*32,395);local b=rows[i];b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',4,-3);b.icon:SetSize(24,24);b.label:ClearAllPoints();b.label:SetPoint('TOPLEFT',36,-8);b.label:SetWidth(351);b.label:SetHeight(18);b.label:SetWordWrap(false);rows[i]:EnableMouseWheel(true);rows[i]:SetScript('OnMouseWheel',function(_,d) offset=math.max(0,offset-d*3);refresh() end) end
   frame:SetScript('OnHide',function() closeGuide();search:ClearFocus();restoreButtons();if kind=='trade' and CloseTradeSkill then CloseTradeSkill() elseif kind=='craft' and CloseCraft then CloseCraft() end;kind=nil;chosen=nil;database=nil;remoteProfession=nil end)
   local events=CreateFrame('Frame');for _,e in ipairs({'TRADE_SKILL_SHOW','TRADE_SKILL_UPDATE','CRAFT_SHOW','CRAFT_UPDATE','TRADE_SKILL_CLOSE','CRAFT_CLOSE','GET_ITEM_INFO_RECEIVED','BAG_UPDATE_DELAYED'}) do events:RegisterEvent(e) end
   local itemRefreshPending=false
   events:SetScript('OnEvent',function(_,e)
    if e=='GET_ITEM_INFO_RECEIVED' or e=='BAG_UPDATE_DELAYED' then
     if database and frame:IsShown() and not itemRefreshPending then
      itemRefreshPending=true;C_Timer.After(.2,function() itemRefreshPending=false;refresh() end)
     end
     return
    end
    if (database or guideActive or (viewed and not viewed.current)) and (e=='TRADE_SKILL_UPDATE' or e=='CRAFT_UPDATE') then return end
    if e=='TRADE_SKILL_SHOW' or e=='CRAFT_SHOW' then closeGuide();viewed=nil;remoteProfession=nil;GL.ShowProfessions() end
    if e=='TRADE_SKILL_CLOSE' or e=='CRAFT_CLOSE' then chosen=nil;restoreButtons();kind=nil;selectRecipe(nil)
    elseif e:match('^TRADE') then database=nil; if kind~='trade' then chosen=nil;restoreButtons() end;kind='trade' else database=nil;if kind~='craft' then chosen=nil;restoreButtons() end;kind='craft' end
    refresh();if C_Timer then C_Timer.After(0,hideNative) else hideNative() end
   end)
  end
  if not InCombatLockdown() then
   local skills={};for i=1,GetNumSkillLines() do local n,h,_,rank,_,_,max=GetSkillLineInfo(i);if not h then skills[n]={rank=rank,max=max} end end
   local n=0
   for _,id in ipairs(spellIds) do
    local name=GetSpellInfo(id);local skill=name and skills[name]
    if skill then n=n+1;local b=buttons[n];b.label:SetText(name..'  '..skill.rank..' / '..skill.max);local _,_,icon=GetSpellInfo(id);b.icon:SetTexture(icon);b:SetAttribute('type','spell');b:SetAttribute('spell',name);b:Show() end
   end
   for i=n+1,#buttons do buttons[i]:Hide() end
  end
  frame:Show();GL.CaptureProfessionSkills();updateCharacterButtons();layoutSections();refresh()
 end
 function GL.InitializeProfessionShortcut()
  if launcher or not GL.db then return end
  local s=setting();launcher=CreateFrame('Button',nil,UIParent);launcher:SetSize(36,36);launcher:SetFrameStrata('HIGH');launcher:SetClampedToScreen(true);launcher:SetMovable(true);launcher:EnableMouse(true);launcher:RegisterForDrag('LeftButton')
  local texture=launcher:CreateTexture(nil,'ARTWORK');texture:SetAllPoints();texture:SetTexture(iconPath)
  launcher:SetPoint('CENTER',UIParent,'CENTER',s.x or 22,s.y or 0)
  launcher:SetScript('OnDragStart',launcher.StartMoving);launcher:SetScript('OnDragStop',function(self) self:StopMovingOrSizing();local x,y=self:GetCenter();local px,py=UIParent:GetCenter();local p=setting();p.x=x-px;p.y=y-py end)
  launcher:SetScript('OnClick',GL.ShowProfessions)
  launcher:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText('Berufe · Klicken zum Öffnen, ziehen zum Verschieben');GameTooltip:Show() end);launcher:SetScript('OnLeave',function() GameTooltip:Hide() end)
  launcher:SetShown(s.shown==true)
 end
 function GL.ToggleProfessionShortcut()
  GL.InitializeProfessionShortcut();local s=setting();if s.x==nil and s.y==nil then launcher:ClearAllPoints();launcher:SetPoint('CENTER',UIParent,'CENTER',22,0)end;s.shown=not launcher:IsShown();launcher:SetShown(s.shown);return s.shown
 end
 local login=CreateFrame('Frame');login:RegisterEvent('PLAYER_LOGIN');login:SetScript('OnEvent',function() GL.InitializeProfessionShortcut() end)
end
