local _,GL=...
-- Plündermeister: Raidmeldung mit Prio-Inhabern beim Öffnen der Beute, eigenes Fenster mit Würfeln, Zuteilen (GiveMasterLoot) und Historie.
local M={};GL.MasterLoot=M
local function norm(v) return (string.lower(tostring(v or ''):gsub('^%s+',''):gsub('%s+$',''))) end
local function short(full) local s=tostring(full or '');return s:match('^(.-)%-') or s end
local function cut(text,max) -- UTF-8-sicher kürzen
 if #text<=max then return text end
 local i=max-1;while i>1 and text:byte(i)>=128 and text:byte(i)<192 do i=i-1 end
 return text:sub(1,i-1)..'…'
end
local ORDER={['P0+']=0,P0=1,P1=2,P2=3,P3=4}
function M.Sort(list)
 table.sort(list,function(a,b) local x,y=ORDER[a.prio] or 9,ORDER[b.prio] or 9;if x~=y then return x<y end;if (a.points or 0)~=(b.points or 0) then return (a.points or 0)>(b.points or 0) end;return a.player<b.player end)
 return list
end
-- Prio-Inhaber eines Items: aktive Raidliste (P1–P3 nur veröffentlicht, P0/P0+ immer), sonst importierte Prioliste.
function M.Holders(r,itemId,itemName)
 local out={};if not r then return out end
 local data=(((GL.db.guildProfiles or {})[r.guild] or {}).activeRaids or {})
 local list=(data.lists or {})[r.raidId]
 if list then
  for _,row in ipairs(list.rows or {}) do
   if row.bench~=1 then
    for _,key in ipairs({'p0','p1','p2','p3'}) do
     if key=='p0' or list.published==1 then
      local id=tonumber(row[key..'Id']);local match
      if id and id>0 then match=id==tonumber(itemId) else local n=norm(row[key]);match=n~='' and n~='gesetzt' and n==norm(itemName) end
      if match then out[#out+1]={player=row.player,realm=row.realm or '',prio=key=='p0' and (row.p0Plus==1 and 'P0+' or 'P0') or key:upper(),class=row.className} end
     end
    end
   end
  end
  return M.Sort(out)
 end
 local p=GL.db.priorities
 if p and p.rows and p.guild==r.guild and (p.raidId==r.raidId or p.legacy) then
  for _,row in ipairs(p.rows) do
   if not row.bench and tonumber(row.itemId)==tonumber(itemId) and row.priority~='Punkte' then out[#out+1]={player=row.player,realm=row.realm or '',prio=row.priority,points=row.points,class=row.class} end
  end
 end
 return M.Sort(out)
end
function M.HolderText(holders,max)
 if #holders==0 then return 'keine Prio' end
 local parts={}
 for i,h in ipairs(holders) do if max and i>max then parts[#parts+1]='+'..(#holders-max);break end;parts[#parts+1]=h.prio..' '..h.player end
 return table.concat(parts,' · ')
end
function M.IsMasterLooter()
 if not GetLootMethod then return false end
 local method,partyIndex=GetLootMethod();return method=='master' and partyIndex==0
end
-- Raidchat mit Abstand senden (Chat-Drossel).
local queue={};local pump=CreateFrame('Frame');local elapsed=0
pump:SetScript('OnUpdate',function(_,dt) elapsed=elapsed+dt;if elapsed<.4 then return end;elapsed=0;local t=table.remove(queue,1);if t and IsInRaid() then SendChatMessage(cut(t,255),'RAID') end end)
function M.Say(text) queue[#queue+1]=text end
function M.Queued() return queue end
-- Aktuelle Beute des offenen Lootfensters.
function M.LootItems()
 local items={}
 for slot=1,(GetNumLootItems and GetNumLootItems() or 0) do
  local link=GetLootSlotLink(slot);local id=link and tonumber(link:match('item:(%d+)'))
  if id then
   local icon,name,quantity=GetLootSlotInfo(slot)
   local _,_,quality=GetItemInfo(link)
   local sources={GetLootSourceInfo(slot)};local guid=sources[1] or ('slot'..slot)
   items[#items+1]={slot=slot,link=link,itemId=id,itemName=name or link:match('%[(.-)%]') or tostring(id),icon=icon,quantity=quantity or 1,quality=quality or 0,key=guid..':'..id}
  end
 end
 return items
end
-- Unverteilte Items: alles ab Lootschwelle, das der Plündermeister gesehen hat und noch nicht vergeben wurde.
-- Nimmt der Plündermeister ein Item selbst (Tasche), bleibt es „in Tasche“ bis zur Vergabe oder zum Entfernen.
function M.Pending(r) if not r then return {} end;r.pending=r.pending or {};return r.pending end
function M.Track(items)
 local r=GL.Active();if not r or not M.IsMasterLooter() then return end
 local pending=M.Pending(r);local threshold=GetLootThreshold and GetLootThreshold() or 2
 for _,item in ipairs(items) do
  if item.quality>=threshold then
   local found;for _,e in ipairs(pending) do if e.key==item.key then found=e end end
   if not found then pending[#pending+1]={key=item.key,itemId=item.itemId,itemName=item.itemName,link=item.link,icon=item.icon,quality=item.quality,quantity=item.quantity,seenAt=GetServerTime()} end
  end
 end
end
function M.Untrack(key) local r=GL.Active();if not r then return end;local pending=M.Pending(r);for i=#pending,1,-1 do if pending[i].key==key then table.remove(pending,i) end end end
function M.UntrackReceipt(text)
 local r=GL.Active();if not r or not GL.ParseLootMessage then return end
 local e=GL.ParseLootMessage(text);if not e then return end
 local me=GL.FullName and GL.FullName('player');if me and e.recipient and short(e.recipient)==short(me) then
  for _,p in ipairs(M.Pending(r)) do if p.itemId==e.itemId and not p.inBag then p.inBag=true;break end end;return
 end
 local pending=M.Pending(r);for i,p in ipairs(pending) do if p.itemId==e.itemId then table.remove(pending,i);return end end
end
-- Aktuelle Beute plus unverteilte Items aus der Tasche (ohne Lootplatz).
function M.Items()
 local items=M.LootItems();local seen={};for _,i in ipairs(items) do seen[i.key]=true end
 for _,p in ipairs(M.Pending(GL.Active())) do if not seen[p.key] then items[#items+1]={key=p.key,itemId=p.itemId,itemName=p.itemName,link=p.link,icon=p.icon,quality=p.quality,quantity=p.quantity or 1,inBag=p.inBag,pendingOnly=true} end end
 return items
end
function M.AnnounceLoot(items)
 local r=GL.Active();if not r or not GL.InInstance(r) or GL.db.lootAnnounce==false or not M.IsMasterLooter() then return 0 end
 r.announced=r.announced or {};local threshold=GetLootThreshold and GetLootThreshold() or 2;local sent=0
 for _,item in ipairs(items or M.LootItems()) do
  if item.quality>=threshold and not r.announced[item.key] then
   r.announced[item.key]=true;sent=sent+1
   M.Say(item.link..' · '..M.HolderText(M.Holders(r,item.itemId,item.itemName),6))
  end
 end
 return sent
end
-- Würfeln: Start merken, Würfe aus den Chatnachweisen ab diesem Zeitpunkt.
M.rollStart={}
function M.StartRoll(item)
 local r=GL.Active();if not r then return end
 local seconds=tonumber(GL.db.rollSeconds) or 15
 M.rollStart[item.key]=GetServerTime()
 M.Say('Würfeln für '..item.link..' · '..seconds..' Sekunden · /roll')
 if C_Timer and C_Timer.After then C_Timer.After(seconds,function()
  local rolls=M.Rolls(item);if #rolls>0 then M.Say('Höchster Wurf für '..item.link..': '..short(rolls[1].player)..' ('..rolls[1].roll..')') end
  if M.frame and M.frame:IsShown() then M.frame:Refresh() end
 end) end
end
function M.Rolls(item)
 local r=GL.Active();local since=M.rollStart[item.key];local out={}
 if not r or not since then return out end
 local seen={}
 for _,e in ipairs(r.chatEvidence or {}) do
  if e.kind=='roll' and e.observedAt>=since and e.minimum==1 and e.maximum==100 and not seen[e.sender] then seen[e.sender]=true;out[#out+1]={player=e.sender,roll=e.roll} end
 end
 table.sort(out,function(a,b) if a.roll~=b.roll then return a.roll>b.roll end;return a.player<b.player end)
 return out
end
-- Zuteilen über den Plündermeister-Modus von WoW.
function M.Candidates(slot)
 local out={}
 if slot then for i=1,40 do local name=GetMasterLootCandidate and GetMasterLootCandidate(slot,i);if name then out[#out+1]={index=i,name=name} end end;return out end
 for i=1,(GetNumGroupMembers and GetNumGroupMembers() or 0) do local name=GetRaidRosterInfo and GetRaidRosterInfo(i);if name then out[#out+1]={name=name} end end
 return out
end
function M.Award(item,candidate,info)
 local r=GL.Active();if not r then error('Keine Aufzeichnung aktiv.') end
 if not M.IsMasterLooter() then error('Du bist nicht Plündermeister.') end
 if item.slot and candidate.index then GiveMasterLoot(item.slot,candidate.index) end
 M.Untrack(item.key)
 r.awards=r.awards or {}
 r.awards[#r.awards+1]={itemId=item.itemId,itemName=item.itemName,recipient=candidate.name,priority=info and info.prio or nil,roll=info and info.roll or nil,at=GetServerTime()}
 local text=item.link..' geht an '..short(candidate.name)..(info and info.prio and (' ('..info.prio..')') or (info and info.roll and (' (Wurf '..info.roll..')') or ''))..((not item.slot or not candidate.index) and ' · Übergabe per Handel' or '')
 if GL.db.lootAnnounce~=false then M.Say(text) end
 return text
end
-- Historie der laufenden Aufzeichnung: Lootmeldungen mit Prio, eigene Vergaben mit Wurf.
function M.History(r)
 local rows={};if not r then return rows end
 local awards={};for _,a in ipairs(r.awards or {}) do awards[#awards+1]=a end
 for _,e in ipairs(r.receipts or {}) do
  local roll,prio
  for _,a in ipairs(awards) do if a.itemId==e.itemId and norm(short(a.recipient))==norm(short(e.recipient)) and math.abs((a.at or 0)-(e.observedAt or 0))<=120 then roll=a.roll;prio=a.priority end end
  rows[#rows+1]={at=e.observedAt,player=short(e.recipient),itemId=e.itemId,itemName=e.itemName,priority=prio or (GL.LootPriority and GL.LootPriority(r,e)) or '—',roll=roll}
 end
 table.sort(rows,function(a,b) return (a.at or 0)>(b.at or 0) end)
 return rows
end

-- Fenster
local QUALITY={[0]={.62,.62,.62},[1]={1,1,1},[2]={.12,1,0},[3]={0,.44,.87},[4]={.64,.21,.93},[5]={1,.5,0}}
function M.Show(selectKey)
 if selectKey then M.selectKey=selectKey end
 if M.frame then M.frame:Show();M.frame:Refresh();return end
 local f=CreateFrame('Frame','GuildLootEraMasterLoot',UIParent,'BasicFrameTemplateWithInset');M.frame=f
 f:SetSize(900,560);f:SetPoint('CENTER');f:SetFrameStrata('DIALOG');f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag('LeftButton');f:SetClampedToScreen(true)
 f:SetScript('OnDragStart',f.StartMoving);f:SetScript('OnDragStop',function(self) self:StopMovingOrSizing();M.SavePlacement(self,'masterWindow') end);tinsert(UISpecialFrames,'GuildLootEraMasterLoot')
 local surface=f:CreateTexture(nil,'BACKGROUND');surface:SetPoint('TOPLEFT',8,-28);surface:SetPoint('BOTTOMRIGHT',-8,8);surface:SetColorTexture(.025,.045,.065,.96)
 local function label(x,y,w,size,owner) local l=(owner or f):CreateFontString(nil,'OVERLAY','GameFontHighlight');l:SetPoint('TOPLEFT',x,y);l:SetWidth(w);l:SetJustifyH('LEFT');l:SetFont(STANDARD_TEXT_FONT,size or 12);l:SetTextColor(.72,.82,.88);return l end
 local function button(text,x,y,w,fn,owner,h)
  local b=CreateFrame('Button',nil,owner or f);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,h or 22)
  local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.13,.23,.27,1);b.background=bg
  b.label=label(6,-6,w-12,11,b);b.label:SetText(text);b:SetScript('OnClick',fn);return b
 end
 local heading=label(20,-38,500,17);heading:SetTextColor(.05,.9,.8)
 local status=label(20,-530,860,11);status:SetTextColor(1,.8,.3)
 local announceButton,autoButton,secondsBox
 announceButton=button('',560,-36,140,function() GL.db.lootAnnounce=GL.db.lootAnnounce==false;f:Refresh() end)
 autoButton=button('',706,-36,120,function() GL.db.masterWindowAuto=GL.db.masterWindowAuto==false;f:Refresh() end)
 label(832,-40,40,11):SetText('Sek.')
 secondsBox=CreateFrame('EditBox',nil,f,'InputBoxTemplate');secondsBox:SetPoint('TOPLEFT',838,-36);secondsBox:SetSize(40,22);secondsBox:SetAutoFocus(false);secondsBox:SetNumeric(true);secondsBox:SetMaxLetters(2)
 secondsBox:SetScript('OnTextChanged',function(self) local n=tonumber(self:GetText());if n and n>=5 then GL.db.rollSeconds=n end end);secondsBox:SetScript('OnEnterPressed',function(self) self:ClearFocus() end)
 -- Beute links
 for i,h in ipairs({{'Item',44,236},{'Prios',284,206},{'',496,60}}) do label(h[2],-66,h[3],11):SetText(h[1]) end
 local rows={};local selected
 for i=1,8 do
  local row=CreateFrame('Button',nil,f);row:SetPoint('TOPLEFT',14,-82-(i-1)*32);row:SetSize(560,30)
  local bg=row:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.07,.13,.18,1);row.background=bg
  row.icon=row:CreateTexture(nil,'ARTWORK');row.icon:SetPoint('TOPLEFT',4,-3);row.icon:SetSize(24,24)
  row.name=label(32,-9,236,12,row);row.holders=label(272,-9,206,11,row)
  row.roll=button('Würfeln',452,-4,62,function() if row.item then M.StartRoll(row.item);selected=row.item.key;f:Refresh() end end,row)
  row.drop=button('×',518,-4,30,function() if row.item then M.Untrack(row.item.key);f:Refresh() end end,row)
  row:SetScript('OnClick',function() if row.item then selected=row.item.key;f:Refresh() end end)
  row:SetScript('OnEnter',function(self) if self.item then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetHyperlink(self.item.link);GameTooltip:Show() end end);row:SetScript('OnLeave',function() GameTooltip:Hide() end)
  rows[i]=row
 end
 -- Detail unten links: Würfe und Zuteilen
 local detailTitle=label(14,-346,560,13);detailTitle:SetTextColor(.95,.77,.3)
 local rollsText=label(14,-364,560,11);rollsText:SetHeight(30)
 label(14,-398,300,11):SetText('Zuteilen an (Prio-Inhaber und Würfe zuerst):')
 local candidateButtons={};local candidatePage=1
 for i=1,12 do local b=button('',14+((i-1)%4)*139,-414+math.floor((i-1)/4)*26,134,function(self) if self.candidate and selected then
   local item;for _,it in ipairs(M.Items()) do if it.key==selected then item=it end end
   if item then local ok,result=pcall(M.Award,item,self.candidate,self.info);status:SetText(ok and result or tostring(result):gsub('^.-:%d+: ',''));f:Refresh() end
  end end);candidateButtons[i]=b end
 button('<',14,-496,40,function() candidatePage=math.max(1,candidatePage-1);f:Refresh() end);button('>',534,-496,40,function() candidatePage=candidatePage+1;f:Refresh() end)
 local candidateInfo=label(60,-500,470,11)
 -- Historie rechts
 local histTitle=label(590,-66,290,12);histTitle:SetText('Historie dieser Aufzeichnung');histTitle:SetTextColor(.95,.77,.3)
 local hist={}
 for i=1,17 do
  local row=CreateFrame('Frame',nil,f);row:SetPoint('TOPLEFT',588,-84-(i-1)*25);row:SetSize(296,24)
  local bg=row:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.07,.13,.18,i%2==0 and .6 or 1)
  row.time=label(4,-6,36,10,row);row.player=label(40,-6,78,11,row);row.item=label(118,-6,126,11,row);row.prio=label(246,-6,48,10,row)
  row:EnableMouse(true);row:SetScript('OnEnter',function(self) if self.itemId then GameTooltip:SetOwner(self,'ANCHOR_LEFT');GameTooltip:SetHyperlink('item:'..self.itemId);GameTooltip:Show() end end);row:SetScript('OnLeave',function() GameTooltip:Hide() end)
  hist[i]=row
 end
 button('Loot-Leiste',588,-512,90,function() M.ToggleBar() end);button('Raidprotokoll',684,-512,100,function() GL.ShowMaster() end);button('Schließen',790,-512,94,function() f:Hide() end)
 M.EnableSizing(f)
 function f:Refresh()
  local r=GL.Active();local items=M.Items()
  f.TitleText:SetText('GuildLoot · Plündermeister'..(r and (' · '..(r.raidName or 'Raid')..' · Aufzeichnung läuft') or ' · keine Aufzeichnung'))
  local target=UnitName and UnitName('target')
  local open=#M.LootItems()>0
  heading:SetText(open and ('Aktuelle Beute'..(target and (' · '..target) or '')) or (#items>0 and 'Unverteilte Items (in Tasche)' or 'Kein Lootfenster geöffnet · keine unverteilten Items'))
  announceButton.label:SetText('Raidmeldung: '..(GL.db.lootAnnounce==false and 'aus' or 'an'));autoButton.label:SetText('Auto-öffnen: '..(GL.db.masterWindowAuto==false and 'aus' or 'an'))
  if not secondsBox:HasFocus() then secondsBox:SetText(tostring(tonumber(GL.db.rollSeconds) or 15)) end
  if not r then status:SetText('Ohne laufende Aufzeichnung werden Prios, Würfe und Vergaben nicht gespeichert. Plündermeister → Aufzeichnung starten.') elseif not M.IsMasterLooter() then status:SetText('Du bist nicht Plündermeister: Zuteilen ist nicht möglich, Meldungen und Historie funktionieren.') else status:SetText('') end
  if M.selectKey then selected=M.selectKey;M.selectKey=nil end
  local selectedItem
  for i,row in ipairs(rows) do
   local item=items[i];row.item=item;row:SetShown(item~=nil)
   if item then
    if item.key==selected then selectedItem=item end
    row.background:SetColorTexture(item.key==selected and .12 or .07,item.key==selected and .24 or .13,item.key==selected and .3 or .18,1)
    row.icon:SetTexture(item.icon or 'Interface\\Icons\\INV_Misc_QuestionMark')
    local c=QUALITY[item.quality] or QUALITY[1];row.name:SetText((item.quantity>1 and (item.quantity..'x ') or '')..item.itemName);row.name:SetTextColor(c[1],c[2],c[3])
    row.holders:SetText((item.pendingOnly and '|cff7f9aa6[Tasche]|r ' or '')..M.HolderText(M.Holders(r,item.itemId,item.itemName),4))
   end
  end
  if not selectedItem and items[1] then selectedItem=items[1];selected=items[1].key end
  for _,b in ipairs(candidateButtons) do b:Hide() end
  if selectedItem then
   local holders=M.Holders(r,selectedItem.itemId,selectedItem.itemName);local rolls=M.Rolls(selectedItem)
   detailTitle:SetText(selectedItem.itemName..' · '..M.HolderText(holders,8))
   if M.rollStart[selectedItem.key] then
    local parts={};for i,x in ipairs(rolls) do if i>10 then break end;local prio;for _,h in ipairs(holders) do if norm(h.player)==norm(short(x.player)) then prio=h.prio end end;parts[#parts+1]=short(x.player)..' '..x.roll..(prio and (' ('..prio..')') or '') end
    rollsText:SetText(#parts>0 and ('Würfe: '..table.concat(parts,' · ')) or 'Würfe: noch keine (1-100)')
   else rollsText:SetText('Noch nicht gewürfelt. „Würfeln“ kündigt das Item im Raid an und sammelt /roll für '..(tonumber(GL.db.rollSeconds) or 15)..' Sekunden.') end
   local candidates=M.Candidates(selectedItem.slot)
   local function score(c) local n=norm(short(c.name));for _,h in ipairs(holders) do if norm(h.player)==n then return -(10-(ORDER[h.prio] or 9)),h.prio end end;for _,x in ipairs(rolls) do if norm(short(x.player))==n then return -x.roll/1000,nil,x.roll end end;return 1 end
   for _,c in ipairs(candidates) do c.score,c.prio,c.roll=score(c) end
   table.sort(candidates,function(a,b) if a.score~=b.score then return a.score<b.score end;return a.name<b.name end)
   local pages=math.max(1,math.ceil(#candidates/12));candidatePage=math.min(candidatePage,pages)
   for i,b in ipairs(candidateButtons) do local c=candidates[(candidatePage-1)*12+i];b.candidate=c;b.info=c and {prio=c.prio,roll=c.roll} or nil;b:SetShown(c~=nil)
    if c then b.label:SetText(short(c.name)..(c.prio and (' · '..c.prio) or (c.roll and (' · '..c.roll) or '')));b.background:SetColorTexture(c.prio and .45 or (c.roll and .2 or .13),c.prio and .32 or (c.roll and .3 or .23),.1,1) end end
   candidateInfo:SetText(#candidates..' berechtigte Spieler · Seite '..candidatePage..' / '..pages..(M.IsMasterLooter() and '' or ' · nur als Plündermeister'))
  else detailTitle:SetText('');rollsText:SetText('');candidateInfo:SetText('') end
  local history=M.History(r)
  for i,row in ipairs(hist) do local e=history[i];row:SetShown(e~=nil);row.itemId=e and e.itemId
   if e then row.time:SetText(date('%H:%M',e.at or 0));row.player:SetText(e.player);row.item:SetText(e.itemName);local _,_,q=GetItemInfo(e.itemId or 0);local c=QUALITY[q or 1] or QUALITY[1];row.item:SetTextColor(c[1],c[2],c[3])
    row.prio:SetText(e.roll and ('Wurf '..e.roll) or e.priority);local matched=tostring(e.priority):match('^P[0123]');row.prio:SetTextColor(matched and .3 or .7,matched and 1 or .7,matched and .6 or .7) end end
  histTitle:SetText('Historie dieser Aufzeichnung · '..#history)
 end
 f:Refresh();f:Show()
end
local f=CreateFrame('Frame')
for _,e in ipairs({'LOOT_OPENED','LOOT_SLOT_CLEARED','LOOT_CLOSED','CHAT_MSG_LOOT','CHAT_MSG_SYSTEM','PLAYER_LOGIN'}) do f:RegisterEvent(e) end
f:SetScript('OnEvent',function(_,event,text)
 if event=='PLAYER_LOGIN' then if GL.db and GL.db.lootBarShown then M.ShowBar() end;return end
 if event=='CHAT_MSG_LOOT' then M.UntrackReceipt(text) end
 if event=='LOOT_OPENED' then
  local r=GL.Active();if not r or not GL.InInstance(r) or not M.IsMasterLooter() then return end
  local items=M.LootItems();M.Track(items);M.AnnounceLoot(items)
  if GL.db.masterWindowAuto~=false and #items>0 and not (M.bar and M.bar:IsShown()) then M.Show() end
 end
 if M.frame and M.frame:IsShown() then M.frame:Refresh() end
 if M.bar and M.bar:IsShown() then M.bar:Refresh() end
end)

-- Position und Größe je Fenster in GL.db speichern.
function M.SavePlacement(f,key)
 local point,_,relative,x,y=f:GetPoint();GL.db[key..'Position']={point,relative,x,y};GL.db[key..'Scale']=f:GetScale()
end
function M.RestorePlacement(f,key)
 local pos=GL.db[key..'Position'];if pos then f:ClearAllPoints();f:SetPoint(pos[1],UIParent,pos[2],pos[3],pos[4]) end
 local scale=tonumber(GL.db[key..'Scale']);if scale then f:SetScale(math.max(.5,math.min(1.6,scale))) end
end
function M.EnableSizing(f)
 local function resize(value) if InCombatLockdown() then return end;f:SetScale(math.max(.5,math.min(1.6,value)));M.SavePlacement(f,'masterWindow') end
 M.RestorePlacement(f,'masterWindow')
 local function control(text,x,fn) local b=CreateFrame('Button',nil,f,'UIPanelButtonTemplate');b:SetPoint('BOTTOMRIGHT',x,8);b:SetSize(30,20);b:SetText(text);b:SetScript('OnClick',fn);return b end
 control('−',-98,function() resize(f:GetScale()-.05) end);control('+',-66,function() resize(f:GetScale()+.05) end);control('1:1',-34,function() resize(1) end):SetWidth(32)
 local grip=CreateFrame('Button',nil,f);grip:SetPoint('BOTTOMRIGHT',-6,6);grip:SetSize(22,22)
 grip:SetNormalTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up');grip:SetHighlightTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight')
 local dragging
 grip:SetScript('OnMouseDown',function(_,button)
  if button~='LeftButton' or InCombatLockdown() then return end
  local cx,cy=GetCursorPosition();local ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale();local left,top=f:GetLeft()*ratio,f:GetTop()*ratio
  f:ClearAllPoints();f:SetPoint('TOPLEFT',UIParent,'BOTTOMLEFT',left,top)
  dragging={x=cx,y=cy,scale=f:GetScale(),width=900*f:GetEffectiveScale(),height=560*f:GetEffectiveScale()}
 end)
 local function stop() if dragging then dragging=nil;M.SavePlacement(f,'masterWindow') end end
 grip:SetScript('OnMouseUp',stop);f:HookScript('OnHide',stop)
 grip:SetScript('OnUpdate',function()
  if not dragging then return end
  if InCombatLockdown() or not IsMouseButtonDown('LeftButton') then stop();return end
  local x,y=GetCursorPosition();local dx=(x-dragging.x)/dragging.width;local dy=(dragging.y-y)/dragging.height
  resize(dragging.scale*(1+(math.abs(dx)>math.abs(dy) and dx or dy)))
 end)
 grip:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_TOP');GameTooltip:SetText('Fenstergröße');GameTooltip:AddLine('Ecke ziehen oder − / + verwenden. Größe und Position werden gespeichert.',1,1,1,true);GameTooltip:Show() end)
 grip:SetScript('OnLeave',function() GameTooltip:Hide() end)
end

-- Loot-Leiste: schlanke, halbtransparente Liste der unverteilten Items mit Würfel-, Vergabe- und Entfernen-Knopf je Zeile.
local BAR_WIDTH,BAR_ROWS=300,12
function M.ToggleBar() if M.bar and M.bar:IsShown() then M.HideBar() else M.ShowBar() end end
function M.HideBar() if M.bar then M.bar:Hide() end;if GL.db then GL.db.lootBarShown=false end end
function M.ShowBar()
 if GL.db then GL.db.lootBarShown=true end
 if M.bar then M.bar:Show();M.bar:Refresh();return end
 local bar=CreateFrame('Frame','GuildLootEraLootBar',UIParent);M.bar=bar
 bar:SetSize(BAR_WIDTH,30);bar:SetPoint('CENTER',UIParent,'CENTER',300,150);bar:SetFrameStrata('HIGH');bar:SetClampedToScreen(true);bar:SetMovable(true);bar:EnableMouse(true)
 bar:SetScript('OnMouseDown',function(self,button) if button=='LeftButton' and not GL.db.lootBarLocked and not InCombatLockdown() then self:StartMoving() end end)
 bar:SetScript('OnMouseUp',function(self) self:StopMovingOrSizing();M.SavePlacement(self,'lootBar') end)
 M.RestorePlacement(bar,'lootBar')
 local bg=bar:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.02,.05,.08,.55);bar.background=bg
 local head=bar:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');head:SetPoint('TOPLEFT',8,-8);head:SetWidth(150);head:SetJustifyH('LEFT');head:SetTextColor(.05,.9,.8);head:SetText('GuildLoot · Beute');bar.head=head
 local function small(text,x,w,fn,tip)
  local b=CreateFrame('Button',nil,bar);b:SetPoint('TOPRIGHT',x,-5);b:SetSize(w,20)
  local bbg=b:CreateTexture(nil,'BACKGROUND');bbg:SetAllPoints();bbg:SetColorTexture(.13,.23,.27,.9);b.background=bbg
  b.label=b:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');b.label:SetPoint('CENTER');b.label:SetText(text);b:SetScript('OnClick',fn)
  if tip then b:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_TOP');GameTooltip:SetText(tip);GameTooltip:Show() end);b:SetScript('OnLeave',function() GameTooltip:Hide() end) end
  return b
 end
 bar.lock=small('',-58,44,function() GL.db.lootBarLocked=not GL.db.lootBarLocked;bar:Refresh() end,'Sperren: Leiste nicht mehr verschieben')
 small('▣',-32,22,function() M.Show() end,'Plündermeister-Fenster')
 small('×',-6,22,function() M.HideBar() end,'Leiste ausblenden (/gle leiste)')
 bar.rows={}
 for i=1,BAR_ROWS do
  local row=CreateFrame('Frame',nil,bar);row:SetPoint('TOPLEFT',4,-30-(i-1)*24);row:SetSize(BAR_WIDTH-8,22)
  local rbg=row:CreateTexture(nil,'BACKGROUND');rbg:SetAllPoints();rbg:SetColorTexture(.06,.12,.16,i%2==0 and .55 or .75)
  local function rb(text,x,w,fn,tip)
   local b=CreateFrame('Button',nil,row);b:SetPoint('LEFT',x,0);b:SetSize(w,20)
   local bbg=b:CreateTexture(nil,'BACKGROUND');bbg:SetAllPoints();bbg:SetColorTexture(.13,.23,.27,.95);b.background=bbg
   b.label=b:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');b.label:SetPoint('CENTER');b.label:SetText(text);b:SetScript('OnClick',fn)
   b:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_TOP');GameTooltip:SetText(tip);GameTooltip:Show() end);b:SetScript('OnLeave',function() GameTooltip:Hide() end);return b
  end
  row.roll=rb('W',2,24,function() if row.item then M.StartRoll(row.item);bar:Refresh() end end,'Würfeln ankündigen und Würfe sammeln')
  row.icon=row:CreateTexture(nil,'ARTWORK');row.icon:SetPoint('LEFT',30,0);row.icon:SetSize(18,18)
  row.name=CreateFrame('Button',nil,row);row.name:SetPoint('LEFT',52,0);row.name:SetSize(BAR_WIDTH-8-52-56,20)
  row.name.text=row.name:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');row.name.text:SetPoint('LEFT');row.name.text:SetPoint('RIGHT');row.name.text:SetJustifyH('LEFT');row.name.text:SetWordWrap(false)
  row.name:SetScript('OnClick',function() if row.item then M.Show(row.item.key) end end)
  row.name:SetScript('OnEnter',function(self) if row.item then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetHyperlink(row.item.link);local rolls=M.Rolls(row.item);if #rolls>0 then GameTooltip:AddLine('Höchster Wurf: '..short(rolls[1].player)..' ('..rolls[1].roll..')',.3,1,.6) end;GameTooltip:AddLine('Klick: vergeben im Plündermeister-Fenster',.7,.85,1);GameTooltip:Show() end end)
  row.name:SetScript('OnLeave',function() GameTooltip:Hide() end)
  row.assign=rb('→',BAR_WIDTH-8-54,24,function() if row.item then M.Show(row.item.key) end end,'Vergeben (öffnet das Fenster mit diesem Item)')
  row.drop=rb('×',BAR_WIDTH-8-28,24,function() if row.item then M.Untrack(row.item.key);bar:Refresh() end end,'Aus der Liste entfernen')
  bar.rows[i]=row
 end
 bar.empty=bar:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');bar.empty:SetPoint('TOPLEFT',8,-32);bar.empty:SetWidth(BAR_WIDTH-16);bar.empty:SetJustifyH('LEFT');bar.empty:SetTextColor(.6,.7,.78)
 function bar:Refresh()
  local r=GL.Active();local items=M.Items();local shown=0
  self.lock.label:SetText(GL.db.lootBarLocked and 'Fest' or 'Frei')
  for i,row in ipairs(self.rows) do
   local item=items[i];row.item=item;row:SetShown(item~=nil)
   if item then
    shown=shown+1
    row.icon:SetTexture(item.icon or 'Interface\\Icons\\INV_Misc_QuestionMark')
    local c=QUALITY[item.quality] or QUALITY[1];row.name.text:SetText((item.quantity and item.quantity>1 and (item.quantity..'x ') or '')..item.itemName..(item.pendingOnly and ' (Tasche)' or ''));row.name.text:SetTextColor(c[1],c[2],c[3])
    local rolled=M.rollStart[item.key]~=nil;row.roll.background:SetColorTexture(rolled and .45 or .13,rolled and .32 or .23,rolled and .1 or .27,.95)
   end
  end
  self.empty:SetShown(shown==0);self.empty:SetText(r and 'Keine unverteilten Items.' or 'Keine Aufzeichnung aktiv.')
  self:SetHeight(34+math.max(1,shown)*24)
 end
 bar:Refresh();bar:Show()
end
