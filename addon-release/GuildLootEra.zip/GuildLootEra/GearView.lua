local _,GL=...
function GL.CreateGearView(parent,notify)
    local view=CreateFrame('Frame',nil,parent);view:SetPoint('TOPLEFT',24,-134);view:SetSize(890,556)
    local selected=16;local rotation=0;local pending;local picker;local stats;local openPicker
    local function label(owner,x,y,width,size)
        local l=owner:CreateFontString(nil,'OVERLAY','GameFontHighlight');l:SetFont(STANDARD_TEXT_FONT,size or 13);l:SetPoint('TOPLEFT',x,y);l:SetWidth(width);l:SetJustifyH('LEFT');l:SetWordWrap(false);return l
    end
    local function run(fn) local ok,err=pcall(fn);if not ok then notify(tostring(err):gsub('^.-:%d+: ','')) end end
    local function button(owner,text,x,y,width,fn)
        local b=CreateFrame('Button',nil,owner);b:SetPoint('TOPLEFT',x,y);b:SetSize(width,30)
        local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.09,.16,.2,1)
        local title=label(b,5,-7,width-10,13);b.text=title;title:SetJustifyH('CENTER');title:SetText(text)
        b:SetScript('OnEnter',function() bg:SetColorTexture(.18,.28,.32,1) end);b:SetScript('OnLeave',function() bg:SetColorTexture(.09,.16,.2,1) end)
        b:SetScript('OnClick',function() run(fn) end);return b
    end
    local nameInput=CreateFrame('EditBox',nil,view,'InputBoxTemplate');nameInput:SetPoint('TOPLEFT',188,-2);nameInput:SetSize(174,26);nameInput:SetAutoFocus(false);nameInput:SetMaxLetters(60)
    local placeholder=label(nameInput,6,-6,160,12);placeholder:SetText('Setname eingeben …');placeholder:SetTextColor(.6,.7,.76)
    nameInput:SetScript('OnTextChanged',function(self) placeholder:SetShown(self:GetText()=='') end)
    nameInput:SetScript('OnEscapePressed',function(self) self:ClearFocus() end)
    local savedLabel=label(view,0,-42,680,12);savedLabel:SetTextColor(.65,.77,.82)
    local modelBackdrop=view:CreateTexture(nil,'BACKGROUND');modelBackdrop:SetPoint('TOPLEFT',202,-70);modelBackdrop:SetSize(486,352);modelBackdrop:SetColorTexture(.045,.085,.12,1)
    local model=CreateFrame('DressUpModel',nil,view);model:SetPoint('TOPLEFT',210,-76);model:SetSize(260,340)
    model:EnableMouse(true);model:EnableMouseWheel(true)
    model:SetScript('OnMouseWheel',function(_,delta) rotation=rotation+delta*.2;model:SetFacing(rotation) end)
    model:SetScript('OnMouseDown',function(_,which) if which=='LeftButton' then rotation=rotation+.35;model:SetFacing(rotation) end end)
    local modelHint=label(view,224,-400,240,11);modelHint:SetText('Mausrad oder Pfeile: drehen');modelHint:SetTextColor(.6,.72,.8)
    local info=label(view,210,-427,470,13)
    local itemInput=CreateFrame('EditBox',nil,view,'InputBoxTemplate');itemInput:SetPoint('TOPLEFT',216,-449);itemInput:SetSize(324,26);itemInput:SetAutoFocus(false);itemInput:SetMaxLetters(500)
    itemInput:SetScript('OnEscapePressed',function(self) self:ClearFocus() end)
    view.slotButtons={}
    local function tooltip(b)
        local link=GL.GearStore().draft[b.slot]
        GameTooltip:SetOwner(b,'ANCHOR_RIGHT')
        if link then GameTooltip:SetHyperlink(link) else GameTooltip:SetText(GL.GearSlotNames[b.slot]) end
        GameTooltip:Show()
    end
    for i,slot in ipairs(GL.GearSlots) do
        local x,y,w
        if i<=8 then x,y,w=0,-78-(i-1)*48,194
        elseif i<=16 then x,y,w=696,-78-(i-9)*48,194
        else x,y,w=202+(i-17)*166,-491,158 end
        local b=CreateFrame('Button',nil,view);b.slot=slot;b:SetPoint('TOPLEFT',x,y);b:SetSize(w,44);b:RegisterForClicks('LeftButtonUp','RightButtonUp')
        b.bg=b:CreateTexture(nil,'BACKGROUND');b.bg:SetAllPoints()
        b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',5,-6);b.icon:SetSize(32,32)
        b.caption=label(b,44,-4,w-48,11);b.caption:SetText(GL.GearSlotNames[slot]);b.caption:SetTextColor(.6,.74,.82)
        b.item=label(b,44,-20,w-48,12);b.item:SetHeight(18)
        b:SetScript('OnEnter',tooltip);b:SetScript('OnLeave',function() GameTooltip:Hide() end)
        b:SetScript('OnClick',function(_,which) run(function()
            pending=nil;selected=slot
            itemInput:SetText('');view:Refresh()
            if which=='RightButton' then openPicker() else itemInput:SetFocus() end
        end) end)
        view.slotButtons[#view.slotButtons+1]=b
    end
    -- Panels occupy the model area, leaving every equipment slot accessible.
    local function panel()
        local f=CreateFrame('Frame',nil,view);f:SetPoint('TOPLEFT',202,-70);f:SetSize(486,352)
        local bg=f:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.045,.085,.12,1)
        f:EnableMouse(true);f:Hide();return f
    end
    picker=panel()
    stats=CreateFrame('Frame',nil,view);stats:SetPoint('TOPLEFT',478,-70);stats:SetSize(210,352)
    local statsBackground=stats:CreateTexture(nil,'BACKGROUND');statsBackground:SetAllPoints();statsBackground:SetColorTexture(.075,.12,.16,1)
    local pickerTitle=label(picker,12,-10,360,14)
    local query=CreateFrame('EditBox',nil,picker,'InputBoxTemplate');query:SetPoint('TOPLEFT',18,-38);query:SetSize(450,24);query:SetAutoFocus(false)
    local page=0;local candidates={};local choices={}
    local pageLabel=label(picker,110,-286,250,11)
    local function renderPicker()
        candidates=GL.GearCandidates(selected,query:GetText())
        page=math.max(0,math.min(page,math.max(0,math.ceil(#candidates/6)-1)))
        pickerTitle:SetText(GL.GearSlotNames[selected]..' · Item auswählen')
        for i,b in ipairs(choices) do
            local r=candidates[page*6+i];b.data=r;b:SetShown(r~=nil)
            if r then b.text:SetText(r.name);local c=ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[r.quality];b.text:SetTextColor(c and c.r or .8,c and c.g or .85,c and c.b or .9) end
        end
        pageLabel:SetText(#candidates..' Items · Seite '..(page+1)..' / '..math.max(1,math.ceil(#candidates/6)))
    end
    for i=1,6 do
        local b
        b=button(picker,'',12,-70-(i-1)*33,462,function()
            if b.data then view:PreviewItem(b.data.link);picker:Hide();model:Show();stats:Show();query:ClearFocus() end
        end)
        b:SetScript('OnEnter',function() if b.data then GameTooltip:SetOwner(b,'ANCHOR_RIGHT');GameTooltip:SetHyperlink(b.data.link);GameTooltip:Show() end end)
        b:SetScript('OnLeave',function() GameTooltip:Hide() end);choices[i]=b
    end
    query:SetScript('OnTextChanged',function() page=0;renderPicker() end)
    query:SetScript('OnEscapePressed',function() picker:Hide();model:Show();stats:Show();query:ClearFocus() end)
    button(picker,'<',12,-275,42,function() page=page-1;renderPicker() end)
    button(picker,'>',426,-275,48,function() page=page+1;renderPicker() end)
    button(picker,'Slot leeren',12,-314,130,function() GL.GearStore().draft[selected]=nil;picker:Hide();model:Show();stats:Show();view:Refresh() end)
    button(picker,'Zurück zur 3D-Ansicht',252,-314,222,function() picker:Hide();model:Show();stats:Show();query:ClearFocus() end)
    local catalogHint=label(picker,70,-304,345,10);catalogHint:SetText('Raid-Katalog, Taschen und bekannte Ausrüstung')
    openPicker=function() stats:Hide();model:Hide();picker:Show();query:SetText('');page=0;renderPicker();query:SetFocus();GameTooltip:Hide() end
    view.itemPicker=picker
    local statTitle=label(stats,12,-10,186,14);statTitle:SetText('Aktuelle Werte')
    local statHint=label(stats,12,-30,186,10);statHint:SetWordWrap(true);statHint:SetHeight(28);statHint:SetText('Angelegt inkl. Buffs\nKeine Wunschset-Berechnung');statHint:SetTextColor(.6,.74,.82)
    local statLabels={}
    for i=1,20 do statLabels[i]=label(stats,12,-64-(i-1)*14,186,11) end
    local function refreshStats()
        local values=GL.CurrentStatLines()
        statTitle:SetText('Werte · '..(UnitName('player') or 'Charakter'))
        for i,l in ipairs(statLabels) do
            local value=(values[i] or ''):gsub('Nahkampf%-Angriffskraft','Angriffskraft'):gsub('Zauberschaden ','Zauber · ')
            l:SetText(value);l:SetTextColor(i<=2 and .45 or .9,i<=2 and .95 or .94,i<=2 and .8 or .98)
        end
    end
    view.statPanel=stats
    function view:Refresh()
        refreshStats();stats:SetShown(not picker:IsShown())
        local store=GL.GearStore();local names=GL.GearSetNames()
        savedLabel:SetText((UnitName('player') or 'Charakter')..' · '..#names..' gespeicherte Sets · Vorschau verändert deine Ausrüstung erst mit „Anlegen“.')
        info:SetText('Itemlink oder ID eingeben · Auswahl: '..GL.GearSlotNames[selected])
        for _,b in ipairs(self.slotButtons) do
            local value=store.draft[b.slot];local name,_,quality,_,_,_,_,_,_,icon
            if value then name,_,quality,_,_,_,_,_,_,icon=GL.GearInfo(value) end
            local c=quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality]
            b.item:SetText(value and (name or ('Item '..tostring(GL.GearItemID(value)))) or 'Leer')
            b.item:SetTextColor(c and c.r or .6,c and c.g or .7,c and c.b or .76)
            b.icon:SetTexture(icon or 'Interface\\Icons\\INV_Misc_QuestionMark')
            b.bg:SetColorTexture(b.slot==selected and .17 or .07,b.slot==selected and .28 or .115,b.slot==selected and .3 or .15,1)
        end
        model:SetUnit('player');model:Undress()
        for _,slot in ipairs(GL.GearSlots) do local link=store.draft[slot]
            local location
            if link then local _,_,_,_,_,_,_,_,value=GL.GearInfo(link);location=value end
            if link and slot~=2 and slot~=11 and slot~=12 and slot~=13 and slot~=14 and location~='INVTYPE_RELIC' then model:TryOn(link,slot==16 and 'MAINHANDSLOT' or slot==17 and 'SECONDARYHANDSLOT' or nil) end
        end
        model:SetFacing(rotation)
    end
    function view:PreviewItem(value)
        local slot,id=GL.PlanGearItem(value,selected)
        if not slot then pending={value=value,id=id};notify('Itemdaten werden geladen …');return end
        pending=nil;selected=slot;self:Refresh();notify('Vorschau aktualisiert: '..GL.GearSlotNames[slot]..'. Mit Speichern als Set behalten.')
    end
    button(view,'Eigene Ausrüstung',0,0,168,function() pending=nil;GL.GearStore().draft=GL.CurrentGear();view:Refresh();notify('Aktuelle Ausrüstung in die Vorschau übernommen.') end)
    button(view,'Speichern',376,0,92,function() local name=GL.SaveGearSet(nameInput:GetText());nameInput:ClearFocus();view:Refresh();notify('Set „'..name..'“ für diesen Charakter gespeichert.') end)
    button(view,'Set laden >',480,0,116,function()
        local names=GL.GearSetNames();if #names==0 then error('Noch kein Set gespeichert. Links einen Setnamen eingeben.') end
        local index=0;for i,name in ipairs(names) do if name==GL.GearStore().selected then index=i end end
        local name=names[index%#names+1];GL.LoadGearSet(name);nameInput:SetText(name);pending=nil;view:Refresh();notify('Set geladen: '..name)
    end)
    button(view,'Set löschen',608,0,156,function() GL.DeleteGearSet(GL.GearStore().selected);nameInput:SetText('');view:Refresh();notify('Gespeichertes Set gelöscht. Die aktuelle Vorschau bleibt erhalten.') end)
    button(view,'Anlegen',782,0,108,function() local n=GL.EquipGearPlan();notify(n==0 and 'Geplante Items sind bereits angelegt.' or 'Ausrüstungswechsel angefordert. Spielmeldungen und angelegte Items prüfen; leere Slots bleiben unverändert.') end)
    button(view,'<',210,-378,32,function() rotation=rotation-.35;model:SetFacing(rotation) end)
    button(view,'>',436,-378,32,function() rotation=rotation+.35;model:SetFacing(rotation) end)
    button(view,'Anprobieren',554,-447,134,function() view:PreviewItem(itemInput:GetText());itemInput:ClearFocus() end)
    itemInput:SetScript('OnEnterPressed',function(self) run(function() view:PreviewItem(self:GetText());self:ClearFocus() end) end)
    local hint=label(view,0,-548,890,12);hint:SetText('Slot anklicken: auswählen · Rechtsklick: Itemliste · Werte rechts: angelegte Ausrüstung inkl. Buffs · Sets sind pro Charakter gespeichert.');hint:SetTextColor(.6,.74,.82)
    view:RegisterEvent('GET_ITEM_INFO_RECEIVED');view:RegisterEvent('PLAYER_EQUIPMENT_CHANGED');view:RegisterEvent('UNIT_STATS');view:RegisterEvent('UNIT_AURA');view:RegisterEvent('UNIT_MAXHEALTH');view:RegisterEvent('UNIT_MAXPOWER');view:RegisterEvent('UNIT_ATTACK_POWER');view:RegisterEvent('UNIT_RESISTANCES')
    view:SetScript('OnEvent',function(_,event,id,success)
        if not view:IsShown() or (event:match('^UNIT_') and id~='player') then return end
        run(function()
            if stats:IsShown() then refreshStats() end
            if event=='GET_ITEM_INFO_RECEIVED' and success and picker:IsShown() then
                for _,b in ipairs(choices) do if b.data and b.data.id==id then
                    local name,link,quality=GL.GearInfo(id);local c=ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality]
                    if name then b.text:SetText(name);b.data.link=link or b.data.link end
                    if c then b.text:SetTextColor(c.r,c.g,c.b) end
                end end
            end
            if event=='GET_ITEM_INFO_RECEIVED' and pending and pending.id==id then
                local value=pending.value;pending=nil
                if success then view:PreviewItem(value) else notify('Itemdaten nicht verfügbar. Bitte die Item-ID prüfen und erneut versuchen.') end
            elseif event=='GET_ITEM_INFO_RECEIVED' and success then
                for _,value in pairs(GL.GearStore().draft) do if GL.GearItemID(value)==id then view:Refresh();break end end
            end
        end)
    end)
    view:SetScript('OnHide',function() pending=nil;GameTooltip:Hide();itemInput:ClearFocus();nameInput:ClearFocus();query:ClearFocus();picker:Hide();stats:Hide();model:Show() end)
    view:SetScript('OnShow',function() run(function() nameInput:SetText(GL.GearStore().selected or '');view:Refresh() end) end)
    return view
end
