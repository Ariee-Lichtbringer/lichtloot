local _,GL=...
GL.GearSlots={1,2,3,15,5,4,19,9,10,6,7,8,11,12,13,14,16,17,18}
GL.GearSlotNames={[1]='Kopf',[2]='Hals',[3]='Schultern',[4]='Hemd',[5]='Brust',[6]='Taille',[7]='Beine',[8]='Füße',[9]='Handgelenke',[10]='Hände',[11]='Ring 1',[12]='Ring 2',[13]='Schmuck 1',[14]='Schmuck 2',[15]='Rücken',[16]='Waffenhand',[17]='Schildhand',[18]='Distanz',[19]='Wappenrock'}
local slots={INVTYPE_HEAD={1},INVTYPE_NECK={2},INVTYPE_SHOULDER={3},INVTYPE_BODY={4},INVTYPE_CHEST={5},INVTYPE_ROBE={5},INVTYPE_WAIST={6},INVTYPE_LEGS={7},INVTYPE_FEET={8},INVTYPE_WRIST={9},INVTYPE_HAND={10},INVTYPE_FINGER={11,12},INVTYPE_TRINKET={13,14},INVTYPE_CLOAK={15},INVTYPE_WEAPON={16,17},INVTYPE_2HWEAPON={16},INVTYPE_WEAPONMAINHAND={16},INVTYPE_WEAPONOFFHAND={17},INVTYPE_SHIELD={17},INVTYPE_HOLDABLE={17},INVTYPE_RANGED={18},INVTYPE_RANGEDRIGHT={18},INVTYPE_THROWN={18},INVTYPE_RELIC={18},INVTYPE_TABARD={19}}
function GL.GearItemID(value)
    local text=tostring(value or '')
    return tonumber(text:match('item:(%d+)') or text:match('^%s*(%d+)%s*$'))
end
local function copy(source) local out={};for _,slot in ipairs(GL.GearSlots) do out[slot]=source and source[slot] or nil end;return out end
function GL.GearStore()
    GL.db.gearCharacters=GL.db.gearCharacters or {}
    local key=UnitGUID('player');if not key then error('Charakter ist noch nicht geladen.') end
    local store=GL.db.gearCharacters[key]
    if not store then store={sets={}};GL.db.gearCharacters[key]=store end
    if not store.draft then store.draft=GL.CurrentGear() end
    return store
end
function GL.CurrentGear()
    local out={};for _,slot in ipairs(GL.GearSlots) do out[slot]=GetInventoryItemLink('player',slot) end;return out
end
function GL.GearInfo(value)
    local fn=GetItemInfo or (C_Item and C_Item.GetItemInfo)
    if fn then return fn(value) end
end
function GL.PlanGearItem(value,preferred)
    local id=GL.GearItemID(value);if not id or id<1 or id>1000000 then error('Bitte einen Itemlink oder eine Item-ID eingeben.') end
    local name,link,_,_,_,_,_,_,location=GL.GearInfo(id)
    if not name then
        if C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
        return nil,id
    end
    local allowed=slots[location];if not allowed then error('Dieses Item ist kein Ausrüstungsgegenstand.') end
    local slot=allowed[1];for _,candidate in ipairs(allowed) do if candidate==preferred then slot=preferred end end
    local store=GL.GearStore()
    -- Preserve enchants on pasted links and current equipped gear.
    store.draft[slot]=tostring(value):match('item:[^|%s]+') or link or ('item:'..id)
    if location=='INVTYPE_2HWEAPON' then store.draft[17]=nil end
    if slot==17 and store.draft[16] then local _,_,_,_,_,_,_,_,mainType=GL.GearInfo(store.draft[16]);if mainType=='INVTYPE_2HWEAPON' then store.draft[16]=nil end end
    return slot
end
function GL.SaveGearSet(name)
    name=tostring(name or ''):gsub('^%s+',''):gsub('%s+$','')
    if name=='' or #name>60 or name:find('[%z\1-\31|]') then error('Bitte einen Setnamen mit höchstens 60 Zeichen eingeben.') end
    local store=GL.GearStore();store.sets[name]=copy(store.draft);store.selected=name;return name
end
function GL.LoadGearSet(name)
    local store=GL.GearStore();if not store.sets[name] then error('Dieses Set wurde nicht gespeichert.') end
    store.draft=copy(store.sets[name]);store.selected=name
end
function GL.DeleteGearSet(name)
    local store=GL.GearStore();if not name or not store.sets[name] then error('Bitte zuerst ein gespeichertes Set laden.') end
    store.sets[name]=nil;store.selected=nil
end
function GL.GearSetNames()
    local names={};for name in pairs(GL.GearStore().sets) do names[#names+1]=name end;table.sort(names);return names
end
function GL.EquipGearPlan()
    if InCombatLockdown and InCombatLockdown() then error('Ausrüstung bitte außerhalb des Kampfes wechseln.') end
    if not EquipItemByName then error('Ausrüstungswechsel ist in diesem Client nicht verfügbar.') end
    local store=GL.GearStore();local needed,missing={},{}
    for _,slot in ipairs(GL.GearSlots) do local value=store.draft[slot];local id=GL.GearItemID(value)
        if id then needed[id]=(needed[id] or 0)+1 end
    end
    local count=GetItemCount or (C_Item and C_Item.GetItemCount)
    if not count then error('Inventar konnte nicht geprüft werden.') end
    for id,n in pairs(needed) do if count(id,false)<n then local name=GL.GearInfo(id);missing[#missing+1]=name or tostring(id) end end
    if #missing>0 then table.sort(missing);error('Fehlt in Taschen/Ausrüstung: '..table.concat(missing,', ')) end
    -- Empty planned slots are intentionally left unchanged; never move items to
    -- bags implicitly. Actual equip restrictions remain enforced by the client.
    local requested=0
    for _,slot in ipairs(GL.GearSlots) do local value=store.draft[slot]
        if value and GL.GearItemID(GetInventoryItemLink('player',slot))~=GL.GearItemID(value) then EquipItemByName(value,slot);requested=requested+1 end
    end
    return requested
end

-- The list is a raid catalog plus locally known inventory/imported items, not all WoW items.
function GL.GearCandidates(slot,search)
    local found={};search=tostring(search or ''):lower()
    local function add(value,fallback,knownSlots)
        local id=GL.GearItemID(value);if not id then return end
        local name,link,quality,_,_,_,_,_,location,icon=GL.GearInfo(id)
        local allowed=slots[location] or knownSlots
        if not allowed then return end
        local fits=false;for _,n in ipairs(allowed) do if n==slot then fits=true end end
        name=name or fallback or ('Item '..id)
        if fits and (search=='' or name:lower():find(search,1,true) or tostring(id)==search) then
            found[id]={id=id,name=name,link=link or ('item:'..id),quality=quality,icon=icon}
        end
    end
    for _,r in ipairs(GL.GearCatalog or {}) do add(r.id,r.name,r.slots) end
    for n,value in pairs(GL.CurrentGear()) do add(value,nil,{n}) end
    for n,value in pairs(GL.GearStore().draft) do add(value,nil,{n}) end
    for _,set in pairs(GL.GearStore().sets) do for n,value in pairs(set) do add(value,nil,{n}) end end
    local containers=C_Container
    local size=containers and containers.GetContainerNumSlots or GetContainerNumSlots
    local link=containers and containers.GetContainerItemLink or GetContainerItemLink
    if size and link then for bag=0,4 do for n=1,size(bag) do add(link(bag,n)) end end end
    local p=GL.DisplayPriorities and GL.DisplayPriorities()
    if p then for _,r in ipairs(p.rows) do add(r.itemId,r.itemName) end end
    local result={};for _,r in pairs(found) do result[#result+1]=r end
    table.sort(result,function(a,b) if a.name~=b.name then return a.name<b.name end return a.id<b.id end)
    return result
end
function GL.CurrentStatLines()
    local lines={}
    local function add(name,value) if type(value)=='number' then lines[#lines+1]=name..': '..string.format('%.0f',value) end end
    if UnitHealthMax then add('Leben',UnitHealthMax('player')) end
    if UnitPowerMax then add('Mana',UnitPowerMax('player',0)) end
    if UnitStat then for i,name in ipairs({'Stärke','Beweglichkeit','Ausdauer','Intelligenz','Willenskraft'}) do local _,effective=UnitStat('player',i);add(name,effective) end end
    if UnitArmor then local _,effective=UnitArmor('player');add('Rüstung',effective) end
    if UnitAttackPower then local base,pos,neg=UnitAttackPower('player');add('Nahkampf-Angriffskraft',(base or 0)+(pos or 0)+(neg or 0)) end
    if GetSpellBonusHealing then add('Bonusheilung',GetSpellBonusHealing()) end
    if GetSpellBonusDamage then for i,name in ipairs({'Heilig','Feuer','Natur','Frost','Schatten','Arkan'}) do add('Zauberschaden '..name,GetSpellBonusDamage(i+1)) end end
    for _,entry in ipairs({{'Nahkampf-Krit',GetCritChance},{'Ausweichen',GetDodgeChance},{'Parieren',GetParryChance},{'Blocken',GetBlockChance}}) do
        if entry[2] then lines[#lines+1]=entry[1]..': '..string.format('%.2f%%',entry[2]()) end
    end
    return lines
end
