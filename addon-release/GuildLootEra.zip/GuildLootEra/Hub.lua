local _,GL=...
-- GuildLoot-Hauptsymbol: ein frei verschiebbares Mini-Symbol mit dem GuildLoot-Logo.
-- Linksklick öffnet eine Auswahl aller Mini-Addons, Rechtsklick das Hauptfenster.
local H={};GL.Hub=H
local launcher,menu
local MEDIA='Interface\\AddOns\\GuildLootEra\\Media\\'
local function store() GL.db.hubShortcut=GL.db.hubShortcut or {};return GL.db.hubShortcut end
local function entries()
 return {
  {icon=MEDIA..'GuildLootLogo',coord={0,.37,0,1},title='GuildLoot',hint='Hauptfenster (/gle) · Haken: dieses Symbol (wieder einblenden unter Einstellungen · Sync)',shown=function() return GL.HubShortcutShown() end,toggle=function() GL.ToggleHubShortcut() end,run=function() if GL.Show then GL.Show() end end},
  {icon=MEDIA..'GuildLootLogo',coord={0,.37,0,1},title='Raidsheet',hint='Sheet des aktuellen Raids',shown=function() return GL.db.sheetShortcutShown~=false end,toggle=function() GL.ToggleSheetShortcut() end,run=function() local id=GL.CurrentSheetRaidId and GL.CurrentSheetRaidId();if not id then print('GuildLoot: Für diesen Raid ist noch kein Raid synchronisiert.');return end;GL.ShowSheetWindow(id) end},
  {icon=MEDIA..'GuildSkills',title='Berufe',hint='Berufsübersicht (/gle berufe)',shown=function() local st=GL.db.professionShortcuts;local x=st and st[UnitGUID('player') or 'player'];return x and x.shown==true end,toggle=function() if GL.ToggleProfessionShortcut then GL.ToggleProfessionShortcut() end end,run=function() GL.ShowProfessions() end},
  {icon=MEDIA..'GuildRaidBag',title='Raidcheck',hint='Taschen-Checkliste (/glcheck)',shown=function() return GL.RaidChecklist.Store().launcherShown~=false end,toggle=function() GL.RaidChecklist.ToggleLauncher() end,run=function() GL.RaidChecklist.Open() end},
  {icon=MEDIA..'GuildLootLogo',coord={0,.37,0,1},title='Loot-Leiste',hint='Plündermeister-Minifenster: unverteilte Beute, Würfeln und Vergeben (/gle leiste)',shown=function() return GL.db.lootBarShown==true end,toggle=function() GL.MasterLoot.ToggleBar() end,run=function() GL.MasterLoot.ToggleBar() end},
  {icon=MEDIA..'GuildBuff',title='Buffleiste',hint='Buffs zuweisen und posten (/gle buffs)',shown=function() return GL.db.buffPanelVisible==true end,toggle=function() GL.ToggleBuffs() end,run=function() GL.ToggleBuffs() end},
  {icon=MEDIA..'GuildBank',title='Gildenbank',hint='Bestand, Anträge und Export (/gle bank)',shown=function() return GL.GuildBankShortcutShown and GL.GuildBankShortcutShown()==true end,toggle=function() GL.ToggleGuildBankShortcut() end,run=function() GL.ToggleGuildBank() end},
  {icon=MEDIA..'GuildWhisper',title='Whisper',hint='Gespräche (/glw)',shown=function() return GL.Whispers and GL.Whispers.db and GL.Whispers.db.launcherShown==true end,toggle=function() GL.Whispers.ToggleLauncher() end,run=function() GL.Whispers.Toggle() end},
  {icon='Interface\\Icons\\INV_Chest_Plate03',title='Rüstungsteile',hint='Rüstungsteile beantragen (/glarmor)',run=function() GL.ArmorRequests.Open() end},
  {icon=MEDIA..'GuildHeal',title='GuildHeal',hint=_G.GuildHeal and 'Heilerframes: Einstellungen (/gheal)' or 'Nicht installiert (Paket „GuildLoot Mini-Addons“)',shown=function() local GH=_G.GuildHeal;return GH~=nil and GH.FramesShown()==true end,toggle=function() local GH=_G.GuildHeal;if GH then GH.ToggleFrames() end end,run=function() if _G.GuildHeal then _G.GuildHeal.ToggleConfig() else print('GuildLoot: GuildHeal ist nicht installiert.') end end},
 }
end
local function buildMenu()
 if menu then return menu end
 menu=CreateFrame('Frame','GuildLootEraHubMenu',UIParent,BackdropTemplateMixin and 'BackdropTemplate' or nil)
 menu:SetFrameStrata('DIALOG');menu:SetClampedToScreen(true);menu:EnableMouse(true)
 local bg=menu:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.05,.08,.11,.96)
 local border=menu:CreateTexture(nil,'BORDER');border:SetPoint('TOPLEFT',-1,1);border:SetPoint('BOTTOMRIGHT',1,-1);border:SetColorTexture(.35,.5,.6,.8);border:SetDrawLayer('BORDER',-1)
 local head=menu:CreateFontString(nil,'OVERLAY','GameFontNormal');head:SetPoint('TOPLEFT',10,-8);head:SetText('GuildLoot · Mini-Addons');head:SetTextColor(1,.8,.25)
 local list=entries();local y=-30;menu.checks={}
 for _,e in ipairs(list) do
  local row=CreateFrame('Button',nil,menu);row:SetPoint('TOPLEFT',6,y);row:SetSize(208,30)
  if e.shown then
   local check=CreateFrame('CheckButton',nil,menu,'UICheckButtonTemplate');check:SetSize(24,24);check:SetPoint('LEFT',row,'RIGHT',2,0)
   check:SetScript('OnClick',function(self) local ok,err=pcall(e.toggle);if not ok then print('GuildLoot: '..tostring(err)) end;self:SetChecked(e.shown()==true) end)
   check:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText(e.title..' · Symbol');GameTooltip:AddLine('Haken an: Symbol bzw. Leiste am Bildschirm anzeigen. Haken aus: ausblenden. Wird gespeichert.',1,1,1,true);GameTooltip:Show() end)
   check:SetScript('OnLeave',function() GameTooltip:Hide() end)
   check.entry=e;menu.checks[#menu.checks+1]=check
  end
  local hl=row:CreateTexture(nil,'HIGHLIGHT');hl:SetAllPoints();hl:SetColorTexture(.2,.32,.34,.7)
  local icon=row:CreateTexture(nil,'ARTWORK');icon:SetPoint('LEFT',4,0);icon:SetSize(24,24);icon:SetTexture(e.icon);if e.coord then icon:SetTexCoord(unpack(e.coord)) end
  local title=row:CreateFontString(nil,'OVERLAY','GameFontHighlight');title:SetPoint('LEFT',icon,'RIGHT',8,0);title:SetText(e.title)
  row:RegisterForClicks('LeftButtonUp','RightButtonUp')
  row:SetScript('OnClick',function() menu:Hide();local ok,err=pcall(e.run);if not ok then print('GuildLoot: '..tostring(err)) end end)
  row:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText(e.title);GameTooltip:AddLine(e.hint,1,1,1,true);GameTooltip:AddLine('Links- oder Rechtsklick: eigenes Fenster öffnen · Haken: Symbol ein/aus',.7,.85,1,true);GameTooltip:Show() end)
  row:SetScript('OnLeave',function() GameTooltip:Hide() end)
  y=y-31
 end
 local foot=menu:CreateFontString(nil,'OVERLAY','GameFontDisableSmall');foot:SetPoint('TOPLEFT',10,y-4);foot:SetWidth(232);foot:SetJustifyH('LEFT');foot:SetText('Haken rechts: Symbol ein- oder ausblenden. Rechtsklick auf das Symbol: Hauptfenster. Ziehen: verschieben.')
 menu:SetSize(252,-y+46)
 menu:SetScript('OnShow',function(self) for _,c in ipairs(self.checks) do c:SetChecked(c.entry.shown()==true) end end)
 menu:SetScript('OnUpdate',function(self) if not self:IsMouseOver(4,-4,-4,4) and not (self.owner and self.owner:IsMouseOver()) then self.away=(self.away or 0)+1;if self.away>90 then self:Hide() end else self.away=0 end end)
 menu:SetScript('OnHide',function(self) self.away=0 end)
 menu:Hide()
 return menu
end
function H.ToggleMenu(at)
 local m=buildMenu();local owner=at or launcher
 if m:IsShown() then m:Hide();return end
 if not owner then return end
 m:ClearAllPoints();local x,y=owner:GetCenter();local px,py=UIParent:GetCenter()
 if y and py and y<py then m:SetPoint('BOTTOM',owner,'TOP',0,4) else m:SetPoint('TOP',owner,'BOTTOM',0,-4) end
 m.owner=owner;m:Show();for _,c in ipairs(m.checks or {}) do c:SetChecked(c.entry.shown()==true) end
end
function GL.InitializeHubShortcut()
 if launcher or not GL.db then return end
 local s=store();launcher=CreateFrame('Button','GuildLootEraHubShortcut',UIParent);H.launcher=launcher
 launcher:SetSize(44,44);launcher:SetFrameStrata('HIGH');launcher:SetFrameLevel(101);launcher:SetClampedToScreen(true);launcher:SetMovable(true);launcher:EnableMouse(true);launcher:RegisterForDrag('LeftButton');launcher:RegisterForClicks('LeftButtonUp','RightButtonUp')
 local texture=launcher:CreateTexture(nil,'ARTWORK');texture:SetAllPoints();texture:SetTexture(MEDIA..'GuildLootLogo');texture:SetTexCoord(0,.37,0,1)
 launcher:SetHighlightTexture('Interface\\Buttons\\ButtonHilight-Square','ADD')
 local label=launcher:CreateFontString(nil,'OVERLAY','GameFontNormalSmall');label:SetPoint('TOP',launcher,'BOTTOM',0,-2);label:SetText('GuildLoot')
 launcher:SetPoint('CENTER',UIParent,'CENTER',s.x or -80,s.y or 0)
 launcher:SetScript('OnDragStart',function(self) GameTooltip:Hide();if menu then menu:Hide() end;self:StartMoving() end)
 launcher:SetScript('OnDragStop',function(self) self:StopMovingOrSizing();local x,y=self:GetCenter();local px,py=UIParent:GetCenter();local p=store();p.x=x-px;p.y=y-py end)
 launcher:SetScript('OnClick',function(_,which) if which=='RightButton' then if menu then menu:Hide() end;if GL.Show then GL.Show() end;return end;H.ToggleMenu() end)
 launcher:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:AddLine('GuildLoot',1,.8,.3);GameTooltip:AddLine('Linksklick: Auswahl der Mini-Addons',1,1,1);GameTooltip:AddLine('Rechtsklick: Hauptfenster',1,1,1);GameTooltip:AddLine('Ziehen: Symbol verschieben',.7,.8,.9);GameTooltip:Show() end)
 launcher:SetScript('OnLeave',function() GameTooltip:Hide() end)
 launcher:SetShown(s.shown~=false)
end
function GL.ToggleHubShortcut()
 GL.InitializeHubShortcut();local s=store();if s.x==nil and s.y==nil then launcher:ClearAllPoints();launcher:SetPoint('CENTER',UIParent,'CENTER',-80,0) end
 s.shown=not launcher:IsShown();launcher:SetShown(s.shown);if not s.shown and menu then menu:Hide() end;return s.shown
end
function GL.HubShortcutShown() local s=GL.db and GL.db.hubShortcut;return not s or s.shown~=false end
function GL.ResetHubShortcut() GL.InitializeHubShortcut();local s=store();s.x,s.y,s.shown=nil,nil,true;launcher:ClearAllPoints();launcher:SetPoint('CENTER',UIParent,'CENTER',-80,0);launcher:Show() end
local login=CreateFrame('Frame');login:RegisterEvent('PLAYER_LOGIN');login:SetScript('OnEvent',function() GL.InitializeHubShortcut() end)
SLASH_GUILDLOOTHUB1='/glehub';SlashCmdList.GUILDLOOTHUB=function() GL.ResetHubShortcut() end
