local _,GL=...
function GL.QueueWebsiteAction(raid,kind,payload)
    if GL.RequireGuildSync then GL.RequireGuildSync() end
    local personal=GL.DisplayProfile();if not personal then error('Bitte zuerst deinen Charakter synchronisieren.') end
    if GL.Active() and kind~='armor' and kind~='guildbank' and kind~='guildbankexport' then error('Bitte die laufende Raidaufzeichnung zuerst beenden.') end
    if kind~='signup' and kind~='prio' and kind~='leadprio' and kind~='create' and kind~='publish' and kind~='access' and kind~='upload' and kind~='update' and kind~='armor' and kind~='guildbank' and kind~='guildbankexport' and kind~='delete' and kind~='syncupdate' then error('Unbekannte Aktion.') end
    GL.db.outgoingRequests=GL.db.outgoingRequests or {};GL.db.outgoingReceipts=GL.db.outgoingReceipts or {}
    for id,r in pairs(GL.db.outgoingRequests) do
        if r.guild==GL.db.selectedGuild and r.player==personal.player and r.realm==personal.realm and r.raidId==raid.id and r.kind==kind and not GL.db.outgoingReceipts[id] then error('Dieser Auftrag wartet bereits auf Übertragung. Bitte /reload und die Sync-App prüfen.') end
    end
    -- Random-Raid, den dieser Spieler selbst erstellt hat: bekannten Lead-PIN einsetzen statt Gildenleitungszugang.
    if type(payload)=='table' and (kind=='publish' or kind=='access' or kind=='upload' or kind=='leadprio' or kind=='delete') and (type(payload.leadPin)~='string' or payload.leadPin:match('^%s*$')) then
        local known=GL.KnownLeadPin(raid.id);if known then payload.leadPin=known;payload.useSavedMaster=false end
    end
    GL.ArchiveConfirmedUploads()
    local total=0
    for id in pairs(GL.db.outgoingRequests) do
        if GL.db.outgoingReceipts[id] and GL.db.outgoingReceipts[id].state~='unknown' then GL.db.outgoingRequests[id]=nil;GL.db.outgoingReceipts[id]=nil else total=total+1 end
    end
    if total>=30 then error('Zu viele offene Aufträge. Bitte zuerst synchronisieren.') end
    GL.db.outgoingCounter=(GL.db.outgoingCounter or 0)+1
    local id=tostring(UnitGUID('player'))..'-'..GetServerTime()..'-'..GL.db.outgoingCounter
    GL.db.outgoingRequests[id]={id=id,guild=GL.db.selectedGuild,player=personal.player,realm=personal.realm,raidId=raid.id,kind=kind,payload=payload,createdAt=GetServerTime()}
    return id
end
function GL.WebsiteActionStatus(raidId)
    local p=GL.DisplayProfile();if not p then return '' end
    local latest
    for _,r in pairs(GL.db.outgoingRequests or {}) do if r.guild==GL.db.selectedGuild and r.player==p.player and r.realm==p.realm and r.raidId==raidId and (not latest or r.createdAt>=latest.createdAt) then latest=r end end
    if not latest then return '' end
    local receipt=(GL.db.outgoingReceipts or {})[latest.id]
    return receipt and receipt.message or 'Zum Senden bitte /reload eingeben. Danach Bestätigung in GuildLoot Sync prüfen.'
end

function GL.IsRandomRaid(raidId)
    if not raidId or not GL.db then return false end
    for _,profile in pairs(GL.db.guildProfiles or {}) do
        for _,r in ipairs(((profile or {}).activeRaids or {}).rows or {}) do if r.id==raidId then return r.random==1 end end
    end
    return false
end
-- Lead-PIN eines selbst erstellten Random-Raids (aus GL.db.createdRaids): Raidleitung ohne PIN-Eingabe.
function GL.KnownLeadPin(raidId)
    if not raidId or not GL.db then return nil end
    local pin
    for _,profile in pairs(GL.db.guildProfiles or {}) do
        for _,r in ipairs(((profile or {}).activeRaids or {}).rows or {}) do if r.id==raidId and r.random==1 then pin=r.prioPin end end
    end
    for _,e in ipairs(GL.db.createdRaids or {}) do
        if e.mode=='prio' and type(e.leadPin)=='string' and e.leadPin:match('^[A-Z2-9][A-Z2-9][A-Z2-9][A-Z2-9]$') and (e.serverId==raidId or (pin and e.playerPin==pin)) then return e.leadPin end
    end
    return nil
end
-- Gildenleitungszugang (einmal unter Plündermeister mit dem Gildenleitungs-PIN angemeldet, dauerhaft gespeichert).
function GL.HasGuildMasterAccess()
    local p=GL.DisplayProfile();if not p or not GL.db then return false end
    local guildKey=GL.db.selectedGuild..'\031'..p.player..'\031'..p.realm..'\031*'
    return (tonumber((GL.db.masterAccess or {})[guildKey]) or 0)>GetServerTime()
end
function GL.HasMasterAccess(raidId)
    if not raidId then return false end
    local p=GL.DisplayProfile();if not p then return false end
    local key=GL.db.selectedGuild..'\031'..p.player..'\031'..p.realm..'\031'..raidId
    local guildKey=GL.db.selectedGuild..'\031'..p.player..'\031'..p.realm..'\031*'
    -- Random-Raids (RMD) gehören keiner Gilde: der Gildenleitungszugang gilt dort nicht, nur der Lead-PIN des Raids.
    if GL.IsRandomRaid and GL.IsRandomRaid(raidId) then return GL.KnownLeadPin(raidId)~=nil or (tonumber((GL.db.masterAccess or {})[key]) or 0)>GetServerTime() end
    return math.max(tonumber((GL.db.masterAccess or {})[key]) or 0,tonumber((GL.db.masterAccess or {})[guildKey]) or 0)>GetServerTime()
end

function GL.QueueRaidUpload(recording,secret)
    if not recording or recording.guild~=GL.db.selectedGuild then error('Bitte das Protokoll der gewählten Gilde öffnen.') end
    if not recording.endedAt then error('Bitte zuerst die Aufzeichnung beenden.') end
    if type(secret)~='string' or #secret>100 or (secret:match('^%s*$') and not GL.HasPersistentMasterAccess()) then error('Bitte den Lead-PIN oder Plündermeister-PIN eingeben.') end
    local index
    for i,r in ipairs(GL.db.raids) do if r==recording then index=i;break end end
    if not index then error('Dieses Protokoll ist nicht mehr verfügbar.') end
    local text=GL.Export(index,true)
    if #text>24000000 then error('Das Protokoll ist für den automatischen Upload zu groß. Bitte manuell exportieren.') end
    local id=GL.QueueWebsiteAction({id=recording.raidId},'upload',{leadPin=secret,text=text,useSavedMaster=secret:match('^%s*$')~=nil})
    GL.db.outgoingRequests[id].recordingSession=recording.sessionId
    GL.db.outgoingRequests[id].recordingEndedAt=recording.endedAt
    return id
end

function GL.HasPersistentMasterAccess()
    local p=GL.DisplayProfile();if not p then return false end
    local key=GL.db.selectedGuild..'\031'..p.player..'\031'..p.realm..'\031*'
    return (GL.db.masterAccess or {})[key]==4102444800
end

-- Archive flags stay on the recording so pruning completed requests never loses history.
function GL.ArchiveRecording(recording,reason)
    if not recording or not recording.endedAt or recording==GL.Active() then error('Bitte zuerst die Aufzeichnung beenden.') end
    if recording.guild~=GL.db.selectedGuild and reason~='uploaded' then error('Bitte die passende Gilde auswählen.') end
    recording.archivedAt=GetServerTime();recording.archiveReason=reason or 'manual'
end
function GL.ArchiveConfirmedUploads()
    for id,q in pairs(GL.db.outgoingRequests or {}) do
        local receipt=(GL.db.outgoingReceipts or {})[id]
        if q.kind=='upload' and receipt and receipt.state=='success' and receipt.guild==q.guild and receipt.raidId==q.raidId and receipt.player==q.player and receipt.realm==q.realm then
            for _,r in ipairs(GL.db.raids or {}) do
                local legacy=not q.recordingSession and q.payload and type(q.payload.text)=='string' and r.sessionId and q.payload.text:find('"sessionId":"'..r.sessionId..'"',1,true)
                if not r.archivedAt and r.endedAt and r~=GL.Active() and r.guild==q.guild and r.raidId==q.raidId and (q.recordingSession==r.sessionId or legacy) and (q.recordingEndedAt==r.endedAt or (legacy and r.endedAt<=q.createdAt)) then
                    GL.ArchiveRecording(r,'uploaded');r.uploadConfirmedAt=receipt.at
                end
            end
        end
    end
end
function GL.RecordingList(archived)
    local rows={}
    for i=#(GL.db.raids or {}),1,-1 do
        local r=GL.db.raids[i]
        if r.guild==GL.db.selectedGuild and (r.archivedAt~=nil)==(archived==true) then rows[#rows+1]=r end
    end
    return rows
end
