local _,GL=...
-- Calendar arithmetic uses UTC civil days, independent of the computer time zone.
local function civilDays(y,m,d)
    if m<=2 then y=y-1 end
    local era=math.floor(y/400);local year=y-era*400
    local month=m+(m>2 and -3 or 9)
    return era*146097+year*365+math.floor(year/4)-math.floor(year/100)+math.floor((153*month+2)/5)+d-1-719468
end
local function berlinOffset(epoch)
    local y=date('!*t',epoch).year
    local march=civilDays(y,3,31);local october=civilDays(y,10,31)
    local begins=(march-(march+4)%7)*86400+3600
    local ends=(october-(october+4)%7)*86400+3600
    return epoch>=begins and epoch<ends and 7200 or 3600
end
GL.CalendarCivilDays=civilDays
GL.CalendarBerlinOffset=berlinOffset
function GL.CalendarPlan(now)
    now=now or GetServerTime()
    local localDate=date('!*t',now+berlinOffset(now))
    local first=civilDays(localDate.year,localDate.month,localDate.day);local events={}
    for n=0,89 do
        local days=first+n;local d=date('!*t',days*86400)
        local function add(kind,name,clock)
            local at=days*86400+(clock and 9 or 0)*3600
            -- Reset at 09:00 is after DST transitions; midnight is before them.
            local offset=berlinOffset(at-3600)
            events[#events+1]={kind=kind,name=name,date=string.format('%04d-%02d-%02d',d.year,d.month,d.day),clock=clock and '09:00' or '',startsAt=at-offset}
        end
        if (days+4)%7==3 then add('reset','MC / BWL / AQ40 / Naxx: Reset',true) end
        if (days-civilDays(2026,6,20))%3==0 then add('reset','ZG / AQ20: Reset',true) end
        if (days-civilDays(2026,6,21))%5==0 then add('reset','Onyxia: Reset',true) end
        local firstWeekday=(civilDays(d.year,d.month,1)+4)%7
        local opening=1+(5-firstWeekday)%7+3
        if d.day>=opening and d.day<opening+7 then add('dmf',d.day==opening and 'Dunkelmond-Jahrmarkt beginnt' or 'Dunkelmond-Jahrmarkt geöffnet',false) end
    end
    table.sort(events,function(a,b) if a.startsAt~=b.startsAt then return a.startsAt<b.startsAt end return a.name<b.name end)
    return events
end
function GL.CalendarText()
    local out={'DEINE AKTUELLEN RAID-IDs (LIVE AUS WOW)'}
    local found=false
    if GetNumSavedInstances and GetSavedInstanceInfo then
        for i=1,GetNumSavedInstances() do
            local name,_,reset,_,locked,_,_,isRaid=GetSavedInstanceInfo(i)
            if locked and isRaid and reset and reset>0 then
                found=true;out[#out+1]=name..': frei ab '..date('%d.%m.%Y %H:%M',GetServerTime()+reset)
            end
        end
    end
    if not found then out[#out+1]='Keine aktiven Raid-IDs vom Spiel gemeldet.' end
    local p=GL.DisplayProfile()
    out[#out+1]='';out[#out+1]=p and ('ANMELDUNGEN: '..p.player..' – '..p.realm..' · STAND '..date('%d.%m.%Y %H:%M',p.exportedAt)) or 'MEINE ANMELDUNGEN'
    if not p then out[#out+1]='Der allgemeine Kalender ist ohne Import verfügbar. Ein persönlicher Import ergänzt deine Anmeldungen und Prio-Hinweise.' end
    local now=GetServerTime();local entries={}
    for _,r in ipairs(p and p.calendar or {}) do if not r.startsAt or r.startsAt>=now-4*3600 then entries[#entries+1]=r end end
    table.sort(entries,function(a,b) return (a.startsAt or math.huge)<(b.startsAt or math.huge) end)
    for _,r in ipairs(entries) do
        out[#out+1]=r.date..' '..(r.clock~='' and r.clock or 'Uhrzeit offen')..' · '..r.name
        out[#out+1]=not r.needsPrio and '  Keine Prio erforderlich' or r.hasPrio and '  |cff79e6a2Prio eingetragen|r' or '  |cffffcc40Prio fehlt – bitte auf der Webseite eintragen|r'
    end
    if p and #entries==0 then out[#out+1]='Keine kommenden, eindeutig zugeordneten Anmeldungen im Export.' end
    out[#out+1]='';out[#out+1]='RESET- UND DUNKELMOND-PLAN (EU / EUROPE-BERLIN)'
    out[#out+1]='Lokal berechnet, immer die nächsten 90 Tage – kein Import erforderlich. Live-Raid-IDs oben sind maßgeblich.'
    local events={};for _,e in ipairs(GL.CalendarPlan(now)) do if e.startsAt>=now-(e.clock=='' and 86400 or 0) then events[#events+1]=e end end
    table.sort(events,function(a,b) if a.startsAt~=b.startsAt then return a.startsAt<b.startsAt end return a.name<b.name end)
    for _,e in ipairs(events) do out[#out+1]=e.date..' '..e.clock..' · '..(e.kind=='dmf' and '|cffca91ff' or '|cff9ac6e8')..e.name..'|r' end
    out[#out+1]='';out[#out+1]='Erinnerungen: beim Einloggen innerhalb von 24 Stunden und einmal in der letzten Stunde vor dem Raid. Nur im Spiel; Grundlage ist der letzte Import.'
    out[#out+1]='Mit /gle erinnerung lassen sich die Hinweise ein- und ausschalten.'
    return table.concat(out,'\n')
end
function GL.CheckPrioReminders()
    if not GL.db or GL.db.prioReminders==false then return {} end
    local p=GL.MyProfile();if not p then return {} end
    local now=GetServerTime();p.reminded=p.reminded or {};local messages={}
    for _,r in ipairs(p.calendar or {}) do
        local left=r.startsAt and r.startsAt-now
        if r.needsPrio and not r.hasPrio and left and left>0 and left<=86400 then
            local stage=left<=3600 and 'hour' or 'day';local key=r.id..':'..r.startsAt..':'..stage
            if not p.reminded[key] then
                p.reminded[key]=true
                messages[#messages+1]='Prio-Erinnerung: '..r.name..' am '..r.date..' um '..r.clock..'. Laut Import vom '..date('%d.%m. %H:%M',p.exportedAt)..' fehlt deine Prio. Bitte auf der Webseite eintragen oder den Import aktualisieren.'
            end
        end
    end
    return messages
end
local frame=CreateFrame('Frame');frame:RegisterEvent('PLAYER_ENTERING_WORLD')
local function remind() for _,msg in ipairs(GL.CheckPrioReminders()) do print('|cffffcc40GuildLoot:|r '..msg) end end
frame:SetScript('OnEvent',function() if C_Timer and C_Timer.After then C_Timer.After(5,remind) else remind() end end)
local elapsed=0
frame:SetScript('OnUpdate',function(_,delta) elapsed=elapsed+delta;if elapsed>=60 then elapsed=0;remind() end end)
