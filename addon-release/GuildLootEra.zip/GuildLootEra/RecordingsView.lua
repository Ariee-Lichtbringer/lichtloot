local _,GL=...
-- Vergangene Raids als Kacheln (aufgezeichnete Raids dieser Gilde): Klick öffnet das Protokoll.
local INSTANCE_KEYS={[409]='mc',[469]='bwl',[249]='ony',[309]='zg',[509]='aq20',[531]='aq40',[533]='naxx'}
function GL.RecordingRaidKey(r) return r and (INSTANCE_KEYS[tonumber(r.instanceId)] or tostring(r.raidId or ''):lower():match('^(%a+%d*)')) or nil end
function GL.PastRecordings()
    local rows={}
    for i=#(GL.db.raids or {}),1,-1 do local r=GL.db.raids[i];if r.guild==GL.db.selectedGuild then rows[#rows+1]=r end end
    table.sort(rows,function(a,b) return (a.startedAt or 0)>(b.startedAt or 0) end)
    return rows
end
function GL.CreateRecordingsView(parent,open)
    local view=CreateFrame('Frame',nil,parent);view:SetPoint('TOPLEFT',24,-162);view:SetSize(890,630)
    local theme=GL.GuildTheme()
    local function label(owner,x,y,w,size)
        local l=owner:CreateFontString(nil,'OVERLAY','GameFontHighlight');l:SetPoint('TOPLEFT',x,y);l:SetWidth(w);l:SetJustifyH('LEFT');l:SetFont(STANDARD_TEXT_FONT,size);l:SetTextColor(.72,.82,.88);return l
    end
    local function button(text,x,y,w,fn,owner)
        local b=CreateFrame('Button',nil,owner or view);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,24)
        local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.13,.23,.27,1);b.background=bg
        local l=label(b,8,-7,w-16,13);l:SetText(text);b.label=l;b:SetScript('OnClick',fn);return b
    end
    local function pill(owner,x,y,w) local f=CreateFrame('Frame',nil,owner);f:SetPoint('TOPLEFT',x,y);f:SetSize(w,18);f.bg=f:CreateTexture(nil,'BACKGROUND');f.bg:SetAllPoints();f.bg:SetColorTexture(.1,.17,.22,1);f.text=label(f,0,-4,w,10);f.text:SetJustifyH('CENTER');return f end
    local heading=label(view,0,0,500,22);heading:SetTextColor(.15,.9,.8)
    local context=label(view,0,-34,890,12)
    local countLabel=label(view,0,-78,570,13)
    local page=1;local cards={}
    for i=1,6 do
        local col,row=(i-1)%2,math.floor((i-1)/2)
        local card=CreateFrame('Frame',nil,view);card:SetPoint('TOPLEFT',col*452,-104-row*160);card:SetSize(438,150)
        local border=card:CreateTexture(nil,'BACKGROUND');border:SetPoint('TOPLEFT',-1,1);border:SetPoint('BOTTOMRIGHT',1,-1);border:SetColorTexture(theme.accent[1],theme.accent[2],theme.accent[3],.55);border:SetDrawLayer('BACKGROUND',-1)
        local bg=card:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.03,.06,.1,1)
        card.icon=card:CreateTexture(nil,'ARTWORK');card.icon:SetPoint('TOPLEFT',10,-10);card.icon:SetSize(48,48)
        card.title=label(card,68,-10,250,14);card.title:SetTextColor(1,1,1)
        card.when=label(card,68,-30,250,11)
        card.state=pill(card,300,-12,128)
        card.recorder=pill(card,10,-66,200);card.recorder.text:SetTextColor(theme.accent[1],theme.accent[2],theme.accent[3])
        card.drops=label(card,10,-90,80,16);card.drops:SetTextColor(1,1,1);card.dropsLabel=label(card,10,-108,80,10);card.dropsLabel:SetText('Drops');card.dropsLabel:SetTextColor(.6,.7,.78)
        card.receipts=label(card,90,-90,80,16);card.receipts:SetTextColor(1,1,1);card.receiptsLabel=label(card,90,-108,90,10);card.receiptsLabel:SetText('Vergaben');card.receiptsLabel:SetTextColor(.6,.7,.78)
        card.awards=label(card,180,-90,60,16);card.awards:SetTextColor(theme.accent[1],theme.accent[2],theme.accent[3]);card.awardsLabel=label(card,180,-108,60,10);card.awardsLabel:SetText('Würfe');card.awardsLabel:SetTextColor(.6,.7,.78)
        card.open=button('Protokoll →',328,-120,102,function() if card.recording then open(card.recording) end end,card);card.open:SetHeight(24)
        card.open.background:SetColorTexture(theme.accent[1],theme.accent[2],theme.accent[3],1);card.open.label:SetTextColor(.05,.08,.12);card.open.label:SetFont(STANDARD_TEXT_FONT,11)
        card.upload=button('Hochladen',218,-120,104,function() if card.recording then open(card.recording);if GL.ShowUploadDialog then GL.ShowUploadDialog() end end end,card);card.upload:SetHeight(24);card.upload.label:SetFont(STANDARD_TEXT_FONT,11)
        card:EnableMouse(true);card:SetScript('OnMouseUp',function() if card.recording then open(card.recording) end end)
        cards[i]=card
    end
    local empty=label(view,16,-135,850,15)
    local pages=label(view,365,-594,250,13)
    button('<',0,-586,64,function() page=math.max(1,page-1);view:Refresh() end)
    button('>',826,-586,64,function() page=page+1;view:Refresh() end)
    local hint=label(view,0,-56,890,11);hint:SetText('Kachel anklicken: Protokoll mit empfangenen Items, Drops, Handel und Würfen. Erfolgreiche Uploads werden automatisch archiviert.')
    local weekdays={'So','Mo','Di','Mi','Do','Fr','Sa'}
    function view:Refresh()
        local rows=GL.PastRecordings()
        heading:SetText('Vergangene Raids · '..GL.GuildName(GL.db.selectedGuild))
        context:SetText('Aufzeichnungen dieses Charakters für diese Gilde · neueste zuerst')
        countLabel:SetText(#rows..' aufgezeichnete Raids')
        local max=math.max(1,math.ceil(#rows/6));page=math.min(page,max);pages:SetText('Seite '..page..' / '..max)
        empty:SetShown(#rows==0);empty:SetText('Noch keine Raidaufzeichnung für diese Gilde. Plündermeister → Aufzeichnung starten.')
        for i,card in ipairs(cards) do
            local r=rows[(page-1)*6+i];card:SetShown(r~=nil);card.recording=r
            if r then
                card.title:SetText(r.raidName or 'Raid')
                local started=r.startedAt or 0
                card.when:SetText(weekdays[tonumber(date('%w',started))+1]..' '..date('%d.%m.%Y · %H:%M',started)..(r.endedAt and (' bis '..date('%H:%M',r.endedAt)) or ''))
                card.icon:SetTexture(GL.RaidIcon(GL.RecordingRaidKey(r)))
                local running=not r.endedAt
                card.state.text:SetText(running and 'Läuft' or (r.archivedAt and 'Archiviert' or 'Beendet · nicht hochgeladen'))
                card.state.text:SetTextColor(running and .47 or (r.archivedAt and .72 or 1),running and .9 or (r.archivedAt and .82 or .8),running and .64 or (r.archivedAt and .88 or .25))
                card.recorder.text:SetText('Aufzeichnung: '..tostring(r.recorder or '?'):gsub('%-.*$',''))
                card.drops:SetText(tostring(#(r.drops or {})));card.receipts:SetText(tostring(#(r.receipts or {})))
                local rolls=0;for _,e in ipairs(r.chatEvidence or {}) do if e.kind=='roll' then rolls=rolls+1 end end;card.awards:SetText(tostring(rolls))
                card.upload:SetShown(not running and not r.archivedAt)
            end
        end
    end
    view:EnableMouseWheel(true);view:SetScript('OnMouseWheel',function(_,delta) page=math.max(1,page+(delta<0 and 1 or -1));view:Refresh() end)
    return view
end
