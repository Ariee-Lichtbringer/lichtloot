local _,GL=...
local function trim(s) return (s:gsub('^%s+',''):gsub('%s+$','')) end
local function split(s)
    local t={};for f in (s..'\t'):gmatch('(.-)\t') do t[#t+1]=trim(f) end;return t
end
function GL.ParseLegacyPriorities(text)
    local p={legacy=true,raidName='Prio3-Reforged-Liste',guild='Noch nicht zugeordnet',raidDate='',exportedAt=GetServerTime(),rows={}}
    local seen={};local lineNo=0
    for line in (text..'\n'):gmatch('(.-)\n') do
        lineNo=lineNo+1
        if trim(line)~='' then
            local f=split(line)
            if #f==6 and f[2]=='' then table.remove(f,2) end
            if #f==1 then
                local player,class,rest=line:match("^%s*(%S+)%s+(%S+)%s+(.+)$")
                if player then
                    local items={};rest=trim(rest)
                    -- WoW's edit box can expand tabs to spaces. Suffix item IDs
                    -- delimit the three columns without splitting item names.
                    while rest~="" and #items<3 do
                        local item,tail=rest:match("^(.-%-%d+)%s+(.*)$")
                        if not item then item=rest;tail="" end
                        items[#items+1]=trim(item);rest=trim(tail)
                    end
                    if #items==3 and rest=="" then f={player,class,items[1],items[2],items[3]} end
                end
            end
            if #f~=5 or f[1]=='' or f[2]=='' then error('Prio3-Zeile '..lineNo..': erwartet werden Spieler, Klasse und drei durch Tab getrennte Items. Bitte den ursprünglichen Textexport kopieren.') end
            if #f[1]>100 or #f[2]>60 then error('Ungültiger Spieler oder Klasse in Zeile '..lineNo) end
            for slot=1,3 do
                local value=f[slot+2]
                if value~='' and value~='-0' and value~='-' then
                    local id,name=value:match('^(%d+)%-(.+)$')
                    if not id then name,id=value:match('^(.-)%-(%d+)$') end
                    if not id or tonumber(id)<1 or tonumber(id)>1000000 or not name or trim(name)=='' then
                        error('Prio3-Zeile '..lineNo..': Item-ID fehlt oder ist ungültig bei '..value..'. Bitte einen vollständigen Export verwenden.')
                    end
                    local key=f[1]..':'..slot
                    if seen[key] then error('Spieler mehrfach enthalten: '..f[1]) end;seen[key]=true
                    p.rows[#p.rows+1]={player=f[1],realm='',class=f[2],priority='P'..slot,itemName=trim(name),itemId=tonumber(id),bench=false}
                    if #p.rows>5000 then error('Zu viele Einträge.') end
                end
            end
        end
    end
    if #p.rows==0 then error('Die Liste enthält keine Prioritäten.') end
    return p
end
function GL.BindLegacy(guild,raidId,code)
    if GL.Active() then error('Bitte den laufenden Raid zuerst beenden.') end
    local p=GL.db.priorities
    if not p or not p.legacy then error('Diese Zuordnung ist nur bei einer importierten Prio3-Liste nötig.') end
    guild=trim(guild or ''):lower();raidId=trim(raidId or '');code=trim(code or ''):lower()
    local instances={mc=409,bwl=469,ony=249,zg=309,aq20=509,aq40=531,naxx=533}
    if not guild:match('^[a-z0-9][a-z0-9%-]*$') or #guild>100 then error('Bitte die GuildLoot-Gildenkennung aus der Website verwenden, z. B. lichtloot.') end
    if raidId=='' or #raidId>160 or raidId:find('[%z\1-\32]') then error('Bitte die genaue Raid-ID von der Website oder dem Exportdateinamen angeben.') end
    if not instances[code] then error('Raid: mc, bwl, ony, zg, aq20, aq40 oder naxx angeben.') end
    local oldGuild=GL.db.selectedGuild
    p.guild=guild;p.raidId=raidId;p.instanceId=instances[code];p.raidName=code:upper();p.raidDate=date('%Y-%m-%d',GetServerTime())
    if oldGuild and oldGuild~=guild then GL.db.guildProfiles[oldGuild].priorities=nil end
    GL.StoreGuildData(guild,'priorities',p)
end

-- Same five-column CSV as the website's Prio3 export (no header).
function GL.ExportPrio3(raidId)
    local list,raid
    if raidId then
        local data=(GL.db.guildProfiles[GL.db.selectedGuild] or {}).activeRaids or {}
        list=data.lists and data.lists[raidId]
        for _,r in ipairs(data.rows or {}) do if r.id==raidId then raid=r end end
        if not list or list.published~=1 then error('Prio3-Export erst nach Veröffentlichung der Prioliste verfügbar.') end
    else
        local p=GL.db.priorities
        if not p or not p.rows or #p.rows==0 then error('Bitte zuerst eine vollständige Raid-Prioliste importieren oder einen veröffentlichten aktiven Raid öffnen.') end
        local players={};list={rows={}}
        for _,r in ipairs(p.rows) do
            if not r.bench and r.priority and r.priority:match('^P[123]$') then
                local key=r.player..'\031'..(r.realm or '');local entry=players[key]
                if not entry then entry={player=r.player,className=r.class or '',realm=r.realm or ''};players[key]=entry;list.rows[#list.rows+1]=entry end
                entry[r.priority:lower()..'Id']=r.itemId
            end
        end
        raid={raid=p.instanceId==249 and 'ony' or ''}
    end
    local function cell(value) return (tostring(value or ''):gsub('[;\r\n\t]',',')) end
    local lines={}
    for _,r in ipairs(list.rows or {}) do
        if r.bench~=1 then
            local fields={cell(r.player),cell(r.className)}
            for i=1,3 do local id=tonumber(r['p'..i..'Id']);fields[#fields+1]=(raid and raid.raid=='ony' and i>1) and '' or (id and id>0 and tostring(id) or '') end
            lines[#lines+1]=table.concat(fields,';')
        end
    end
    if #lines==0 then error('Keine exportierbaren Prioritäten vorhanden.') end
    return table.concat(lines,'\n')
end
