local _,GL=...
local W={};GL.Whispers=W
local window,chat,input,target,info,launcher,badge,background
local settingsPanel
local rows,offset={},0
local tabs,addTarget={},nil
local channelNames={GUILD='Gildenchat',PARTY='Gruppenchat',RAID='Raidchat'}
local channelEvents={CHAT_MSG_GUILD='GUILD',CHAT_MSG_PARTY='PARTY',CHAT_MSG_PARTY_LEADER='PARTY',CHAT_MSG_RAID='RAID',CHAT_MSG_RAID_LEADER='RAID',CHAT_MSG_RAID_WARNING='RAID'}
local function trim(s) return tostring(s or ''):gsub('^%s+',''):gsub('%s+$','') end
local function safe(s) return tostring(s or ''):gsub('|','||') end
local function now() return GetServerTime() end
local function realmName(realm)
 realm=trim(realm):gsub('%s','');local current=GetNormalizedRealmName and GetNormalizedRealmName() or GetRealmName():gsub('%s','')
 if realm:lower()==current:lower() then return current end
 if realm:lower()=='lakeshire' then return 'Lakeshire' end
 if realm:lower()=='everlook' then return 'Everlook' end
 return realm
end
local function normalized(name,guid)
 name=trim(name)
 if name=='' or #name>100 or name:find('[|%c]') then return nil end
 local character,realm=name:match('^([^%s%-]+)%s*%-%s*(.+)$')
 if not character then character,realm=name:match('^([^%s]+)%s+(.+)$') end
 if character then realm=realmName(realm);if realm=='' or realm:find('%-') then return nil end;return character..'-'..realm end
 if name:find('%s') then return nil end
 if guid and GetPlayerInfoByGUID then local _,_,_,_,_,n,r=GetPlayerInfoByGUID(guid);if n and n~='' then return n..'-'..realmName(r and r~='' and r or GetRealmName()) end end
 local matches={};local function remember(full) if full and full:match('^([^%-]+)'):lower()==name:lower() then matches[full:lower()]=full end end
 if UnitFullName then
  local function rememberUnit(unit) local n,r=UnitFullName(unit);if n then remember(n..'-'..realmName(r and r~='' and r or GetRealmName())) end end
  rememberUnit('target');rememberUnit('focus')
  if IsInRaid and IsInRaid() then for i=1,(GetNumGroupMembers and GetNumGroupMembers() or 0) do rememberUnit('raid'..i) end
  else for i=1,(GetNumSubgroupMembers and GetNumSubgroupMembers() or 0) do rememberUnit('party'..i) end end
 end
 if GetNumGuildMembers and GetGuildRosterInfo then for i=1,GetNumGuildMembers() do local full=GetGuildRosterInfo(i);if full and full:find('-',1,true) then remember(full) end end end
 for _,thread in pairs(W.db and W.db.threads or {}) do if thread.kind=='WHISPER' and #thread.messages>0 and thread.recipient:find('-',1,true) then remember(thread.recipient) end end
 local found,count=nil,0;for _,full in pairs(matches) do found=full;count=count+1 end
 if count==1 then return found end
 if count>1 then return nil end
 -- Let WoW resolve an unknown short name; never invent a realm for it.
 return name
end
W.ResolveRecipient=normalized

function W.Initialize()
 GuildLootWhispersDB=GuildLootWhispersDB or {}
 W.db=GuildLootWhispersDB;W.db.threads=W.db.threads or {};W.db.alpha=tonumber(W.db.alpha) or .85;W.selected=W.db.selected
 -- Battle.net account IDs are session-local; old recipients must never be reused.
 for k,t in pairs(W.db.threads) do if t.kind=='BN_WHISPER' or channelNames[t.kind] then W.db.threads[k]=nil end end
end
local backgrounds={
 {key='slate',name='Schiefer (hell, wie GuildHeal)',r=.29,g=.37,b=.45},
 {key='blue',name='Dunkelblau',r=.025,g=.045,b=.065},
 {key='charcoal',name='Anthrazit',r=.035,g=.035,b=.035},
 {key='warm',name='Warmes Dunkel',r=.09,g=.055,b=.035},
}
local sounds={{key='whisper',name='Whisper',id=3081},{key='click',name='Klick',id=856},{key='off',name='Aus'}}
function W.Preferences(kind)
 if not W.db then W.Initialize() end
 local cfg=W.db
 if kind=='buff' then W.db.buffPreferences=W.db.buffPreferences or {};cfg=W.db.buffPreferences end
 local style=backgrounds[1];local sound=kind=='buff' and sounds[2] or sounds[1]
 for _,v in ipairs(backgrounds) do if v.key==cfg.backgroundStyle then style=v end end
 -- Frei gewählte Hintergrundfarbe (Farbwähler)
 if cfg.backgroundStyle=='custom' and type(cfg.customColor)=='table' then style={key='custom',name='Eigene Farbe',r=tonumber(cfg.customColor[1]) or 0,g=tonumber(cfg.customColor[2]) or 0,b=tonumber(cfg.customColor[3]) or 0} end
 for _,v in ipairs(sounds) do if v.key==cfg.reminderSound then sound=v end end
 cfg.alpha=math.max(0,math.min(1,tonumber(cfg.alpha) or (kind=='buff' and .96 or .85)))
 cfg.backgroundStyle=style.key;cfg.reminderSound=sound.key
 return style,sound,cfg
end
function W.ApplyPreferences()
 local style,_,cfg=W.Preferences()
 if background then background:SetColorTexture(style.r,style.g,style.b,cfg.alpha) end
 if GL.Buffs and GL.Buffs.ApplyAppearance then GL.Buffs.ApplyAppearance() end
end
function W.SetPreference(key,value,kind)
 local _,_,cfg=W.Preferences(kind)
 if key=='alpha' then cfg.alpha=math.max(0,math.min(1,tonumber(value) or .85));if kind=='buff' then cfg.compactAlpha=cfg.alpha end
 elseif key=='orientation' and kind=='buff' and (value=='horizontal' or value=='vertical') then cfg.orientation=value
 elseif key=='compactScale' and kind=='buff' then cfg.compactScale=math.max(.8,math.min(2.4,math.floor((tonumber(value) or 1.5)*10+.5)/10))
 elseif key=='backgroundStyle' then for _,v in ipairs(backgrounds) do if v.key==value then cfg.backgroundStyle=value end end;if value=='custom' and type(cfg.customColor)=='table' then cfg.backgroundStyle='custom' end
 elseif key=='customColor' and type(value)=='table' then cfg.customColor={math.max(0,math.min(1,tonumber(value[1]) or 0)),math.max(0,math.min(1,tonumber(value[2]) or 0)),math.max(0,math.min(1,tonumber(value[3]) or 0))};cfg.backgroundStyle='custom'
 elseif key=='reminderSound' then for _,v in ipairs(sounds) do if v.key==value then cfg.reminderSound=value end end end
 W.ApplyPreferences();if kind=='buff' and (key=='orientation' or key=='compactScale') and GL.Buffs then GL.Buffs.Refresh() end
end
function GL.PlayReminderSound()
 local _,sound=W.Preferences('buff')
 if sound.id and PlaySound then PlaySound(sound.id,'SFX') end
end
local lastWhisperSound
function W.PlayWhisperSound(preview)
 local _,sound=W.Preferences()
 local timestamp=GetTime and GetTime() or now()
 if sound.id and PlaySound and (preview or not lastWhisperSound or timestamp-lastWhisperSound>=2) then
  PlaySound(sound.id,'SFX');if not preview then lastWhisperSound=timestamp end
 end
end
function W.ResetPreferences(kind)
 local _,_,cfg=W.Preferences(kind)
 cfg.compactScale=nil;cfg.alpha=kind=='buff' and .96 or .85;cfg.backgroundStyle='slate';cfg.customColor=nil;cfg.reminderSound=kind=='buff' and 'click' or 'whisper';cfg.compactAlpha=nil;cfg.orientation='horizontal';W.ApplyPreferences()
end
function W.List()
 local out={};for _,t in pairs(W.db.threads) do if not channelNames[t.kind] then out[#out+1]=t end end
 table.sort(out,function(a,b) if a.at==b.at then return a.key<b.key end;return a.at>b.at end);return out
end
function W.Unread()
 local n=0;for _,t in pairs(W.db.threads) do n=n+(t.unread or 0) end;return n
end
function W.Conversation(name,kind,account)
 kind=kind or 'WHISPER'
 local recipient=kind=='BN_WHISPER' and tonumber(account) or normalized(name)
 if not recipient then return nil end
 local key=kind..':'..string.lower(tostring(recipient));local t=W.db.threads[key]
 if not t then
  local list=W.List();if #list>=40 then
   for i=#list,1,-1 do if list[i].key~=W.selected and (list[i].unread or 0)==0 then W.db.threads[list[i].key]=nil;break end end
  end
  if #W.List()>=80 then return nil end
  t={key=key,name=kind=='WHISPER' and recipient or name,recipient=recipient,kind=kind,messages={},unread=0,at=now()};W.db.threads[key]=t
 end
 return t
end
function W.Channel(kind)
 if not channelNames[kind] then return end
 local key='CHANNEL:'..kind;local t=W.db.threads[key]
 if not t then t={key=key,name=channelNames[kind],kind=kind,messages={},unread=0,at=now()};W.db.threads[key]=t end
 return t
end
function W.Switch(kind)
 if kind=='WHISPER' then local list=W.List();W.Select(W.lastWhisper or (list[1] and list[1].key)) else W.Select(W.Channel(kind).key) end
end
local function line(m)
 local class=m.class
 if m.outgoing and UnitClass then local _,token=UnitClass('player');class=token end
 if not class then
  local recipient=normalized(m.sender)
  local t=recipient and W.db.threads['WHISPER:'..string.lower(recipient)]
  class=t and t.class
 end
 local c=class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
 local nameColor=c and string.format('|cff%02x%02x%02x',math.floor(c.r*255+.5),math.floor(c.g*255+.5),math.floor(c.b*255+.5)) or '|cffc9d4df'
 local name=m.outgoing and (UnitName and UnitName('player') or 'Du') or m.sender
 return '|cffffcc00'..date('%H:%M',m.at)..'|r '..nameColor..'['..safe(name)..']|r: '..(m.channel=='GUILD' and '|cff40ff40' or m.channel=='PARTY' and '|cffaaaaff' or m.channel=='RAID' and '|cffff7f00' or m.outgoing and '|cffff00ff' or '|cffc43cff')..safe(m.text)..'|r'
end
function W.MarkAllRead()
 if not W.db then return 0 end
 local n=0;for _,t in pairs(W.db.threads or {}) do n=n+(t.unread or 0);t.unread=0 end
 W.RefreshList();return n
end
function W.RefreshList()
 if not launcher then return end
 local selectedThread=W.db.threads[W.selected or ''];local mode=selectedThread and channelNames[selectedThread.kind] and selectedThread.kind or 'WHISPER'
 if target then target:SetShown(mode=='WHISPER');if addTarget then addTarget:SetShown(mode=='WHISPER') end end
 for kind,b in pairs(tabs) do local t=W.db.threads['CHANNEL:'..kind];local n=t and t.unread or 0;b.label:SetText((kind=='WHISPER' and 'Whisper' or channelNames[kind])..(n>0 and (' ('..n..')') or ''));b.label:SetTextColor(kind==mode and 1 or .7,kind==mode and .82 or .8,kind==mode and .2 or .85) end
 local unread=W.Unread();badge:SetText(unread>0 and tostring(unread) or '')
 local list=W.List();offset=math.max(0,math.min(offset,math.max(0,#list-(W.visibleRows or 7))))
 for i,b in ipairs(rows) do local t=list[i+offset];b.thread=t;b:SetShown(mode=='WHISPER' and t~=nil and i<=(W.visibleRows or 7))
  if t then b.label:SetText((t.key==W.selected and '|cffffd24a' or '|cffd9e2ec')..safe(t.name)..'|r'..((t.unread or 0)>0 and ' |cffffd24a('..t.unread..')|r' or '')..(t.kind=='BN_WHISPER' and '\n|cff7895baBattle.net|r' or '')) end
 end
end
function W.Select(key)
 if input and W.selected and W.db.threads[W.selected] then W.db.threads[W.selected].draft=input:GetText() end
 W.selected=key;W.db.selected=key;local t=key and W.db.threads[key];if not t then if chat then chat:Clear();input:SetText('');info:SetText('Gespräch wählen oder links Name-Server eingeben.') end;W.RefreshList();return end
 if not channelNames[t.kind] then W.lastWhisper=key end
 t.unread=0
 if chat then chat:Clear();for _,m in ipairs(t.messages) do chat:AddMessage(line(m),.92,.92,.95) end;chat:ScrollToBottom();input:SetText(t.draft or '');info:SetText('An '..safe(t.name)) end
 W.RefreshList()
end
function W.DeleteConversation(key)
 local t=key and W.db.threads[key]
 if not t or channelNames[t.kind] then return false end
 W.db.threads[key]=nil
 if W.pending and W.pending.key==key then W.pending=nil end
 if W.lastWhisper==key then W.lastWhisper=nil end
 if W.selected==key then local list=W.List();W.Select(list[1] and list[1].key) else W.RefreshList() end
 return true
end
function W.Receive(event,text,name,account,guid)
 if not W.db or type(text)~='string' or type(name)~='string' then return end
 local kind=channelEvents[event] or (event:find('BN_',1,true) and 'BN_WHISPER' or 'WHISPER')
 if kind=='WHISPER' then
  local resolved=normalized(name,guid) or name
  if not resolved:find('-',1,true) then resolved=resolved..'-'..realmName(GetRealmName()) end
  local bare=resolved:match('^([^%-]+)');local oldKey='WHISPER:'..bare:lower();local newKey='WHISPER:'..resolved:lower();local old=W.db.threads[oldKey]
  if old and not W.db.threads[newKey] then W.db.threads[oldKey]=nil;old.key=newKey;old.name=resolved;old.recipient=resolved;W.db.threads[newKey]=old;if W.selected==oldKey then W.selected=newKey;W.db.selected=newKey end;if W.pending and W.pending.key==oldKey then W.pending.key=newKey end end
  name=resolved
 end
 local t=channelNames[kind] and W.Channel(kind) or W.Conversation(name,kind,account);if not t then return end
 local outgoing=event:find('_INFORM',1,true)~=nil or (channelNames[kind] and guid and UnitGUID and guid==UnitGUID('player')) or false
 local visible=window and window:IsShown() and W.selected==t.key and chat:AtBottom()
 local class
 if outgoing and UnitClass then local _,token=UnitClass('player');class=token elseif kind~='BN_WHISPER' and guid and GetPlayerInfoByGUID then local _,token=GetPlayerInfoByGUID(guid);class=token end
 if not outgoing and class then t.class=class end
 if outgoing and W.pending and W.pending.key==t.key and W.pending.text==text then t.draft='';W.pending=nil;if info and W.selected==t.key then info:SetText('An '..safe(t.name)..' · gesendet') end end
 local m={text=text:sub(1,2000),sender=name,outgoing=outgoing,at=now(),class=class,channel=channelNames[kind] and kind or nil}
 t.messages[#t.messages+1]=m;t.at=now();if #t.messages>100 then table.remove(t.messages,1) end
 if not outgoing and not visible then
  t.unread=(t.unread or 0)+1
  if kind=='WHISPER' or kind=='BN_WHISPER' then W.PlayWhisperSound() end
 end
 if chat and W.selected==t.key then chat:AddMessage(line(m),.92,.92,.95) end
 W.RefreshList()
end
function W.Send(text)
 local t=W.db.threads[W.selected or ''];text=trim(text)
 if not t then return false,'Bitte zuerst einen Gesprächspartner wählen.' end
 if text=='' then return false,'Bitte eine Nachricht eingeben.' end
 if #text>255 or text:find('[\r\n]') then return false,'Maximal 255 Bytes pro Nachricht; bitte den Text kürzen.' end
 if t.kind=='GUILD' and (not IsInGuild or not IsInGuild()) then return false,'Du bist in keiner Gilde.' end
 if t.kind=='PARTY' and (not IsInGroup or not IsInGroup() or IsInRaid and IsInRaid()) then return false,'Du bist in keiner normalen Gruppe. Im Schlachtzug bitte Raid wählen.' end
 if t.kind=='RAID' and (not IsInRaid or not IsInRaid()) then return false,'Du bist in keinem Schlachtzug.' end
 if text:sub(1,1)=='/' then return false,'Bitte den Chat über die Reiter wählen; Slash-Befehle werden hier nicht gesendet.' end
 local fn=t.kind=='BN_WHISPER' and BNSendWhisper or (SendChatMessage or C_ChatInfo and C_ChatInfo.SendChatMessage)
 if not fn then return false,'Diese Chatfunktion ist nicht verfügbar.' end
 local ok,err
 if t.kind=='BN_WHISPER' then ok,err=pcall(fn,t.recipient,text) else ok,err=pcall(fn,text,channelNames[t.kind] and t.kind or 'WHISPER',nil,t.recipient) end
 if not ok then return false,'WoW konnte die Nachricht nicht senden: '..tostring(err) end
 W.pending={key=t.key,text=text,at=now()};t.draft=text;return true
end
local function label(parent,text,x,y,width)
 local t=parent:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');t:SetPoint('TOPLEFT',x,y);t:SetWidth(width);t:SetJustifyH('LEFT');t:SetText(text);return t
end
local function button(parent,text,x,y,width,fn)
 local b=CreateFrame('Button',nil,parent);b:SetPoint('TOPLEFT',x,y);b:SetSize(width,26)
 local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.12,.20,.26,.9)
 b.label=label(b,text,6,-7,width-12);b:SetScript('OnClick',fn);return b
end
function W.ToggleSettings(kind,owner)
 kind=kind or 'whisper'
 local sameKind=W.settingsKind==kind;W.settingsKind=kind
 if not settingsPanel then
  local p=CreateFrame('Frame',nil,UIParent);settingsPanel=p;W.settingsPanel=p
  p:SetSize(520,436);p:SetPoint('CENTER');p:SetFrameStrata('DIALOG');p:EnableMouse(true)
  local bg=p:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.025,.035,.05,1)
  local heading=label(p,'',14,-14,340)
  button(p,'×',484,-7,26,function() p:Hide() end)
  local soundHeading=label(p,'',14,-50,360)
  local soundButtons={};local styleButtons={};local orientationButtons={}
  local opacityText=label(p,'',14,-238,340)
  local swatch=p:CreateTexture(nil,'ARTWORK');swatch:SetPoint('TOPLEFT',172,-198);swatch:SetSize(30,26);swatch:SetColorTexture(.29,.37,.45,1)
  local function refresh()
   local style,sound,cfg=W.Preferences(W.settingsKind)
   heading:SetText(W.settingsKind=='buff' and 'Buffs · Persönliche Einstellungen' or 'Whisper · Persönliche Einstellungen')
   soundHeading:SetText(W.settingsKind=='buff' and 'Buff-Erinnerungston' or 'Ton bei ungelesenen Whispern')
   for key,b in pairs(soundButtons) do b.label:SetTextColor(key==sound.key and 1 or .8,key==sound.key and .82 or .86,key==sound.key and .2 or .9) end
   for key,b in pairs(orientationButtons) do b:SetShown(W.settingsKind=='buff');b.label:SetTextColor(key==(cfg.orientation or 'horizontal') and 1 or .8,key==(cfg.orientation or 'horizontal') and .82 or .86,key==(cfg.orientation or 'horizontal') and .2 or .9) end
   for key,b in pairs(styleButtons) do b.label:SetTextColor(key==style.key and 1 or .8,key==style.key and .82 or .86,key==style.key and .2 or .9) end
   swatch:SetColorTexture(style.r,style.g,style.b,1)
   opacityText:SetText('Hintergrund-Deckkraft: '..math.floor(cfg.alpha*100+.5)..'%')
   if p.sizeText then p.sizeText:SetShown(W.settingsKind=='buff');p.sizeText:SetText('Größe der kompakten Leiste: '..math.floor((cfg.compactScale or 1.5)*100+.5)..'%');for _,b in ipairs(p.sizeButtons or {}) do b:SetShown(W.settingsKind=='buff') end end
  end
  for i,v in ipairs(sounds) do local key=v.key;soundButtons[key]=button(p,v.name,14+(i-1)*94,-72,88,function() W.SetPreference('reminderSound',key,W.settingsKind);refresh() end) end
  button(p,'Test',302,-72,82,function() if W.settingsKind=='buff' then GL.PlayReminderSound() else W.PlayWhisperSound(true) end end)
  label(p,'Nutzt die WoW-Lautstärke für Soundeffekte.',14,-108,370)
  label(p,'Hintergrund',14,-140,360)
  for i,v in ipairs(backgrounds) do local key=v.key;styleButtons[key]=button(p,v.name,14+(i-1)*124,-162,118,function() W.SetPreference('backgroundStyle',key,W.settingsKind);refresh() end) end
  -- Freie Farbwahl über den WoW-Farbwähler; die Farbe wird je Charakter gespeichert.
  local function openColorPicker()
   local style,_,cfg=W.Preferences(W.settingsKind);local kind=W.settingsKind
   local r,g,b=style.r,style.g,style.b
   local function apply() local nr,ng,nb;if ColorPickerFrame.GetColorRGB then nr,ng,nb=ColorPickerFrame:GetColorRGB() else nr,ng,nb=ColorPickerFrame.r or r,ColorPickerFrame.g or g,ColorPickerFrame.b or b end;W.SetPreference('customColor',{nr,ng,nb},kind);refresh() end
   local function cancel(previous) local pr,pg,pb=r,g,b;if type(previous)=='table' then pr,pg,pb=previous.r or previous[1] or r,previous.g or previous[2] or g,previous.b or previous[3] or b end;W.SetPreference('customColor',{pr,pg,pb},kind);if style.key~='custom' then W.SetPreference('backgroundStyle',style.key,kind) end;refresh() end
   if not ColorPickerFrame then return end
   if ColorPickerFrame.SetupColorPickerAndShow then
    ColorPickerFrame:SetupColorPickerAndShow({r=r,g=g,b=b,hasOpacity=false,swatchFunc=apply,cancelFunc=cancel})
   else
    ColorPickerFrame.func=apply;ColorPickerFrame.swatchFunc=apply;ColorPickerFrame.opacityFunc=nil;ColorPickerFrame.hasOpacity=false;ColorPickerFrame.cancelFunc=cancel;ColorPickerFrame.previousValues={r=r,g=g,b=b}
    ColorPickerFrame:SetColorRGB(r,g,b);ColorPickerFrame:Hide();ColorPickerFrame:Show()
   end
  end
  styleButtons.custom=button(p,'Eigene Farbe …',14,-196,150,openColorPicker)
  label(p,'Farbwähler von WoW · Deckkraft unten',210,-204,300)
  button(p,'−',14,-262,44,function() local _,_,cfg=W.Preferences(W.settingsKind);W.SetPreference('alpha',cfg.alpha-.1,W.settingsKind);refresh() end)
  button(p,'+',64,-262,44,function() local _,_,cfg=W.Preferences(W.settingsKind);W.SetPreference('alpha',cfg.alpha+.1,W.settingsKind);refresh() end)
  label(p,'0% durchsichtig · 100% deckend',124,-270,260)
  orientationButtons.horizontal=button(p,'Icons: horizontal',14,-304,180,function() W.SetPreference('orientation','horizontal','buff');refresh() end)
  orientationButtons.vertical=button(p,'Icons: vertikal',204,-304,180,function() W.SetPreference('orientation','vertical','buff');refresh() end)
  p.sizeText=label(p,'',14,-342,300)
  p.sizeButtons={button(p,'−',330,-336,44,function() local _,_,cfg=W.Preferences('buff');W.SetPreference('compactScale',(cfg.compactScale or 1.5)-.1,'buff');refresh() end),button(p,'+',380,-336,44,function() local _,_,cfg=W.Preferences('buff');W.SetPreference('compactScale',(cfg.compactScale or 1.5)+.1,'buff');refresh() end)}
  button(p,'Standard',14,-379,110,function() W.ResetPreferences(W.settingsKind);refresh() end)
  button(p,'Fertig',394,-379,110,function() p:Hide() end)
  label(p,'Wird automatisch für diesen Charakter gespeichert.',14,-416,496)
  p.refresh=refresh;p:SetClampedToScreen(true);p:SetScript('OnShow',refresh);p:Hide()
 end
 if settingsPanel:IsShown() and sameKind then settingsPanel:Hide() else
  -- Neben dem aufrufenden Fenster öffnen (rechts, sonst links), damit Buffleiste bzw. Chat sichtbar bleiben.
  settingsPanel:ClearAllPoints()
  local anchor=owner or window
  if anchor and anchor.GetRight then
   local scale=anchor:GetEffectiveScale()/settingsPanel:GetEffectiveScale()
   local right=(anchor:GetRight() or 0)*scale;local left=(anchor:GetLeft() or 0)*scale;local width=settingsPanel:GetWidth()
   if right+12+width<=UIParent:GetWidth()/settingsPanel:GetEffectiveScale()*UIParent:GetEffectiveScale() then settingsPanel:SetPoint('TOPLEFT',anchor,'TOPRIGHT',12,0)
   elseif left-12-width>=0 then settingsPanel:SetPoint('TOPRIGHT',anchor,'TOPLEFT',-12,0)
   else settingsPanel:SetPoint('BOTTOM',anchor,'TOP',0,12) end
  else settingsPanel:SetPoint('CENTER',UIParent,'CENTER') end
  settingsPanel.refresh()
  if input then input:ClearFocus() end;if target then target:ClearFocus() end
  settingsPanel:Show()
 end
end
local function savePosition(f,key)
 local x,y=f:GetCenter();local px,py=UIParent:GetCenter();W.db[key]={x=x-px,y=y-py}
end
local function position(f,key,x,y)
 local p=W.db[key] or {};f:ClearAllPoints();f:SetPoint('CENTER',UIParent,'CENTER',tonumber(p.x) or x,tonumber(p.y) or y)
end
function W.ToggleLauncher()
 if not window then W.Build() end
 if not W.db.buttonPosition then position(launcher,'buttonPosition',-66,0)end
 W.db.launcherShown=not launcher:IsShown();launcher:SetShown(W.db.launcherShown)
 return W.db.launcherShown
end
function W.Toggle()
 if not window then W.Build() end
 if window:IsShown() then window:Hide() else window:Show();if W.selected then W.Select(W.selected) end end
end
function W.Build()
 if window or not W.db then return end
 local f=CreateFrame('Frame','GuildLootWhisperWindow',UIParent);window=f;W.window=f
 f:SetSize(math.max(480,math.min(900,tonumber(W.db.width) or 620)),math.max(280,math.min(650,tonumber(W.db.height) or 360)))
 f:SetFrameStrata('MEDIUM');f:SetClampedToScreen(true);f:SetMovable(true);f:EnableMouse(true);f:SetResizable(true)
 if f.SetResizeBounds then f:SetResizeBounds(480,280,900,650) else f:SetMinResize(480,280);f:SetMaxResize(900,650) end
 position(f,'position',0,80)
 background=f:CreateTexture(nil,'BACKGROUND');background:SetAllPoints();f.chromeBg=background;W.ApplyPreferences()
 GL.StyleToolWindow(f,{key='whisper',keepBg=true,scale=false,close=false})
 -- Keep the draggable title area clear of Settings and Close hit targets.
 local title=CreateFrame('Frame',nil,f);title:SetPoint('TOPLEFT',0,0);title:SetPoint('TOPRIGHT',-282,0);title:SetHeight(34);title:EnableMouse(true);title:RegisterForDrag('LeftButton')
 label(title,'GuildLoot · Chat',12,-10,230)
 title:SetScript('OnDragStart',function() f:StartMoving() end);title:SetScript('OnDragStop',function() f:StopMovingOrSizing();savePosition(f,'position') end)
 local close=button(f,'×',0,-4,26,function() f:Hide() end);close:ClearAllPoints();close:SetPoint('TOPRIGHT',-5,-4)
 local preferences=button(f,'Einstellungen',0,-4,114,function() W.ToggleSettings() end);preferences:ClearAllPoints();preferences:SetPoint('TOPRIGHT',-40,-4)
 local readAll=button(f,'Alle gelesen',0,-4,110,function() local n=W.MarkAllRead();if info then info:SetText(n>0 and (n..' Nachrichten als gelesen markiert.') or 'Keine ungelesenen Nachrichten.') end end);readAll:ClearAllPoints();readAll:SetPoint('TOPRIGHT',-160,-4)
 for i,kind in ipairs({'WHISPER','GUILD','PARTY','RAID'}) do tabs[kind]=button(f,kind,12+(i-1)*111,-39,105,function() W.Switch(kind) end) end
 target=CreateFrame('EditBox',nil,f,'InputBoxTemplate');target:SetPoint('TOPLEFT',16,-80);target:SetSize(134,24);target:SetAutoFocus(false);target:SetMaxLetters(100)
 local function openTarget() local name=normalized(target:GetText());if not name then info:SetText('Name-Server eingeben, z. B. Betaris-Lakeshire.');return end;local t=W.Conversation(name);if t then offset=0;W.Select(t.key);target:SetText('');target:ClearFocus();input:SetFocus() end end
 target:SetScript('OnEnterPressed',openTarget);target:SetScript('OnEscapePressed',function() target:ClearFocus() end)
 addTarget=button(f,'+',154,-80,24,openTarget)
 target:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_TOP');GameTooltip:SetText('Name-Server');GameTooltip:AddLine('Auch andere Server: z. B. Betaris-Lakeshire. Bei gleichen Namen den Server immer angeben.',1,1,1,true);GameTooltip:Show() end)
 target:SetScript('OnLeave',function() GameTooltip:Hide() end)
 local list=CreateFrame('Frame',nil,f);list:SetPoint('TOPLEFT',10,-116);list:SetPoint('BOTTOMLEFT',10,12);list:SetWidth(168);list:EnableMouseWheel(true)
 list:SetScript('OnMouseWheel',function(_,delta) offset=offset-delta;W.RefreshList() end)
 for i=1,12 do
  local b=button(list,'',0,-(i-1)*38,168,function(self) if self.thread then W.Select(self.thread.key) end end);b:SetHeight(34);b.label:SetWidth(130);rows[i]=b
  local remove=button(b,'×',140,-4,24,function() if b.thread then W.DeleteConversation(b.thread.key) end end)
  remove:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText('Chat löschen');GameTooltip:AddLine('Entfernt den gespeicherten Verlauf dieses Chats.',1,1,1,true);GameTooltip:Show() end)
  remove:SetScript('OnLeave',function() GameTooltip:Hide() end)
 end
 chat=CreateFrame('ScrollingMessageFrame',nil,f);chat:SetPoint('TOPLEFT',190,-114);chat:SetPoint('BOTTOMRIGHT',-12,78);chat:SetFontObject(GameFontHighlightSmall);chat:SetJustifyH('LEFT');chat:SetFading(false);chat:SetMaxLines(100);chat:EnableMouseWheel(true)
 chat:SetScript('OnMouseWheel',function(_,delta) if delta>0 then chat:ScrollUp() else chat:ScrollDown() end;if chat:AtBottom() and W.selected then W.db.threads[W.selected].unread=0;W.RefreshList() end end)
 info=label(f,'Gespräch wählen oder links Name-Server eingeben.',190,-85,380);info:SetPoint('TOPRIGHT',-12,-85)
 input=CreateFrame('EditBox',nil,f,'InputBoxTemplate');input:SetPoint('BOTTOMLEFT',196,40);input:SetPoint('BOTTOMRIGHT',-90,40);input:SetHeight(28);input:SetAutoFocus(false);input:SetMaxLetters(255)
 local function send() local ok,err=W.Send(input:GetText());if ok then input:SetText('');info:SetText('An '..safe(W.db.threads[W.selected].name)..' · an WoW übergeben') else info:SetText(err) end end
 input:SetScript('OnEnterPressed',send);input:SetScript('OnEscapePressed',function() input:ClearFocus() end)
 local sendButton=button(f,'Senden',0,0,72,send);sendButton:ClearAllPoints();sendButton:SetPoint('BOTTOMRIGHT',-12,40)
 local footer=label(f,'Enter: senden · Mausrad: Verlauf · /gl whisper',190,0,400);footer:ClearAllPoints();footer:SetPoint('BOTTOMLEFT',190,16);footer:SetPoint('BOTTOMRIGHT',-24,16)
 local resize=CreateFrame('Button',nil,f);resize:SetSize(18,18);resize:SetPoint('BOTTOMRIGHT',0,0);resize:EnableMouse(true);label(resize,'◢',0,0,18)
 resize:SetScript('OnMouseDown',function() f:StartSizing('BOTTOMRIGHT') end);resize:SetScript('OnMouseUp',function() f:StopMovingOrSizing();W.db.width=f:GetWidth();W.db.height=f:GetHeight();savePosition(f,'position') end)
 f:SetScript('OnSizeChanged',function() local count=math.max(1,math.min(12,math.floor((f:GetHeight()-132)/38)));W.visibleRows=count;W.RefreshList() end)
 f:SetScript('OnHide',function() if settingsPanel then settingsPanel:Hide() end;if W.selected and W.db.threads[W.selected] then W.db.threads[W.selected].draft=input:GetText() end;input:ClearFocus();target:ClearFocus();W.db.open=false end)
 f:SetScript('OnShow',function() W.db.open=true;W.RefreshList() end)
 launcher=CreateFrame('Button','GuildLootWhisperButton',UIParent);W.launcher=launcher;launcher:SetSize(36,36);launcher:SetFrameStrata('MEDIUM');launcher:SetMovable(true);launcher:SetClampedToScreen(true);launcher:EnableMouse(true);launcher:RegisterForDrag('LeftButton');position(launcher,'buttonPosition',-66,0)
 launcher:SetShown(W.db.launcherShown==true)
 local icon=launcher:CreateTexture(nil,'ARTWORK');icon:SetAllPoints();icon:SetTexture('Interface\\AddOns\\GuildLootEra\\Media\\GuildWhisper')
 badge=label(launcher,'',23,0,45);badge:SetTextColor(1,.82,.2)
 launcher:SetScript('OnClick',function() W.Toggle() end);launcher:SetScript('OnDragStart',function() launcher:StartMoving() end);launcher:SetScript('OnDragStop',function() launcher:StopMovingOrSizing();savePosition(launcher,'buttonPosition') end)
 local elapsed=0;launcher:SetScript('OnUpdate',function(_,dt) elapsed=elapsed+dt;icon:SetAlpha(W.Unread()>0 and (.65+.35*math.sin(elapsed*3)^2) or 1) end)
 launcher:SetScript('OnEnter',function() GameTooltip:SetOwner(launcher,'ANCHOR_TOP');GameTooltip:SetText('GuildLoot Whisper · '..W.Unread()..' ungelesen');GameTooltip:Show() end);launcher:SetScript('OnLeave',function() GameTooltip:Hide() end)
 W.visibleRows=math.max(1,math.min(12,math.floor((f:GetHeight()-132)/38)));W.RefreshList();if W.selected and W.db.threads[W.selected] then W.Select(W.selected) end;if not W.db.open then f:Hide() end
end
local events=CreateFrame('Frame')
events:RegisterEvent('CHAT_MSG_SYSTEM');events:RegisterEvent('UI_ERROR_MESSAGE');events:RegisterEvent('PLAYER_LOGIN');events:RegisterEvent('CHAT_MSG_WHISPER');events:RegisterEvent('CHAT_MSG_WHISPER_INFORM');events:RegisterEvent('CHAT_MSG_BN_WHISPER');events:RegisterEvent('CHAT_MSG_BN_WHISPER_INFORM')
for e in pairs(channelEvents) do events:RegisterEvent(e) end
events:SetScript('OnEvent',function(_,event,...)
 if event=='PLAYER_LOGIN' then W.Initialize();W.Build();return end
 local args={...};if event=='CHAT_MSG_SYSTEM' or event=='UI_ERROR_MESSAGE' then
  local text=event=='UI_ERROR_MESSAGE' and args[2] or args[1]
  if W.pending and now()-W.pending.at<8 and type(text)=='string' and (text:lower():find('nicht gefunden',1,true) or text:lower():find('not found',1,true) or text:lower():find('nicht online',1,true) or text:lower():find('player not',1,true)) then
   local pending=W.pending;W.pending=nil;if input and W.selected==pending.key then input:SetText(pending.text);info:SetText(text..' Bitte Name-Server prüfen.') end
  end;return
 end
 W.Receive(event,args[1],args[2],args[13],args[12])
end)
SLASH_GUILDLOOTWHISPER1='/glw';SlashCmdList.GUILDLOOTWHISPER=function() W.Toggle() end
