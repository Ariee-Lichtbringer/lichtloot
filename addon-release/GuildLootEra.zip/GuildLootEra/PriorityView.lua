local _,GL=...
local order={P1=1,P2=2,P3=3,P0=4,["P0+"]=5,Punkte=6}
function GL.PriorityGroups(search)
    local groups={};local p=GL.DisplayPriorities()
    if not p then return {} end
    search=tostring(search or ""):lower()
    for _,r in ipairs(p.rows) do
        if search=="" or tostring(r.itemId)==search or r.itemName:lower():find(search,1,true) or r.player:lower():find(search,1,true) then
            local g=groups[r.itemId]
            if not g then g={itemId=r.itemId,itemName=r.itemName,players={},byPlayer={}};groups[r.itemId]=g end
            local key=r.player.."\031"..r.realm
            local player=g.byPlayer[key]
            if not player then
                player={player=r.player,realm=r.realm,class=r.class,bench=r.bench,points=r.points,priorities={},seen={},createdAt=r.createdAt}
                g.byPlayer[key]=player;g.players[#g.players+1]=player
            end
            -- Repeated P1/P2/P3/P0+ entries refer to the same item point account.
            -- Never sum their repeated point values.
            if player.points~=r.points then player.conflict=true end
            if not player.seen[r.priority] then player.seen[r.priority]=true;player.priorities[#player.priorities+1]=r.priority end
        end
    end
    local out={}
    for _,g in pairs(groups) do
        for _,r in ipairs(g.players) do table.sort(r.priorities,function(a,b) return (order[a] or 99)<(order[b] or 99) end) end
        table.sort(g.players,function(a,b)
            local ap,bp=a.conflict and -math.huge or a.points or -math.huge,b.conflict and -math.huge or b.points or -math.huge
            if ap~=bp then return ap>bp end
            if a.player~=b.player then return a.player<b.player end
            return a.realm<b.realm
        end)
        out[#out+1]=g
    end
    table.sort(out,function(a,b) if a.itemName~=b.itemName then return a.itemName<b.itemName end return a.itemId<b.itemId end)
    return out
end
function GL.PriorityLabel(player)
    local other={};local p0,p0plus=false,false
    for _,priority in ipairs(player.priorities) do
        if priority=="P0" then p0=true
        elseif priority=="P0+" then p0plus=true
        elseif priority~="Punkte" then other[#other+1]=priority end
    end
    local text=table.concat(other,"  ·  ")
    if p0 or p0plus then
        local badge=p0 and p0plus and "P0 / P0+ gesetzt" or p0plus and "P0+ gesetzt" or "P0 gesetzt"
        return "|cff79e6a2"..badge.."|r"..(text~="" and "\n"..text or ""),true
    end
    return text~="" and text or "Nur Punktestand",false
end
local classes={Krieger="WARRIOR",Druide="DRUID",Schurke="ROGUE",Magier="MAGE",Priester="PRIEST",Paladin="PALADIN",["Jäger"]="HUNTER",Jaeger="HUNTER",Hexenmeister="WARLOCK",Schamane="SHAMAN"}
local function label(parent,size,x,y,width)
    local s=parent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    s:SetFont(STANDARD_TEXT_FONT,size);s:SetPoint("TOPLEFT",x,y);s:SetWidth(width);s:SetJustifyH("LEFT");s:SetWordWrap(false)
    return s
end
function GL.CreatePriorityView(parent)
    local view=CreateFrame("Frame",nil,parent)
    view:SetPoint("TOPLEFT",20,-328);view:SetPoint("BOTTOMRIGHT",-22,58)
    view.rows={};view.offset=0;view.lines={};view.count=5
    local header=label(view,12,14,0,500);header:SetText("ITEM / SPIELER");header:SetTextColor(.65,.74,.82)
    local prio=label(view,12,490,0,190);prio:SetText("PRIORITÄTEN");prio:SetTextColor(.65,.74,.82)
    local points=label(view,12,716,0,140);points:SetText("P0+-PUNKTE");points:SetJustifyH("RIGHT");points:SetTextColor(1,.8,.25)
    local empty=label(view,15,16,-58,790)
    -- This virtual list has a Frame parent, not a ScrollFrame. Blizzard's
    -- UIPanelScrollBarTemplate calls parent:SetVerticalScroll during SetValue.
    local scroll=CreateFrame("Slider","GuildLootEraPriorityScrollBar",view)
    scroll:SetOrientation("VERTICAL");scroll:SetWidth(16)
    local track=scroll:CreateTexture(nil,"BACKGROUND");track:SetAllPoints();track:SetColorTexture(.06,.09,.12,.9)
    local thumb=scroll:CreateTexture(nil,"OVERLAY");thumb:SetSize(16,32);thumb:SetColorTexture(.55,.65,.72,1)
    scroll:SetThumbTexture(thumb)
    scroll:SetPoint("TOPRIGHT",-2,-42);scroll:SetPoint("BOTTOMRIGHT",-2,20);scroll:SetValueStep(1);scroll:SetMinMaxValues(0,0);scroll:SetValue(0)
    local function tooltip(frame)
        if not frame.itemId then return end
        GameTooltip:SetOwner(frame,"ANCHOR_RIGHT");GameTooltip:SetHyperlink("item:"..frame.itemId);if GameTooltip.AddLine then GameTooltip:AddLine("Rechtsklick: im Ausrüstungsplaner anprobieren",.5,.9,.8) end;GameTooltip:Show()
    end
    local function itemInfo(frame)
        local fn=GetItemInfo or (C_Item and C_Item.GetItemInfo)
        local name,link,quality,_,_,_,_,_,_,icon
        if fn then name,link,quality,_,_,_,_,_,_,icon=fn(frame.itemId) end
        frame.title:SetText(name or frame.itemName)
        local c=quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality]
        frame.title:SetTextColor(c and c.r or .75,c and c.g or .8,c and c.b or .85)
        frame.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
        frame.link=link
    end
    for i=1,view.count do
        local row=CreateFrame("Button",nil,view)
        row:RegisterForClicks("LeftButtonUp","RightButtonUp");row:SetPoint("TOPLEFT",0,-26-(i-1)*58);row:SetSize(866,56)
        row.bg=row:CreateTexture(nil,"BACKGROUND");row.bg:SetAllPoints()
        row.icon=row:CreateTexture(nil,"ARTWORK");row.icon:SetSize(30,30);row.icon:SetPoint("LEFT",10,0)
        row.title=label(row,15,50,-6,590)
        row.name=label(row,15,28,-5,350);row.realm=label(row,11,28,-24,350);row.realm:SetTextColor(.6,.67,.75)
        row.prio=label(row,14,490,-5,220);row.prio:SetHeight(18)
        row.subprio=label(row,12,490,-24,220);row.subprio:SetHeight(16);row.subprio:SetTextColor(.65,.74,.82)
        row.entered=label(row,11,490,-41,360);row.entered:SetTextColor(.6,.7,.76)
        row.points=label(row,18,716,-10,140);row.points:SetJustifyH("RIGHT");row.points:SetTextColor(1,.8,.25)
        row.count=label(row,12,686,-13,164);row.count:SetJustifyH("RIGHT");row.count:SetTextColor(.65,.75,.8)
        row:SetScript("OnEnter",tooltip);row:SetScript("OnLeave",function() GameTooltip:Hide() end)
        row:SetScript("OnClick",function(self,which) if self.itemId and which=="RightButton" then GL.ShowGearForItem(self.itemId);return end;if self.itemId and self.link and HandleModifiedItemClick then HandleModifiedItemClick(self.link) end end)
        view.rows[i]=row
    end
    function view:Render()
        empty:SetText(#self.lines==0 and (GL.DisplayPriorities() and "Keine passenden Items oder Spieler gefunden." or "Noch keine Prioliste geladen. Oben auf Importieren klicken.") or "")
        for i,row in ipairs(self.rows) do
            local data=self.lines[self.offset+i]
            row:Hide();row.itemId=nil
            if data then
                row:Show()
                local isItem=data.kind=="item"
                row.icon:SetShown(isItem);row.title:SetShown(isItem);row.count:SetShown(isItem)
                row.name:SetShown(not isItem);row.realm:SetShown(not isItem);row.prio:SetShown(not isItem);row.subprio:SetShown(not isItem);row.points:SetShown(not isItem);row.entered:SetShown(not isItem)
                if isItem then
                    row.itemId=data.group.itemId;row.itemName=data.group.itemName
                    row.bg:SetColorTexture(.12,.2,.25,.95);row.count:SetText(#data.group.players.." Spieler")
                    itemInfo(row)
                else
                    local r=data.player
                    row.bg:SetColorTexture(.07,.1,.14,(self.offset+i)%2==0 and .85 or .5)
                    row.name:SetText(r.player..(r.bench and "  [BANK]" or ""));row.realm:SetText(r.realm~="" and r.realm or "Realm nicht enthalten")
                    local c=RAID_CLASS_COLORS and RAID_CLASS_COLORS[classes[r.class] or tostring(r.class):upper()]
                    row.name:SetTextColor(c and c.r or .92,c and c.g or .94,c and c.b or .98)
                    row.entered:SetText(r.createdAt and ("Eingetragen: "..date("%d.%m.%Y %H:%M",r.createdAt)) or (#r.priorities==1 and r.priorities[1]=="Punkte" and "" or "Eintragungszeit nicht enthalten"))
                    local priorityLabel,hasP0=GL.PriorityLabel(r)
                    local main,sub=priorityLabel:match("^([^\n]*)\n?(.*)$")
                    row.prio:SetText(main);row.subprio:SetText(sub or "");row.prio:SetTextColor(.65,.87,1)
                    if hasP0 then row.bg:SetColorTexture(.08,.24,.16,.9) end
                    row.points:SetText(r.conflict and "Prüfen" or r.points~=nil and tostring(r.points) or "—")
                    row.points:SetTextColor(r.points~=nil and 1 or .6,r.points~=nil and .8 or .67,r.points~=nil and .25 or .75)
                end
            end
        end
    end
    function view:Refresh(search)
        GameTooltip:Hide();self.lines={}
        local groups=GL.PriorityGroups(search)
        for _,g in ipairs(groups) do
            self.lines[#self.lines+1]={kind="item",group=g}
            for _,r in ipairs(g.players) do self.lines[#self.lines+1]={kind="player",player=r} end
        end
        self.offset=0;scroll:SetMinMaxValues(0,math.max(0,#self.lines-self.count));scroll:SetValue(0);self:Render()
        return #groups
    end
    scroll:SetScript("OnValueChanged",function(_,value) view.offset=math.floor(value+.5);GameTooltip:Hide();view:Render() end)
    view:EnableMouseWheel(true);view:SetScript("OnMouseWheel",function(_,delta) scroll:SetValue(math.max(0,math.min(math.max(0,#view.lines-view.count),view.offset-delta*3))) end)
    for _,row in ipairs(view.rows) do row:EnableMouseWheel(true);row:SetScript("OnMouseWheel",function(_,delta) scroll:SetValue(math.max(0,math.min(math.max(0,#view.lines-view.count),view.offset-delta*3))) end) end
    view:RegisterEvent("GET_ITEM_INFO_RECEIVED")
    view:SetScript("OnEvent",function(_,_,id,success)
        if not view:IsShown() or not success then return end
        for _,row in ipairs(view.rows) do if row.itemId==id then itemInfo(row);if GameTooltip:IsOwned(row) then tooltip(row) end end end
    end)
    view:SetScript("OnHide",function() GameTooltip:Hide() end)
    return view
end

-- Public raid lists remain separate from the recording/import data: hidden item
-- names must never become usable loot priorities before publication.
function GL.CreateSyncedPriorityView(parent)
    local v=CreateFrame('Frame',nil,parent);v:SetPoint('TOPLEFT',24,-180);v:SetSize(890,500)
    local selected,offset=nil,0
    local function text(owner,x,y,w,size)
        local t=owner:CreateFontString(nil,'OVERLAY','GameFontHighlight');t:SetPoint('TOPLEFT',x,y);t:SetWidth(w);t:SetFont(STANDARD_TEXT_FONT,size or 13);t:SetJustifyH('LEFT');return t
    end
    local function button(title,x,y,w,fn)
        local b=CreateFrame('Button',nil,v);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,28)
        local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.08,.14,.18,1)
        local caption=text(b,12,-7,w-24,13);caption:SetText(title)
        function b:SetText(value) caption:SetText(value) end
        b:SetScript('OnEnter',function() bg:SetColorTexture(.14,.22,.26,1) end)
        b:SetScript('OnLeave',function() bg:SetColorTexture(.08,.14,.18,1) end)
        b:SetScript('OnClick',fn);return b
    end
    local choose=button('Raid auswählen',0,0,890,function() end)
    local accent=choose:CreateTexture(nil,'ARTWORK');accent:SetPoint('BOTTOMLEFT');accent:SetPoint('BOTTOMRIGHT');accent:SetHeight(2);accent:SetColorTexture(.88,.69,.20,1)
    local hint=text(choose,730,-7,145,12);hint:SetText('Raid auswählen  v');hint:SetTextColor(1,.8,.25)

    local info=text(v,0,-38,890);local rows={}
    local missing=text(v,0,-62,890,12);missing:SetHeight(68)
    local missingHover=CreateFrame('Frame',nil,v);missingHover:SetPoint('TOPLEFT',0,-62);missingHover:SetSize(890,68);missingHover:EnableMouse(true)
    missingHover:SetScript('OnEnter',function(self) if self.details then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:AddLine('Fehlende Prioeinträge',1,.8,.3);for _,r in ipairs(self.details) do GameTooltip:AddLine(r.player..' – '..r.realm..' · '..r.spec,1,1,1,true) end;GameTooltip:Show() end end)
    missingHover:SetScript('OnLeave',function() GameTooltip:Hide() end)
    for i=1,7 do
        local row=CreateFrame('Frame',nil,v);row:SetPoint('TOPLEFT',0,-142-(i-1)*42);row:SetSize(890,42)
        local bg=row:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.07,.14,.19,1)
        row.name=text(row,8,-12,210);row.cells={}
        for j=1,4 do
            local b=CreateFrame('Button',nil,row);b:SetPoint('TOPLEFT',220+(j-1)*166,-2);b:SetSize(164,38);b.label=text(b,4,-5,156,12)
            b:SetScript('OnEnter',function(self) if self.itemId and GameTooltip then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetHyperlink('item:'..self.itemId);GameTooltip:Show() end end)
            b:SetScript('OnLeave',function() if GameTooltip then GameTooltip:Hide() end end);row.cells[j]=b
        end
        rows[i]=row
    end
    local page=text(v,320,-451,300)
    button('<',0,-446,80,function() offset=math.max(0,offset-7);v:Refresh() end)
    button('>',810,-446,80,function() offset=offset+7;v:Refresh() end)
    local data,raids
    local menu=CreateFrame('Frame',nil,v,'BackdropTemplate');menu:SetPoint('TOPLEFT',choose,'BOTTOMLEFT',0,-3);menu:SetSize(890,300);menu:SetFrameStrata('DIALOG');menu:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8'});menu:SetBackdropColor(.025,.055,.08,1);menu:Hide()
    local menuRows={};local menuOffset=0
    local function renderMenu()
        for _,b in ipairs(menuRows) do b:Hide() end
        menuOffset=math.min(menuOffset,math.max(0,#(raids or {})-10))
        for i=1,math.min(10,#(raids or {})-menuOffset) do
            local r=raids[menuOffset+i];local b=menuRows[i]
            if not b then b=CreateFrame('Button',nil,menu);b:SetPoint('TOPLEFT',5,-5-(i-1)*30);b:SetSize(880,28);b.label=text(b,8,-6,860,12);local hover=b:CreateTexture(nil,'HIGHLIGHT');hover:SetAllPoints();hover:SetColorTexture(.2,.3,.34,.7);b:SetHighlightTexture(hover);menuRows[i]=b end
            b.label:SetText(r.name..' · '..r.date..' '..r.clock);b.label:SetTextColor(r.id==selected and 1 or .82,r.id==selected and .8 or .88,r.id==selected and .25 or .92);b:Show();b:SetScript('OnClick',function() selected=r.id;GL.masterRaidId=selected;offset=0;menu:Hide();v:Refresh() end)
        end
        menu:SetHeight(math.min(10,#(raids or {}))*30+10)
    end
    menu:EnableMouseWheel(true);menu:SetScript('OnMouseWheel',function(_,d) menuOffset=math.max(0,menuOffset-d);renderMenu() end)
    choose:SetScript('OnClick',function() if menu:IsShown() then menu:Hide();return end;if #(raids or {})==0 then return end;menuOffset=0;renderMenu();menu:Show() end)
    function v:Refresh()
        menu:Hide()
        data=(GL.db.guildProfiles[GL.db.selectedGuild] or {}).activeRaids or {}
        -- RMD-Kontext: nur Random-Raids zur Auswahl, sonst nur Gildenraids (die Bereiche bleiben getrennt)
        local rmd=GL.IsRandomRaid~=nil and GL.IsRandomRaid(GL.masterRaidId or selected)
        raids={};for _,r in ipairs(data.rows or {}) do if (r.random==1)==rmd then raids[#raids+1]=r end end
        local raid;for _,r in ipairs(raids) do if r.id==(GL.masterRaidId or selected) then raid=r end end
        raid=raid or raids[1];selected=raid and raid.id;GL.masterRaidId=selected
        if self.master and not GL.HasMasterAccess(selected) then self:Hide();GL.ShowMaster();return end
        choose:SetText(raid and (raid.name..' · '..raid.date..' '..raid.clock) or 'Keine aktiven Raids synchronisiert')
        local list=raid and (data.lists or {})[raid.id] or {};list=list or {}
        local entries={};for _,r in ipairs(list.rows or {}) do entries[#entries+1]=r end
        local own=GL.DisplayProfile()
        table.sort(entries,function(a,b)
            local am=own and a.player==own.player and a.realm==own.realm;local bm=own and b.player==own.player and b.realm==own.realm
            if am~=bm then return am==true end
            return (a.player..a.realm)<(b.player..b.realm)
        end)
        offset=math.min(offset,math.max(0,math.ceil(#entries/7)-1)*7)
        local attendance=list.attendance;local full=raid and raid.signup==1
        missing:SetShown(full);missingHover:SetShown(full);missingHover.details=nil
        if full then
            if attendance and attendance.available==1 then
                local names={};for i,r in ipairs(attendance.missing or {}) do if i<=10 then names[#names+1]=r.player end end
                local count=#(attendance.missing or {});missingHover.details=attendance.missing
                missing:SetText('Angemeldet: '..attendance.count..' · Fehlende Prioeinträge: '..count..'\n'..(count==0 and 'Alle angemeldeten Spieler haben eine Prio.' or table.concat(names,' · '))..(count>10 and (' · +'..(count-10)..' weitere (Maus darüber)') or ''))
            else missing:SetText('Anmeldungen noch nicht verfügbar. Bitte die Sync-App aktualisieren und synchronisieren.') end
        end
        info:SetText((list.published==1 and 'Veröffentlicht · alle Items sichtbar' or 'P1–P3: nur gesetzt · P0/P0+: Item sichtbar')..' · '..#entries..' Spieler')
        page:SetText('Seite '..(offset/7+1)..' / '..math.max(1,math.ceil(#entries/7)))
        for i,row in ipairs(rows) do
            local r=entries[offset+i];row:SetShown(r~=nil)
            if r then
                row.name:SetText((offset+i)..'. '..r.player..'\n'..r.realm)
                local c=RAID_CLASS_COLORS and RAID_CLASS_COLORS[classes[r.className] or r.className];row.name:SetTextColor(c and c.r or .8,c and c.g or .85,c and c.b or .9)
                for j,b in ipairs(row.cells) do
                    b:SetShown(raid.raid~='ony' or j==1);b.itemId=nil
                    local key='p'..(j==4 and 0 or j);local name=r[key] or '';local prefix=j==4 and (r.p0Plus==1 and 'P0+' or 'P0') or key:upper()
                    local visible=j==4 or list.published==1
                    b.label:SetTextColor(.7,.85,.8)
                    if name=='' then b.label:SetText(prefix..' —') elseif not visible then b.label:SetText(prefix..' |TInterface\\RaidFrame\\ReadyCheck-Ready:14|t |cff79e6a2gesetzt|r') else
                        local cachedQuality;local id=tonumber(r[key..'Id']);for _,item in ipairs((data.catalogs or {})[raid.raid] or {}) do if item.name==name then id=item.id;cachedQuality=tonumber(item.quality) or ({["Episch"]=4,["Selten"]=3,["Ungewöhnlich"]=2,["Legendär"]=5})[item.quality];break end end
                        if id and id>0 then b.itemId=id end
                        local get=GetItemInfo or (C_Item and C_Item.GetItemInfo);local itemName,link,quality;if get and b.itemId then itemName,link,quality=get(b.itemId) end
                        quality=quality or cachedQuality;b.label:SetText(prefix..' · '..(itemName or name));if quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality] then local color=ITEM_QUALITY_COLORS[quality];b.label:SetTextColor(color.r,color.g,color.b) end
                    end
                end
            end
        end
    end
    v:EnableMouseWheel(true);v:SetScript('OnMouseWheel',function(_,delta) offset=math.max(0,offset+(delta<0 and 7 or -7));v:Refresh() end)
    v:RegisterEvent('GET_ITEM_INFO_RECEIVED');v:SetScript('OnEvent',function() if v:IsShown() then v:Refresh() end end)
    return v
end

-- Recognize the Naxx layout from its own top-level headings, not player names.
function GL.RaidSheetSections(sheet)
 local bosses,general={},{}
 for _,tab in ipairs(sheet.tabs or {}) do
  local headings=tab.rows and tab.rows[2] or {};local starts={}
  for c,value in ipairs(headings) do if c>=8 and tostring(value):match('%S') then starts[#starts+1]={c=c,name=value} end end
  local maxCol=0;for _,row in ipairs(tab.rows or {}) do maxCol=math.max(maxCol,#row) end
  if #starts>0 and (headings[2]=='Einteilung Trash' or #starts==1 and (tab.name=='Sapphiron' or tab.name=='Kel Thuzad')) then
   if headings[2]=='Einteilung Trash' then general[#general+1]={name=tab.name,tab=tab,c1=2,c2=6,r1=2,general=true} end
   for i,h in ipairs(starts) do
    local section={name=h.name,tab=tab,c1=h.c,c2=starts[i+1] and starts[i+1].c-2 or maxCol,r1=2}
    bosses[#bosses+1]=section
    -- Grobbulus is beneath Patchwerk in this workbook, not in the header row.
    for _,m in ipairs(tab.merges or {}) do
     if m.r>2 and m.c==h.c and ((tab.rows[m.r] or {})[m.c]=='Grobbulus') then
      section.r2=m.r-1;bosses[#bosses+1]={name='Grobbulus',tab=tab,c1=m.c,c2=m.c+m.w-1,r1=m.r}
     end
    end
   end
  elseif tab.name~='Aufstellung' and tab.name~='Gruppen' then
   bosses[#bosses+1]={name=tab.name,tab=tab,c1=1,c2=math.max(1,maxCol),r1=1}
  end
 end
 return bosses,general
end
function GL.CreateRaidSheetView(parent,standalone)
 local v=CreateFrame('Frame',nil,parent);v:SetPoint('TOPLEFT',24,-180);v:SetSize(890,500)
 local selected=1;local generalMode=false;local lastKey;local choices={};local pieces={}
 local function label(owner,value,x,y,w,size)
  local t=owner:CreateFontString(nil,'OVERLAY','GameFontHighlight');t:SetPoint('TOPLEFT',x,y);t:SetWidth(w);t:SetFont(STANDARD_TEXT_FONT,size or 12);t:SetJustifyH('LEFT');t:SetText(value);return t
 end
 local function button(owner,value,x,y,w,fn)
  local b=CreateFrame('Button',nil,owner);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,32);local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.08,.17,.21,1)
  b.title=label(b,value,9,-9,w-18,12);b:SetHighlightTexture('Interface\\QuestFrame\\UI-QuestTitleHighlight');b:SetScript('OnClick',fn);return b
 end
 local dropdown=CreateFrame('Frame',nil,v,'BackdropTemplate');dropdown:SetFrameStrata('DIALOG');dropdown:SetSize(440,380);dropdown:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8'});dropdown:SetBackdropColor(.025,.055,.08,1);dropdown:Hide();local items={}
 local function menu(anchor,options,select)
  if dropdown:IsShown() then dropdown:Hide();return end
  dropdown:ClearAllPoints();dropdown:SetPoint('TOPLEFT',anchor,'BOTTOMLEFT',0,-3)
  local offset=0
  local function render()
   for _,b in ipairs(items) do b:Hide() end
   for i=1,math.min(8,#options-offset) do
    local opt=options[offset+i];local b=items[i] or button(dropdown,'',4,-4-(i-1)*25,432,function() end);items[i]=b;b:SetHeight(24);b.title:SetText(opt.label);b:Show();b:SetScript('OnClick',function() dropdown:Hide();select(opt.value) end)
   end
   dropdown:SetHeight(math.max(32,math.min(8,#options)*25+8))
  end
  dropdown:EnableMouseWheel(true);dropdown:SetScript('OnMouseWheel',function(_,d) offset=math.max(0,math.min(math.max(0,#options-8),offset-d));render() end)
  render();dropdown:Show()
 end
 local raidButton,bossButton
 raidButton=button(v,'Raid auswählen',0,0,438,function()
  local data=((GL.db.guildProfiles or {})[GL.db.selectedGuild] or {}).activeRaids or {};local options={}
  for _,r in ipairs(data.rows or {}) do options[#options+1]={label=r.name..' · '..r.date,value=r.id} end
  menu(raidButton,options,function(id) GL.masterRaidId=id;v:Refresh() end)
 end)
 bossButton=button(v,'Boss auswählen',0,-78,440,function()
  local options={};for i,s in ipairs(choices) do options[#options+1]={label=s.name,value=i} end
  menu(bossButton,options,function(i) if choices[i].bossLink then generalMode=false;selected=choices[i].bossLink else selected=i end;v.scroll:SetVerticalScroll(0);v:Refresh() end)
 end)
 local bossTab=button(v,'Bosse & Taktiken',0,-38,438,function() generalMode=false;selected=1;v.scroll:SetVerticalScroll(0);v:Refresh() end)
 local generalTab=button(v,'Allgemeine Rollen',450,-38,440,function() generalMode=true;selected=1;v.scroll:SetVerticalScroll(0);v:Refresh() end)
 local previousButton=button(v,'< Zurück',450,-78,115,function() selected=math.max(1,selected-1);v.scroll:SetVerticalScroll(0);v:Refresh() end)
 local nextButton=button(v,'Weiter >',575,-78,115,function() selected=math.min(#choices,selected+1);v.scroll:SetVerticalScroll(0);v:Refresh() end)
 local info=label(v,'',0,-117,890,11)
 local scroll=CreateFrame('ScrollFrame',nil,v,'UIPanelScrollFrameTemplate');scroll:SetPoint('TOPLEFT',0,-137);scroll:SetSize(864,333);v.scroll=scroll
 local body=CreateFrame('Frame',nil,scroll);body:SetSize(848,1);scroll:SetScrollChild(body)
 scroll:EnableMouseWheel(true);scroll:SetScript('OnMouseWheel',function(self,d) self:SetVerticalScroll(math.max(0,math.min(self:GetVerticalScrollRange(),self:GetVerticalScroll()-d*55))) end)
 local footer=label(v,'',0,-482,890,10)
 if standalone then
  v:ClearAllPoints();v:SetPoint('TOPLEFT',16,-36);v:SetSize(1068,798)
  raidButton:SetWidth(526);raidButton.title:SetWidth(508)
  bossButton:ClearAllPoints();bossButton:SetPoint('TOPLEFT',538,0);bossButton:SetWidth(530);bossButton.title:SetWidth(512)
  bossTab:SetWidth(300);generalTab:ClearAllPoints();generalTab:SetPoint('TOPLEFT',312,-38);generalTab:SetWidth(300)
  previousButton:ClearAllPoints();previousButton:SetPoint('TOPLEFT',624,-38);nextButton:ClearAllPoints();nextButton:SetPoint('TOPLEFT',751,-38)
  info:ClearAllPoints();info:SetPoint('TOPLEFT',0,-78);info:SetWidth(1068)
  scroll:ClearAllPoints();scroll:SetPoint('TOPLEFT',0,-100);scroll:SetSize(1042,670);body:SetWidth(1026)
  footer:ClearAllPoints();footer:SetPoint('TOPLEFT',0,-780);footer:SetWidth(1068)
 end
 local function escape(x) return tostring(x or ''):gsub('|','||') end
 local function rgb(h,r,g,b) if type(h)=='string' and h:match('^#%x%x%x%x%x%x$') then return tonumber(h:sub(2,3),16)/255,tonumber(h:sub(4,5),16)/255,tonumber(h:sub(6,7),16)/255 end return r,g,b end
 local function piece(i)
  local p=pieces[i];if not p then p=CreateFrame('Frame',nil,body);p.bg=p:CreateTexture(nil,'BACKGROUND');p.bg:SetAllPoints();p.text=label(p,'',3,-2,100,12);p.image=p:CreateTexture(nil,'ARTWORK');p:EnableMouse(true)
   p:SetScript('OnEnter',function(self) if self.value~='' then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:AddLine(self.value,1,1,1,true);GameTooltip:Show() end end);p:SetScript('OnLeave',function() GameTooltip:Hide() end);pieces[i]=p
  end;p:Show();p.image:Hide();p.image:SetTexture(nil);return p
 end
 function v:Refresh()
  dropdown:Hide();for _,p in ipairs(pieces) do p:Hide();p.image:SetTexture(nil) end
  local data=((GL.db.guildProfiles or {})[GL.db.selectedGuild] or {}).activeRaids or {};local raid
  for _,r in ipairs(data.rows or {}) do if r.id==GL.masterRaidId then raid=r end end;raid=raid or (data.rows or {})[1]
  local sheet=raid and ((data.sheets or {})[raid.raid] or (raid.raid:match('^zg%-') and (data.sheets or {}).zg))
  local key=tostring(GL.db.selectedGuild)..':'..tostring(raid and raid.raid)
  if key~=lastKey then selected=1;lastKey=key;scroll:SetVerticalScroll(0) end
  local bosses,general=GL.RaidSheetSections(sheet or {})
  for i,b in ipairs(bosses) do if b.tab.name=='Sapphiron' or b.tab.name=='Kel Thuzad' then general[#general+1]={name=b.name..' · Boss-Einteilung',bossLink=i,tab=b.tab,c1=b.c1,c2=b.c2,r1=b.r1} end end
  choices=generalMode and general or bosses;selected=math.min(selected,math.max(1,#choices));local section=choices[selected]
  if section and section.bossLink then selected=section.bossLink;generalMode=false;choices=bosses;section=choices[selected] end
  bossTab.title:SetTextColor(generalMode and .7 or 1,generalMode and .8 or .8,generalMode and .85 or .2)
  generalTab.title:SetTextColor(generalMode and 1 or .7,.8,generalMode and .2 or .85)
  raidButton.title:SetText(raid and (escape(raid.name)..' · '..raid.date..'  v') or 'Kein aktiver Raid');bossButton.title:SetText(section and (escape(section.name)..'  v') or 'Kein Bereich verfügbar')
  info:SetText(sheet and (sheet.available==1 and ('Stand '..date('%d.%m.%Y %H:%M',sheet.exportedAt)..' · '..escape(GL.db.selectedGuild)) or escape(sheet.error or 'Sheet nicht verfügbar')) or 'Noch kein Raidsheet synchronisiert.')
  if not section or not sheet or sheet.available~=1 then body:SetHeight(333);footer:SetText('Für diesen Bereich liegt noch keine Einteilung vor.');return end
  local blocks={section}
  if section.name=='Four Horsemen' and not generalMode then
   blocks={}
   -- Each role keeps its original cells and its own position picture.
   -- Use the three main role blocks; the far-right draft is not part of this view.
   for _,bounds in ipairs({{8,12},{23,31},{14,20}}) do
    if tostring(((section.tab.rows or {})[5] or {})[bounds[1]] or ''):match('%S') then
     blocks[#blocks+1]={tab=section.tab,c1=bounds[1],c2=bounds[2],r1=5,r2=section.r2}
    end
   end
   if #blocks==0 then blocks={section} end
  end
  local n,yOffset=0,0
  for _,block in ipairs(blocks) do
  local t=block.tab;local rows=t.rows or {};local c1,c2,r1=block.c1,block.c2,block.r1
  local r2=r1;local imageAt={};local mergeAt={};local covered={}
  for r=r1,math.min(#rows,block.r2 or #rows) do for c=c1,c2 do if tostring((rows[r] or {})[c] or ''):match('%S') or tostring(((t.notes or {})[r] or {})[c] or ''):match('%S') then r2=math.max(r2,r) end end end
  for _,m in ipairs(t.merges or {}) do if m.c>=c1 and m.c<=c2 and m.r>=r1 then
   mergeAt[m.r..':'..m.c]=m
   for r=m.r,m.r+m.h-1 do for c=m.c,math.min(c2,m.c+m.w-1) do if r~=m.r or c~=m.c then covered[r..':'..c]=true end end end
  end end
  for _,im in ipairs(t.images or {}) do if im.col>=c1 and im.col<=c2 and im.row>=r1 and im.row<=(block.r2 or #rows) then imageAt[im.row..':'..im.col]=im;local m=mergeAt[im.row..':'..im.col];r2=math.max(r2,im.row+(m and m.h or 1)-1) end end
  local xs,ys={},{};local total=0
  for c=c1,c2 do xs[c]=total;total=total+((t.widths or {})[c] or 110) end;xs[c2+1]=total
  local scale=(body:GetWidth()-8)/math.max(1,total);local rowScale=scale*.60;local height=0
  for r=r1,r2 do ys[r]=height;height=height+((t.heights or {})[r] or 30)*rowScale end;ys[r2+1]=height
  for r=r1,r2 do for c=c1,c2 do if not covered[r..':'..c] then
   local m=mergeAt[r..':'..c];local endC=math.min(c2+1,c+(m and m.w or 1));local endR=math.min(r2+1,r+(m and m.h or 1));n=n+1;local p=piece(n)
   local w=(xs[endC]-xs[c])*scale;local h=ys[endR]-ys[r];p:ClearAllPoints();p:SetPoint('TOPLEFT',xs[c]*scale,-yOffset-ys[r]);p:SetSize(math.max(1,w-2),math.max(1,h-2))
   local value=escape((rows[r] or {})[c]);local note=escape(((t.notes or {})[r] or {})[c]);p.value=value..(note~='' and ('\n'..note) or '')
   p.text:SetText(value);p.text:SetWidth(math.max(1,w-6));p.text:SetHeight(math.max(1,h-4));p.text:SetJustifyH('CENTER');p.text:SetJustifyV('MIDDLE');p.text:SetFont(STANDARD_TEXT_FONT,math.max(10,math.min(18,((m and m.w>=4 and m.h>=2 and r==r1) and h or ((t.heights or {})[r] or 30)*rowScale)*.55)))
   p.bg:SetColorTexture(rgb(((t.backgrounds or {})[r] or {})[c],0,0,0));p.text:SetTextColor(rgb(((t.fontColors or {})[r] or {})[c],1,1,1))
   local im=imageAt[r..':'..c];if im and im.texture and im.texture:match('^Interface\\AddOns\\GuildLootEra\\Media\\Raidsheets\\%x+$') then
    p.image:SetTexture(im.texture);p.image:ClearAllPoints();p.image:SetPoint('CENTER');local ratio=math.min((w-2)/math.max(1,im.width),(h-2)/math.max(1,im.height));p.image:SetSize(im.width*ratio,im.height*ratio);p.image:Show()
   end
  end end end
  yOffset=yOffset+height+24
  end
  body:SetHeight(math.max(scroll:GetHeight(),yOffset));scroll:SetVerticalScroll(math.min(scroll:GetVerticalScroll(),math.max(0,yOffset-scroll:GetHeight())))
  footer:SetText((generalMode and 'Kompakte Rollenübersicht · ' or 'Kompakte Bossübersicht · ')..'Mausrad: nach unten · Maus über Zelle: vollständiger Text')
 end
 return v
end

function GL.LootPriority(raid,entry)
 if not raid or not entry.recipient then return '—' end
 local data=(((GL.db.guildProfiles or {})[raid.guild] or {}).activeRaids or {})
 local list=(data.lists or {})[raid.raidId]
 if not list then return 'Nicht prüfbar' end
 local function norm(value) return (strlower or string.lower)(tostring(value or ''):gsub('^%s+',''):gsub('%s+$','')) end
 local function identity(name,realm) return norm(name)..'-'..norm(realm):gsub('%s','') end
 local player,realm=tostring(entry.recipient):match('^(.-)%-(.+)$')
 if not player or not realm then return 'Nicht prüfbar' end
 local found={}
 for _,row in ipairs(list.rows or {}) do
  if identity(row.player,row.realm)==identity(player,realm) then
   for _,key in ipairs({'p1','p2','p3','p0'}) do
    if key=='p0' or list.published==1 then
     local id=tonumber(row[key..'Id']);local matches
     if id and id>0 then matches=id==tonumber(entry.itemId)
     else matches=norm(row[key])~='' and norm(row[key])~='gesetzt' and norm(row[key])==norm(entry.itemName) end
     if matches then found[#found+1]=key=='p0' and (row.p0Plus==1 and 'P0+' or 'P0') or key:upper() end
    end
   end
  end
 end
 if #found>0 then return table.concat(found,' / ') end
 return list.published==1 and 'Keine Prio' or 'Nicht prüfbar'
end

function GL.LootTableRows(raid,receipts)
 local rows={};local entries={}
 if receipts=='evidence' then
  for _,e in ipairs(raid and raid.chatEvidence or {}) do
   rows[#rows+1]={at=e.observedAt,player=e.sender,itemId=e.itemId,itemName=e.itemName or ('Wurf '..e.roll..' ('..e.minimum..'-'..e.maximum..')'),quantity='—',priority=e.priority or '—',source=e.players or 'Item offen',detail=e.raw}
  end
  return rows
 end
 if raid then if receipts=='trade' then entries=raid.trades or {} elseif receipts then entries=raid.receipts or {} else entries=raid.drops or {} end end
 for _,entry in ipairs(entries) do
  rows[#rows+1]={itemId=entry.itemId,itemName=entry.itemName,quantity=entry.quantity or 1,priority=receipts and GL.LootPriority(raid,entry) or '—',player=receipts and entry.recipient or '—',source=receipts=='trade' and ('Von '..tostring(entry.giver)) or receipts and 'Quelle unbestätigt' or (entry.sourceName or 'Unbekannt'),at=entry.observedAt or entry.firstSeenAt or entry.createdAt}
 end
 return rows
end
function GL.CreateLootTable(parent)
 local v=CreateFrame('Frame',nil,parent);v:SetPoint('TOPLEFT',24,-284);v:SetSize(890,355)
 local receipts=true;local selected;local widgets={}
 function v:Select(r) selected=r;v.archived=r and r.archivedAt~=nil or false end
 function v:GetRecording()
  if selected and selected.guild==GL.db.selectedGuild and (selected.archivedAt~=nil)==(v.archived==true) then return selected end
  return GL.RecordingList(v.archived)[1]
 end
 local function text(owner,value,x,y,w)
  local t=owner:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');t:SetPoint('TOPLEFT',x,y);t:SetWidth(w);t:SetJustifyH('LEFT');t:SetText(value);return t
 end
 local function button(value,x,w,fn)
  local b=CreateFrame('Button',nil,v);b:SetPoint('TOPLEFT',x,0);b:SetSize(w,28);local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.08,.17,.21,1);b.title=text(b,value,6,-7,w-12);b:SetScript('OnClick',fn);return b
 end
 local receivedButton=button('Empfangene Items',0,180,function() receipts=true;v:Refresh() end)
 local dropsButton=button('Bestätigte Drops',190,170,function() receipts=false;v:Refresh() end)
 local tradeButton=button('Handel',370,100,function() receipts='trade';v:Refresh() end)
 local evidenceButton=button('Prio / Würfe',480,120,function() receipts='evidence';v:Refresh() end)
 local raidButton=button('Raidprotokoll auswählen',610,270,function()
  local raids=GL.RecordingList(v.archived)
  local current=v:GetRecording();local nextIndex=1;for i,r in ipairs(raids) do if r==current then nextIndex=i%math.max(1,#raids)+1 end end;selected=raids[nextIndex];v:Refresh()
 end)
 for _,h in ipairs({{'Zeit',0,65},{'Spieler',70,195},{'Item',275,270},{'Prio',550,100},{'Menge',655,45},{'Quelle',710,150}}) do text(v,h[1],h[2],-39,h[3]):SetTextColor(0,1,.85) end
 local scroll=CreateFrame('ScrollFrame',nil,v,'UIPanelScrollFrameTemplate');scroll:SetPoint('TOPLEFT',0,-62);scroll:SetSize(862,270)
 local body=CreateFrame('Frame',nil,scroll);body:SetSize(862,1);scroll:SetScrollChild(body)
 local info=text(v,'',0,-342,880)
 local empty=text(body,'',12,-18,820)
 function v:Refresh()
  for _,w in ipairs(widgets) do w:Hide() end
  local raid=v:GetRecording();selected=raid
  raidButton.title:SetText(raid and ((raid.raidName or 'Raid')..' · '..date('%d.%m. %H:%M',raid.startedAt)..' >') or 'Keine Aufzeichnung')
  local rows=GL.LootTableRows(raid,receipts)
  receivedButton.title:SetTextColor(receipts==true and 1 or .7,receipts==true and .82 or .8,receipts==true and 0 or .85)
  tradeButton.title:SetTextColor(receipts=='trade' and 1 or .7,receipts=='trade' and .82 or .8,receipts=='trade' and 0 or .85)
  dropsButton.title:SetTextColor(receipts and .7 or 1,receipts and .8 or .82,receipts and .85 or 0)
  evidenceButton.title:SetTextColor(receipts=='evidence' and 1 or .7,receipts=='evidence' and .82 or .8,receipts=='evidence' and 0 or .85)
  empty:SetText(receipts=='evidence' and 'Noch keine Prio-Meldungen oder Würfe erfasst. Neue Meldungen werden während der Aufzeichnung gesammelt.' or receipts=='trade' and 'Noch kein abgeschlossener eigener Handel mit Raidmitgliedern erfasst.\nÜbergaben zwischen anderen Spielern sind hier nicht sichtbar.' or receipts and 'Noch keine empfangenen Items in dieser Aufzeichnung.' or ('Noch keine Beutequelle erfasst. '..#(raid and raid.receipts or {})..' Empfangsmeldungen findest du unter „Empfangene Items“.\n\nBosskills allein bestätigen keine Beutequelle. Dafür muss das Lootfenster erfasst werden – bei dir oder über ein teilendes GuildLoot-Addon im Raid.'))
  if not raid then empty:SetText(v.archived and 'Noch keine archivierten Raidprotokolle.' or 'Keine offenen Raidprotokolle. Übertragene Raids findest du unter Raids → Raidarchiv.\nFür heute: Prioliste auswählen und Aufzeichnung starten.') end
  empty:SetShown(#rows==0)
  if #rows==0 then scroll:SetVerticalScroll(0) end
  for i=#rows,1,-1 do local entry=rows[i];local n=#rows-i+1;local w=widgets[n]
   if not w then
    w=CreateFrame('Frame',nil,body);w:SetPoint('TOPLEFT',0,-(n-1)*38);w:SetSize(860,36);local bg=w:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.08,.17,.21,n%2==0 and .6 or .95)
    w.time=text(w,'',0,-9,65);w.player=text(w,'',70,-9,195);w.item=text(w,'',307,-9,235);w.priority=text(w,'',550,-9,100);w.amount=text(w,'',655,-9,45);w.source=text(w,'',710,-9,150)
    w.icon=w:CreateTexture(nil,'ARTWORK');w.icon:SetPoint('TOPLEFT',275,-4);w.icon:SetSize(28,28)
    w:EnableMouse(true);w:SetScript('OnEnter',function(self) if self.detail then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText(self.detail:gsub('|','||'),1,1,1,1,true);GameTooltip:Show() elseif self.itemId then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetHyperlink('item:'..self.itemId);GameTooltip:Show() end end);w:SetScript('OnLeave',function() GameTooltip:Hide() end);widgets[n]=w
   end
   w:Show();w.itemId=entry.itemId;w.detail=entry.detail
   w.time:SetText(entry.at and date('%H:%M:%S',entry.at) or '—');w.player:SetText(tostring(entry.player or '—'):gsub('|','||'));w.item:SetText(tostring(entry.itemName or entry.itemId):gsub('|','||'));w.amount:SetText(tostring(entry.quantity));w.source:SetText(tostring(entry.source):gsub('|','||'))
   w.priority:SetText(entry.priority);local matched=entry.priority:match('^P[0123]');w.priority:SetTextColor(matched and .3 or .7,matched and 1 or .7,matched and .6 or .7)
   local _,_,quality,_,_,_,_,_,_,icon=GetItemInfo(entry.itemId or 0);w.icon:SetTexture(icon or 'Interface\\Icons\\INV_Misc_QuestionMark');local color=ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality];w.item:SetTextColor(color and color.r or 1,color and color.g or 1,color and color.b or 1)
  end
  body:SetHeight(math.max(270,#rows*38));info:SetText(#rows..' Einträge · '..(receipts=='evidence' and 'Chatnachweise zur manuellen Prüfung · Würfe ohne automatische Itemzuordnung · Maus über Zeile: Originaltext' or receipts=='trade' and 'Abgeschlossene eigene Handelsvorgänge · keine zusätzlichen Drops · Quelle = Geber' or receipts and 'Empfangene Items; diese Meldungen zählen nicht als zusätzliche Drops.' or 'Drops mit zugeordneter Quelle.'))
 end
 local elapsed=0;v:SetScript('OnUpdate',function(_,dt) elapsed=elapsed+dt;if elapsed>=2 then elapsed=0;if v:IsShown() then v:Refresh() end end end)
 return v
end
