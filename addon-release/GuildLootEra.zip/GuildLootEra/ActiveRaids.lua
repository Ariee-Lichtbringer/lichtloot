local _,GL=...
function GL.CreateActiveRaidsView(parent)
    local view=CreateFrame('Frame',nil,parent);view:SetPoint('TOPLEFT',24,-122);view:SetSize(890,556)
    local page=1;local cards={};local openForm
    local function label(owner,x,y,w,size)
        local l=owner:CreateFontString(nil,'OVERLAY','GameFontHighlight');l:SetPoint('TOPLEFT',x,y);l:SetWidth(w);l:SetJustifyH('LEFT');l:SetFont(STANDARD_TEXT_FONT,size);l:SetTextColor(.72,.82,.88);return l
    end
    local heading=label(view,0,0,500,22);heading:SetTextColor(.15,.9,.8)
    local context=label(view,0,-34,890,12)
    local function button(text,x,y,w,fn,owner)
        local b=CreateFrame('Button',nil,owner or view);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,24)
        local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.13,.23,.27,1);b.background=bg
        local l=label(b,8,-7,w-16,13);l:SetText(text);b.label=l;b:SetScript('OnClick',fn);if GL.GateSyncButton then GL.GateSyncButton(b,text) end;return b
    end
    button('Charakter wechseln',670,0,220,function() GL.CyclePersonalProfile();view:Refresh() end)
    local instructions=label(view,590,-78,300,13);instructions:SetText('Raid anklicken: Anmeldung und Prios')
    local countLabel=label(view,0,-78,570,13)
    for i=1,5 do
        local card=CreateFrame('Frame',nil,view);card:SetPoint('TOPLEFT',0,-110-(i-1)*76);card:SetSize(890,68)
        local bg=card:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.07,.13,.18,1)
        card.day=label(card,14,-12,125,16);card.clock=label(card,14,-36,125,13)
        card.title=label(card,150,-10,470,17);card.title:SetTextColor(.95,.77,.3)
        card.detail=label(card,150,-37,470,12);card.mine=label(card,625,-10,250,12);card.action=label(card,625,-42,250,13);card.action:SetText('|cff79e6c5Anmelden / Prios >|r');card:EnableMouse(true);card:SetScript('OnMouseUp',function() if card.raid then openForm(card.raid) end end)
        cards[i]=card
    end
    local empty=label(view,16,-135,850,15)
    local pages=label(view,365,-497,250,13)
    button('<',0,-488,64,function() page=math.max(1,page-1);view:Refresh() end)
    button('>',826,-488,64,function() page=page+1;view:Refresh() end)
    local hint=label(view,0,-536,890,12);hint:SetText('Absenden → /reload → Sync-App überträgt → weiteres /reload übernimmt die Serverbestätigung.')
    function view:Refresh()
        local profile=GL.db.guildProfiles[GL.db.selectedGuild] or {};local data=profile.activeRaids;local rows=data and data.rows or {};local personal=GL.DisplayProfile()
        heading:SetText('Aktive Raids · '..GL.GuildName(GL.db.selectedGuild))
        context:SetText(data and ('Stand '..date('%d.%m.%Y %H:%M',data.exportedAt)..(personal and (' · Dein Charakter: '..personal.player..' – '..personal.realm) or '')) or 'In GuildLoot Sync „Jetzt synchronisieren“ anklicken, danach /reload.')
        countLabel:SetText(#rows..' bevorstehende Raids der Gilde')
        local max=math.max(1,math.ceil(#rows/5));page=math.min(page,max);pages:SetText('Seite '..page..' / '..max)
        empty:SetShown(#rows==0);empty:SetText(data and 'Keine bevorstehenden Raids im aktuellen Gildenexport.' or 'Noch keine Raidübersicht synchronisiert. Benötigt GuildLoot Sync ab 0.1.3.')
        for i,card in ipairs(cards) do
            local r=rows[(page-1)*5+i];card:SetShown(r~=nil)
            if r then
                card.raid=r
                local year,month,day=r.date:match('^(%d+)%-(%d+)%-(%d+)$')
                card.day:SetText(day and (day..'.'..month..'.'..year) or r.date);card.clock:SetText(r.clock~='' and (r.clock..' Uhr') or 'Zeit folgt')
                card.title:SetText(r.name);card.detail:SetText(r.kind..' · '..r.count..' Einträge')
                local mine
                for _,event in ipairs(personal and personal.calendar or {}) do if event.id==r.id or event.id=='p0:'..r.id then mine=event;break end end
                card.mine:SetText(mine and (mine.hasPrio and '|cff79e6a2Angemeldet · Prio vorhanden|r' or '|cffffcc40Angemeldet · Prio fehlt|r') or 'Keine eigene Anmeldung im Import')
            end
        end
    end
    local form=CreateFrame('Frame',nil,view);form:SetAllPoints();form:EnableMouse(true)
    if form.SetFrameLevel and view.GetFrameLevel then form:SetFrameLevel(view:GetFrameLevel()+10) end
    local bg=form:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.025,.06,.09,1)
    local title=label(form,12,-8,730,20);title:SetTextColor(.05,.9,.8)
    local identity=label(form,44,-35,690,18)
    local classIcon=form:CreateTexture(nil,'ARTWORK');classIcon:SetPoint('TOPLEFT',12,-34);classIcon:SetSize(24,24)
    button('Schließen',756,-8,120,function() form:Hide() end,form)
    local selectedRaid,catalog,list,selected=nil,{},{},{}
    local editingProfile
    local priorityRules,ownRules
    local function level(key)
        for _,v in ipairs(priorityRules and priorityRules.levels or {}) do if v.key==key then return v end end
        return {enabled=true,label=key:upper()}
    end
    local function allowed(key,item)
        if not selectedRaid or not priorityRules then return false end
        if selectedRaid.raid=="ony" and key~="p1" then return false end
        if key=="p0" or key=="plus" then
            for _,v in ipairs((priorityRules.items or {})[selectedRaid.raid] or {}) do if (not item or v.name==item.name) and v[key] then return true end end
            return false
        end
        return level(key).enabled~=false
    end
    local function selectionAllowed(key,item)
        if not allowed(key,item) then return false end
        local recruit=priorityRules and priorityRules.recruit
        if recruit and recruit.enabled then
            for _,raid in ipairs(recruit.raids or {}) do if raid==selectedRaid.raid then
                local released=ownRules and ownRules.recruitReleases and ownRules.recruitReleases[raid]
                if released~=true and key~='p0' then
                    for _,v in ipairs(recruit.allowedPriorities or {}) do if v==(key=='plus' and 'p0plus' or key) then return true end end
                    return false
                end
            end end
        end
        return true
    end
    local statusIndex,roleIndex,pickerPage,listPage=1,1,1,1
    local statuses={{'Angemeldet','signed'},{'Bank','bench'},{'Verspätet','late'},{'Vielleicht','tentative'},{'Abgemeldet','absent'}}
    local roles={{'Schaden','dd'},{'Heilung','heal'},{'Tank','tank'}}
    local feedback=label(form,12,-523,865,12);feedback:SetTextColor(1,.8,.3)
    local function queue(kind,payload)
        local p=GL.DisplayProfile();if not p or not editingProfile or p.player~=editingProfile.player or p.realm~=editingProfile.realm then feedback:SetText('Charakter gewechselt. Bitte den Raid erneut öffnen.');return end
        local ok,err=pcall(GL.QueueWebsiteAction,selectedRaid,kind,payload)
        feedback:SetText(ok and 'Vorgemerkt · /reload zum Senden · Serverbestätigung nach erneutem /reload.' or tostring(err))
    end
    local statusButton,roleButton
    statusButton=button('Angemeldet >',12,-64,200,function() statusIndex=statusIndex%#statuses+1;statusButton.label:SetText(statuses[statusIndex][1]..' >') end,form)
    roleButton=button('Schaden >',222,-64,175,function() roleIndex=roleIndex%#roles+1;roleButton.label:SetText(roles[roleIndex][1]..' >') end,form)
    local signup=button('Anmeldung absenden',407,-64,238,function() queue('signup',{status=statuses[statusIndex][2],role=roles[roleIndex][2]}) end,form)
    local pureHint=label(form,12,-66,620,13)
    button('Raidsheet',650,-64,226,function() if selectedRaid then GL.ShowRaidSheet(selectedRaid.id) end end,form)
    local function edit(x,y,w)
        local e=CreateFrame('EditBox',nil,form,'InputBoxTemplate');e:SetPoint('TOPLEFT',x,y);e:SetSize(w,24);e:SetAutoFocus(false);e:SetFontObject('ChatFontNormal');return e
    end
    label(form,12,-94,420,17):SetText('Möglicher Loot')
    label(form,460,-94,410,17):SetText('Aktuelle Prioliste')
    local search=edit(18,-116,422);local rosterSearch=edit(466,-116,404)
    local selection=label(form,12,-143,430,11);local publication=label(form,460,-143,410,11)
    local picker,roster={},{};local pickerRefresh,rosterRefresh
    local rosterScroll,updatingRosterScroll
    local qualityNames={['Schlecht']=0,['Gewöhnlich']=1,['Normal']=1,['Ungewöhnlich']=2,['Selten']=3,['Episch']=4,['Legendär']=5}
    local fallbackColors={[0]={.62,.62,.62},[1]={1,1,1},[2]={.12,1,0},[3]={0,.44,.87},[4]={.64,.21,.93},[5]={1,.5,0}}
    local function decorate(b,item)
        b.item=item;b.itemId=item and tonumber(item.id) or nil
        if not item then b.label:SetText('');return end
        local name,link,quality,_,_,_,_,_,_,icon
        local get=GetItemInfo or (C_Item and C_Item.GetItemInfo)
        if get then name,link,quality,_,_,_,_,_,_,icon=get(item.id) end
        quality=quality or tonumber(item.quality) or qualityNames[item.quality]
        local color=quality and fallbackColors[quality] or {.72,.82,.88}
        b.label:SetText(name or item.name);b.label:SetTextColor(unpack(color))
        if b.icon then b.icon:SetTexture(icon or (item.icon and item.icon~='' and ('Interface\\Icons\\'..item.icon)) or 'Interface\\Icons\\INV_Misc_QuestionMark') end
    end
    local function tooltip(b)
        b:SetScript('OnEnter',function(self) if self.itemId and GameTooltip then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetHyperlink('item:'..self.itemId);if self.item and self.item.rewards and self.item.rewards~='' then GameTooltip:AddLine('Questbelohnungen',1,.8,.3);for reward in self.item.rewards:gmatch('[^\n]+') do GameTooltip:AddLine(reward,.75,.5,1,true) end end;GameTooltip:Show() end end)
        b:SetScript('OnLeave',function() if GameTooltip then GameTooltip:Hide() end end)
    end
    local chosen={}
    local function selectedRefresh()
        for i,b in ipairs(chosen) do
            local key=({'p1','p2','p3','p0'})[i];local item=selected[key]
            b:SetShown(allowed(key) or (key=='p0' and allowed('plus')))
            decorate(b,item);if not item then b.label:SetText((i==4 and 'P0 / P0+' or level('p'..i).label)..': nicht gewählt') else b.label:SetText((i==4 and (selected.plus and 'P0+: ' or 'P0: ') or level('p'..i).label..': ')..b.label:GetText()) end
        end
    end
    for i=1,4 do
        local key=({'p1','p2','p3','p0'})[i]
        local b=button('',12+(i-1)*218,-460,212,function() selected[key]=nil;selectedRefresh();pickerRefresh() end,form);tooltip(b);chosen[i]=b
    end
    for i=1,8 do
        local b=button('',12,-158-(i-1)*34,430,function() end,form);b:SetSize(430,32)
        b.label:SetPoint('TOPLEFT',32,-5);b.label:SetWidth(200);b.label:SetHeight(26);b.label:SetFont(STANDARD_TEXT_FONT,12)
        b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',4,-4);b.icon:SetSize(24,24);tooltip(b)
        b.prios={}
        for j,key in ipairs({'p1','p2','p3','p0','plus'}) do
            local pbutton=button(({p1='P1',p2='P2',p3='P3',p0='P0',plus='P0+'})[key],236+(j-1)*38,0,36,function()
                if not b.item or not selectionAllowed(key,b.item) then return end
                if key=='p0' or key=='plus' then selected.p0=b.item;selected.plus=key=='plus';selected.p1=nil;selected.p2=nil;selected.p3=nil
                else selected.p0=nil;selected.plus=nil;selected[key]=b.item end
                selectedRefresh();pickerRefresh()
            end,b);pbutton:SetSize(34,32);pbutton.label:SetFont(STANDARD_TEXT_FONT,10);pbutton.label:SetPoint('TOPLEFT',3,-10);pbutton.label:SetWidth(32);b.prios[key]=pbutton
        end
        picker[i]=b
    end
    local function searchKey(text)
        text=tostring(text or ''):gsub('Ä','a'):gsub('Ö','o'):gsub('Ü','u'):gsub('ä','a'):gsub('ö','o'):gsub('ü','u'):gsub('ß','ss'):lower()
        return text:gsub('[^a-z0-9]+',' ')
    end
    pickerRefresh=function()
        local filtered={};local term=searchKey(search:GetText())
        for _,item in ipairs(catalog) do
            local haystack=item.search or searchKey(item.name..' '..tostring(item.id)..' '..(item.slot or '')..' '..(item.boss or ''))
            local matches=true;for word in term:gmatch('%S+') do if not haystack:find(word,1,true) then matches=false;break end end
            if matches then filtered[#filtered+1]=item end
        end
        local function rank(item)
            for index,key in ipairs({'p1','p2','p3','p0'}) do if selected[key] and selected[key].id==item.id then return index end end
            return 5
        end
        table.sort(filtered,function(a,b) local ar,br=rank(a),rank(b);if ar~=br then return ar<br end;return a.name<b.name end)
        pickerPage=math.min(pickerPage,math.max(1,math.ceil(#filtered/8)))
        selection:SetText('Item, Token, Quest, Klasse oder Boss · '..#filtered..' Items · Seite '..pickerPage)
        for i,b in ipairs(picker) do
            local item=filtered[(pickerPage-1)*8+i];b:SetShown(item~=nil)
            if item then
                decorate(b,item)
                local position=0
                for _,key in ipairs({'p1','p2','p3','p0','plus'}) do local p=b.prios[key]
                    local show=selectionAllowed(key,item);p:SetShown(show)
                    if show then p:ClearAllPoints();p:SetPoint('TOPLEFT',236+position*38,0);position=position+1 end
                    p.label:SetText((key=='p0' and 'P0') or (key=='plus' and 'P0+') or level(key).label)
                    local chosenItem=selected[key=='plus' and 'p0' or key]
                    local active=chosenItem and chosenItem.id==item.id and (key~='plus' or selected.plus) and (key~='p0' or not selected.plus)
                    p.background:SetColorTexture(active and .68 or .045,active and .48 or .12,active and .08 or .16,1)
                    p.label:SetTextColor(active and 1 or .72,active and .9 or .82,active and .45 or .88)
                end
            end
        end
    end
    local classes={Krieger='WARRIOR',Druide='DRUID',Schurke='ROGUE',Magier='MAGE',Priester='PRIEST',Paladin='PALADIN',['Jäger']='HUNTER',Hexenmeister='WARLOCK',Schamane='SHAMAN'}
    for i=1,8 do
        local row=CreateFrame('Frame',nil,form);row:SetPoint('TOPLEFT',460,-158-(i-1)*34);row:SetSize(410,34)
        local background=row:CreateTexture(nil,'BACKGROUND');background:SetAllPoints();background:SetColorTexture(.065,.12,.17,1)
        row.number=label(row,3,-3,25,11);row.number:SetTextColor(.6,.7,.78)
        row.name=label(row,30,-3,375,12);row.cells={}
        for j=1,4 do local b=button('',(j-1)*101,-16,100,function() end,row);b:SetSize(100,18);b.label:SetPoint('TOPLEFT',4,-2);b.label:SetFont(STANDARD_TEXT_FONT,10);b.label:SetHeight(16);b.label:SetWordWrap(false);tooltip(b);row.cells[j]=b end
        roster[i]=row
    end
    local function lookup(id,name)
        for _,item in ipairs(catalog) do if (id and id>0 and item.id==id) or (name~='' and item.name==name) then return item end end
        if id and id>0 then return {id=id,name=name} end
    end
    rosterRefresh=function()
        local rows={};local term=(rosterSearch:GetText() or ''):lower()
        for _,r in ipairs(list.rows or {}) do if (r.player..' '..r.realm..' '..r.className):lower():find(term,1,true) then rows[#rows+1]=r end end
        table.sort(rows,function(a,b)
            local ac,bc=classes[a.className] or a.className or '',classes[b.className] or b.className or ''
            if ac~=bc then return ac<bc end
            return (a.player..a.realm)<(b.player..b.realm)
        end)
        listPage=math.max(1,math.min(listPage,math.max(1,#rows-7)))
        if rosterScroll then updatingRosterScroll=true;rosterScroll:SetMinMaxValues(1,math.max(1,#rows-7));rosterScroll:SetValue(listPage);rosterScroll:SetShown(#rows>8);updatingRosterScroll=false end
        publication:SetText((list.published==1 and 'Veröffentlicht' or 'Prios verborgen · P0-Auswahl sichtbar')..' · '..#rows..' Spieler')
        for i,row in ipairs(roster) do
            local r=rows[listPage-1+i];row:SetShown(r~=nil)
            if r then
                row.number:SetText(tostring(listPage-1+i)..'.');row.name:SetText(r.player..' · '..r.realm)
                local color=RAID_CLASS_COLORS and RAID_CLASS_COLORS[classes[r.className] or r.className];row.name:SetTextColor(color and color.r or .72,color and color.g or .82,color and color.b or .88)
                for j,b in ipairs(row.cells) do
                    b:SetShown(j==4 and (allowed('p0') or allowed('plus')) or (j<4 and allowed('p'..j)))
                    local key=j==4 and 'p0' or 'p'..j;local name=r[key] or '';local visible=j==4 or list.published==1 or r.own==true
                    local item=visible and lookup(r[key..'Id'],name)
                    decorate(b,item)
                    if not item then b.label:SetText((j==4 and (r.p0Plus==1 and 'P0+ ' or 'P0 ') or level('p'..j).label..' ')..(name~='' and (visible and name or 'gesetzt') or '—')) end
                end
            end
        end
    end
    search:SetScript('OnTextChanged',function() pickerPage=1;pickerRefresh() end)
    rosterSearch:SetScript('OnTextChanged',function() listPage=1;rosterRefresh() end)
    button('<',12,-432,48,function() pickerPage=math.max(1,pickerPage-1);pickerRefresh() end,form):SetSize(48,20)
    button('>',394,-432,48,function() pickerPage=pickerPage+1;pickerRefresh() end,form):SetSize(48,20)
    local function scrollRoster(_,delta)
        listPage=math.max(1,listPage+(delta<0 and 1 or -1));rosterRefresh()
    end
    -- Catch the wheel over rows and item buttons, including empty list space.
    local rosterArea=CreateFrame('Frame',nil,form);rosterArea:SetPoint('TOPLEFT',460,-158);rosterArea:SetSize(410,272)
    if rosterArea.SetFrameLevel and form.GetFrameLevel then rosterArea:SetFrameLevel(form:GetFrameLevel()) end
    rosterArea:EnableMouseWheel(true);rosterArea:SetScript('OnMouseWheel',scrollRoster)
    for _,row in ipairs(roster) do
        row:EnableMouseWheel(true);row:SetScript('OnMouseWheel',scrollRoster)
        for _,cell in ipairs(row.cells) do cell:EnableMouseWheel(true);cell:SetScript('OnMouseWheel',scrollRoster) end
    end
    rosterScroll=CreateFrame('Slider',nil,form);rosterScroll:SetPoint('TOPLEFT',874,-158);rosterScroll:SetSize(12,268);rosterScroll:SetOrientation('VERTICAL');rosterScroll:SetValueStep(1)
    local track=rosterScroll:CreateTexture(nil,'BACKGROUND');track:SetAllPoints();track:SetColorTexture(.06,.09,.12,1)
    local thumb=rosterScroll:CreateTexture(nil,'OVERLAY');thumb:SetSize(12,28);thumb:SetColorTexture(.55,.65,.72,1);rosterScroll:SetThumbTexture(thumb)
    rosterScroll:SetScript('OnValueChanged',function(_,value) if not updatingRosterScroll then listPage=math.floor(value+.5);rosterRefresh() end end)
    rosterScroll:EnableMouseWheel(true);rosterScroll:SetScript('OnMouseWheel',scrollRoster)
    label(form,460,-435,410,11):SetText('Mausrad: Prioliste scrollen')
    button('Prios absenden',12,-494,430,function()
        for key,item in pairs(selected) do if key~='plus' and item and not selectionAllowed(key=='p0' and selected.plus and 'plus' or key,item) then feedback:SetText('Diese Auswahl ist nicht mehr freigegeben. Bitte neu auswählen.');return end end
        local mode=selected.p0 and (selected.plus and 'p0plus' or 'p0') or 'normal'
        local first=selected.p0 or selected.p1 or selected.p2 or selected.p3
        if not first then feedback:SetText('Bitte eine verfügbare Priorität auswählen.');return end
        queue('prio',{mode=mode,p1=selected.p0 and selected.p0.id or (selected.p1 and selected.p1.id or 0),p2=selected.p2 and selected.p2.id or 0,p3=selected.p3 and selected.p3.id or 0})
    end,form)
    label(form,460,-494,410,11):SetText('Ausgewähltes Item anklicken: entfernen.\nFreigaben und Fristen prüft die Website beim Absenden.')
    label(form,12,-544,865,11):SetText('Item-Tooltip: Maus über das Item · Datenabruf alle 30 Sekunden bei geöffneter Sync-App · /reload lädt den neuen Stand.')
    openForm=function(raid)
        selectedRaid=raid;local p=GL.DisplayProfile();local profile=GL.db.guildProfiles[GL.db.selectedGuild] or {};local data=profile.activeRaids or {}
        priorityRules=data.priorityRules
        catalog=data.catalogs and data.catalogs[raid.raid] or {};list=data.lists and data.lists[raid.id] or {};selected={}
        title:SetText(raid.name..' · '..raid.date..' '..raid.clock)
        editingProfile=p
        local own
        for _,record in ipairs(data.ownPrios or {}) do if p and record.player==p.player and record.realm==p.realm then own=record;break end end
        ownRules=own
        local class=own and own.className
        local entries={};local ownRow
        for _,row in ipairs(list.rows or {}) do
            local copy={};for k,v in pairs(row) do copy[k]=v end
            if p and row.player==p.player and row.realm==p.realm then class=class or row.className;ownRow=copy end
            entries[#entries+1]=copy
        end
        local saved
        for _,row in ipairs(own and own.rows or {}) do if row.raidId==raid.id or row.externalRaidId==raid.id then saved=row;break end end
        if saved then
            if not ownRow then ownRow={player=p.player,realm=p.realm,className=class or ''};entries[#entries+1]=ownRow end
            for _,key in ipairs({'p1','p2','p3','p0','p0Plus'}) do ownRow[key]=saved[key] end
            ownRow.own=true
        end
        list={published=list.published,rows=entries}
        if ownRow then
            for _,key in ipairs({'p1','p2','p3','p0'}) do
                if (allowed(key) or (key=='p0' and allowed('plus'))) and (key=='p0' or saved or list.published==1) then selected[key]=lookup(ownRow[key..'Id'],ownRow[key] or '') end
            end
            selected.plus=ownRow.p0Plus==1
            -- P0 submissions also carry duplicate P1–P3 values on the website.
            if selected.p0 then selected.p1=nil;selected.p2=nil;selected.p3=nil end
        end
        local token=classes[class] or class
        if not token and p and UnitName and UnitName('player')==p.player and UnitClass then local _,current=UnitClass('player');token=current end
        local color=RAID_CLASS_COLORS and RAID_CLASS_COLORS[token]
        identity:SetText(p and (p.player..' – '..p.realm..' · '..GL.GuildName(GL.db.selectedGuild)) or 'Bitte zuerst einen Charakter synchronisieren')
        identity:SetTextColor(color and color.r or .8,color and color.g or .85,color and color.b or .9)
        classIcon:SetTexture(token and ('Interface\\Icons\\ClassIcon_'..token) or 'Interface\\Icons\\INV_Misc_QuestionMark')
        statusIndex=1;roleIndex=1;pickerPage=1;listPage=1
        statusButton.label:SetText('Angemeldet >');roleButton.label:SetText('Schaden >')
        statusButton:SetShown(raid.signup==1);roleButton:SetShown(raid.signup==1);signup:SetShown(raid.signup==1);signup:SetEnabled(p~=nil)
        pureHint:SetShown(raid.signup~=1);pureHint:SetText('Prio-Anmeldung · Auswahl direkt am Item. Ohne Rolle und Teilnahmestatus.')
        feedback:SetText(priorityRules and GL.WebsiteActionStatus(raid.id) or 'Gildenregeln fehlen: GuildLoot Sync aktualisieren, synchronisieren und /reload eingeben.');search:SetText('');rosterSearch:SetText('');selectedRefresh();pickerRefresh();rosterRefresh();form:Show()
    end
    form:RegisterEvent('GET_ITEM_INFO_RECEIVED');form:SetScript('OnEvent',function() if form:IsShown() and view:IsShown() then pickerRefresh();rosterRefresh();selectedRefresh() end end)
    form:Hide();view:SetScript('OnHide',function() form:Hide();search:ClearFocus();rosterSearch:ClearFocus();if GameTooltip then GameTooltip:Hide() end end)
    view:EnableMouseWheel(true);view:SetScript('OnMouseWheel',function(_,delta) if form:IsShown() then pickerPage=math.max(1,pickerPage+(delta<0 and 1 or -1));pickerRefresh() else page=math.max(1,page+(delta<0 and 1 or -1));view:Refresh() end end)
    local creator=CreateFrame('Frame',nil,view);creator:SetAllPoints();creator:EnableMouse(true)
    if creator.SetFrameLevel and view.GetFrameLevel then creator:SetFrameLevel(view:GetFrameLevel()+20) end
    local cbg=creator:CreateTexture(nil,'BACKGROUND');cbg:SetAllPoints();cbg:SetColorTexture(.025,.06,.09,1)
    label(creator,16,-12,700,22):SetText('Raid erstellen')
    button('Schließen',756,-8,120,function() creator:Hide() end,creator)
    local createContext=label(creator,16,-50,840,13)
    local createFeedback=label(creator,16,-442,840,13);createFeedback:SetTextColor(1,.8,.3)
    local draft={raid='mc',mode='raid',template='',channel=''};local options={}
    local dropdowns={}
    local popup=CreateFrame('Frame',nil,creator);popup:SetPoint('TOPLEFT',460,-102);popup:SetSize(414,310)
    if popup.SetFrameLevel and creator.GetFrameLevel then popup:SetFrameLevel(creator:GetFrameLevel()+20) end
    local popbg=popup:CreateTexture(nil,'BACKGROUND');popbg:SetAllPoints();popbg:SetColorTexture(.08,.18,.22,1)
    local popupEmpty=label(popup,16,-20,380,14)
    local poprows={};local popupItems={};local popupCallback;local popPage=1
    local function paintPopup()
        popupEmpty:SetShown(#popupItems==0);popupEmpty:SetText('Keine passenden Einträge im Import. Bitte synchronisieren und /reload eingeben. Falls weiterhin leer: Vorlagen in der Gildenleitung prüfen.')
        popPage=math.min(popPage,math.max(1,math.ceil(#popupItems/7)))
        for i,b in ipairs(poprows) do local item=popupItems[(popPage-1)*7+i];b.item=item;b:SetShown(item~=nil);if item then b.label:SetText(item.title or item.name or item.id);b:SetEnabled(not item.header);b.label:SetTextColor(item.header and 1 or .72,item.header and .8 or .82,item.header and .3 or .88) end end
    end
    for i=1,7 do local b;b=button('',8,-8-(i-1)*36,398,function() if b.item and not b.item.header then popupCallback(b.item);popup:Hide() end end,popup);poprows[i]=b end
    button('<',8,-270,58,function() popPage=math.max(1,popPage-1);paintPopup() end,popup)
    button('>',348,-270,58,function() popPage=popPage+1;paintPopup() end,popup)
    local function dropdown(key,title,y,getItems)
        label(creator,16,y,425,12):SetText(title)
        local b;b=button('Auswählen …',16,y-21,425,function()
            popupItems=getItems();popPage=1;popupCallback=function(item) draft[key]=item.id;b.label:SetText(item.title or item.name);if key=='raid' then draft.template='';dropdowns.template.label:SetText('Vorlage auswählen …') end end;paintPopup();popup:Show()
        end,creator);dropdowns[key]=b
    end
    dropdown('mode','Anmeldeart',-85,function() return {{id='raid',title='Vollständiger Raid mit Discord-Anmeldung'},{id='p0',title='Reiner P0-Anmelder mit Discord-Post'}} end)
    local types={{id='mc',title='Geschmolzener Kern'},{id='bwl',title='Pechschwingenhort'},{id='aq40',title="Ahn’Qiraj 40"},{id='naxx',title='Naxxramas'},{id='zg',title="Zul’Gurub"},{id='aq20',title="Ahn’Qiraj 20"},{id='ony',title='Onyxia'}}
    dropdown('raid','Raid · 20er / 40er',-148,function() local rows={{header=true,title='20er-Raids'}};for _,t in ipairs(types) do if t.id=='zg' or t.id=='aq20' then rows[#rows+1]=t end end;rows[#rows+1]={header=true,title='40er-Raids'};for _,t in ipairs(types) do if t.id~='zg' and t.id~='aq20' then rows[#rows+1]=t end end;return rows end)
    dropdown('template','Raidvorlage · nur beim vollständigen Raid benötigt',-211,function() local rows={};for _,t in ipairs(options.templates or {}) do if t.raid==draft.raid then rows[#rows+1]=t end end;return rows end)
    dropdown('channel','Discord-Channel',-274,function() return options.channels or {} end)
    label(creator,16,-340,230,12):SetText('Datum · JJJJ-MM-TT');label(creator,260,-340,180,12):SetText('Uhrzeit · HH:MM')
    local function creatorEdit(x,w)
        local e=CreateFrame('EditBox',nil,creator,'InputBoxTemplate');e:SetPoint('TOPLEFT',x,-362);e:SetSize(w,26);e:SetAutoFocus(false);e:SetFontObject('ChatFontNormal');return e
    end
    local createDate=creatorEdit(22,222);local createTime=creatorEdit(266,174)
    local createButton=button('Raid erstellen und absenden',16,-402,425,function()
        local d,t=createDate:GetText(),createTime:GetText()
        if not d:match('^%d%d%d%d%-%d%d%-%d%d$') or not t:match('^%d%d:%d%d$') then createFeedback:SetText('Bitte Datum und Uhrzeit im angegebenen Format eingeben.');return end
        if draft.channel=='' or (draft.mode=='raid' and draft.template=='') then createFeedback:SetText('Bitte Channel und bei vollständigem Raid eine passende Vorlage auswählen.');return end
        local ok,err=pcall(GL.QueueWebsiteAction,{id='create'},'create',{raid=draft.raid,mode=draft.mode,template=draft.template,channel=draft.channel,date=d,clock=t})
        createFeedback:SetText(ok and 'Erstellung vorgemerkt. /reload zum Senden. Ergebnis anschließend in GuildLoot Sync prüfen.' or tostring(err))
    end,creator)
    label(creator,470,-105,390,16):SetText('Wie beim Schnell-Raid auf GuildLoot')
    label(creator,470,-145,390,13):SetText('Vollständiger Raid: Anmeldung und Prioseite mit der gewählten Vorlage.\n\nReiner P0-Anmelder: Item-Anmeldungen ohne Rolle oder Teilnahmestatus.\n\nDer Discord-Post erscheint im gewählten Channel.\n\nZum Erstellen gelten die Rechte deines Spielerlogins. Datum und Uhrzeit vor dem Absenden prüfen.')
    label(creator,16,-518,850,12):SetText('Nach /reload überträgt die geöffnete Sync-App. Ein weiteres /reload lädt den erstellten Raid und die Serverbestätigung.')
    button('+ Raid erstellen',466,0,194,function()
        form:Hide();local p=GL.DisplayProfile();options=((GL.db.guildProfiles[GL.db.selectedGuild] or {}).activeRaids or {}).creation or {}
        draft={raid='mc',mode='raid',template='',channel=''}
        dropdowns.mode.label:SetText('Vollständiger Raid mit Discord-Anmeldung');dropdowns.raid.label:SetText('Geschmolzener Kern');dropdowns.template.label:SetText('Vorlage auswählen …');dropdowns.channel.label:SetText('Channel auswählen …')
        createDate:SetText(date('%Y-%m-%d'));createTime:SetText('20:00');popup:Hide()
        createContext:SetText(GL.GuildName(GL.db.selectedGuild)..' · '..(p and (p.player..' – '..p.realm) or 'Kein Charakter ausgewählt'))
        createButton:SetEnabled(options.available==1 and p~=nil)
        createFeedback:SetText(options.available==1 and GL.WebsiteActionStatus('create') or 'Erstellung nicht verfügbar. Bitte synchronisieren und die Erstellerrechte auf GuildLoot prüfen.')
        creator:Show()
    end)
    popup:Hide();creator:Hide()
    view:SetScript('OnHide',function() form:Hide();creator:Hide();popup:Hide();search:ClearFocus();rosterSearch:ClearFocus();createDate:ClearFocus();createTime:ClearFocus();if GameTooltip then GameTooltip:Hide() end end)
    return view
end
