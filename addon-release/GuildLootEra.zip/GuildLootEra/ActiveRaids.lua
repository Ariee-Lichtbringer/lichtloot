local _,GL=...
local feedbackText,openCreatorForLead
local RAID_IMAGES={mc=true,bwl=true,aq40=true,naxx=true,zg=true,aq20=true,ony=true}
-- Gildenfarben wie auf der Website: aus dem Sync-Import (theme.accent, Hex), sonst feste Vorgabe je Gilde.
local GUILD_THEMES={lichtloot={accent='facc15'},nachtloot={accent='2dd4bf'}}
local function hexColor(hex) hex=tostring(hex or ''):gsub('^#','');if #hex~=6 then return nil end;return {tonumber(hex:sub(1,2),16)/255,tonumber(hex:sub(3,4),16)/255,tonumber(hex:sub(5,6),16)/255} end
function GL.GuildTheme(guild)
    guild=guild or GL.db.selectedGuild
    local data=((GL.db.guildProfiles or {})[guild] or {}).activeRaids or {}
    local accent=hexColor(data.theme and (data.theme.accent or data.theme.accentColor)) or hexColor(GUILD_THEMES[guild] and GUILD_THEMES[guild].accent) or hexColor('facc15')
    return {accent=accent}
end
function GL.RaidIcon(key) key=tostring(key or ''):lower();if RAID_IMAGES[key] then return 'Interface\\AddOns\\GuildLootEra\\Media\\Raids\\'..key..'-icon' end;return 'Interface\\AddOns\\GuildLootEra\\Media\\GuildLootLogo' end
-- Raidbild (256x128) aus Media/Raids, sonst das GuildLoot-Logo.
function GL.RaidImage(key) key=tostring(key or ''):lower();if RAID_IMAGES[key] then return 'Interface\\AddOns\\GuildLootEra\\Media\\Raids\\'..key end;return 'Interface\\AddOns\\GuildLootEra\\Media\\GuildLootLogo' end
-- PrioPIN und Homepage im Raidchat posten (Raid, sonst Gruppe, sonst nur Chatfenster).
local weekdayNames={'So','Mo','Di','Mi','Do','Fr','Sa'}
function GL.PrioPinLines(info)
    local y,m,d=tostring(info.date or ''):match('^(%d+)%-(%d+)%-(%d+)$')
    local when=y and (weekdayNames[tonumber(date('%w',time({year=tonumber(y),month=tonumber(m),day=tonumber(d),hour=12})))+1]..' '..d..'.'..m..'.'..y) or tostring(info.date or '')
    return {
        'GuildLoot Raid: '..tostring(info.name or 'Raid')..' · '..when..(info.clock and info.clock~='' and (' '..info.clock..' Uhr') or '')..' · PrioPIN: '..tostring(info.pin or ''),
        'Prios eintragen: www.lichtloot.de → Random-Raid öffnen → PrioPIN eingeben, oder im GuildLoot-Addon unter Aktive Raids.',
    }
end
function GL.PostPrioPin(info)
    local lines=GL.PrioPinLines(info)
    local channel=IsInRaid() and 'RAID' or (IsInGroup and IsInGroup() and 'PARTY') or nil
    for _,line in ipairs(lines) do
        if channel then SendChatMessage(line:sub(1,255),channel) else print('|cff79e6c5GuildLoot:|r '..line) end
    end
    return channel
end
-- Random-Raids (RMD) ohne Gilde: nur P1–P3, keine P0-Regeln, keine Rekrutenfreigaben.
local RANDOM_RULES={recruit={enabled=false},levels={{key='p1',label='P1',enabled=true},{key='p2',label='P2',enabled=true},{key='p3',label='P3',enabled=true}},items={}}
-- opts.random=true: RMD-Bereich (Random-Raids aus der Random-Datenbank, unabhängig von der Gilde), sonst Gildenraids.
function GL.CreateActiveRaidsView(parent,opts)
    local feedbackText,openCreatorForLead -- je Ansicht (Gilde und RMD haben eigene Formulare und Ersteller)
    local random=opts~=nil and opts.random==true
    local view=CreateFrame('Frame',nil,parent);view:SetPoint('TOPLEFT',24,-162);view:SetSize(890,630)
    local page=1;local cards={};local openForm;local openDelete
    local function isRandomRow(r) return r.random==1 end
    -- Gelöschte (archivierte) Raids bis zum nächsten Sync ausblenden; bei fehlgeschlagener Quittung wieder zeigen.
    local function deletedLocally(id)
        local d=(GL.db.deletedRaids or {})[id];if not d then return false end
        local rc=d.requestId and (GL.db.outgoingReceipts or {})[d.requestId]
        if (rc and rc.state=='failed') or (GetServerTime()-(d.at or 0))>7*86400 then GL.db.deletedRaids[id]=nil;return false end
        return true
    end
    local function isRandomEntry(e) return e.mode=='prio' end
    local function sourceRows()
        local data=(GL.db.guildProfiles[GL.db.selectedGuild] or {}).activeRaids;local out={}
        for _,r in ipairs(data and data.rows or {}) do if isRandomRow(r)==random and not deletedLocally(r.id) then out[#out+1]=r end end
        return out
    end
    local function createdEntries()
        local out={}
        for _,e in ipairs(GL.db.createdRaids or {}) do if isRandomEntry(e)==random and (random or e.guild==GL.db.selectedGuild) then out[#out+1]=e end end
        return out
    end
    local function label(owner,x,y,w,size)
        local l=owner:CreateFontString(nil,'OVERLAY','GameFontHighlight');l:SetPoint('TOPLEFT',x,y);l:SetWidth(w);l:SetJustifyH('LEFT');l:SetFont(STANDARD_TEXT_FONT,size);l:SetTextColor(.72,.82,.88);return l
    end
    local heading=label(view,0,0,500,22);if random then heading:SetTextColor(.78,.62,1) else heading:SetTextColor(.15,.9,.8) end
    local context=label(view,0,-34,890,12)
    local function button(text,x,y,w,fn,owner)
        local b=CreateFrame('Button',nil,owner or view);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,24)
        local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.13,.23,.27,1);b.background=bg
        local l=label(b,8,-7,w-16,13);l:SetText(text);b.label=l;b:SetScript('OnClick',fn);if GL.GateSyncButton then GL.GateSyncButton(b,text) end;return b
    end
    button('Charakter wechseln',670,0,220,function() GL.CyclePersonalProfile();view:Refresh() end)
    local instructions=label(view,590,-78,300,13);instructions:SetText('Raid anklicken: Anmeldung und Prios')
    local countLabel=label(view,0,-78,570,13)
    -- Raidkacheln wie auf der Website: zwei Spalten, Gildenfarbe als Rahmen und Aktionsfarbe.
    local theme=random and {accent={.66,.5,.95}} or GL.GuildTheme()
    local function pill(owner,x,y,w) local f=CreateFrame('Frame',nil,owner);f:SetPoint('TOPLEFT',x,y);f:SetSize(w,18);f.bg=f:CreateTexture(nil,'BACKGROUND');f.bg:SetAllPoints();f.bg:SetColorTexture(.1,.17,.22,1);f.text=label(f,0,-4,w,10);f.text:SetJustifyH('CENTER');return f end
    for i=1,6 do
        local col,row=(i-1)%2,math.floor((i-1)/2)
        local card=CreateFrame('Frame',nil,view);card:SetPoint('TOPLEFT',col*452,-104-row*160);card:SetSize(438,150)
        local border=card:CreateTexture(nil,'BACKGROUND');border:SetPoint('TOPLEFT',-1,1);border:SetPoint('BOTTOMRIGHT',1,-1);border:SetColorTexture(theme.accent[1],theme.accent[2],theme.accent[3],.55);border:SetDrawLayer('BACKGROUND',-1)
        local bg=card:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.03,.06,.1,1)
        card.icon=card:CreateTexture(nil,'ARTWORK');card.icon:SetPoint('TOPLEFT',10,-10);card.icon:SetSize(48,48)
        card.title=label(card,68,-10,250,14);card.title:SetTextColor(1,1,1)
        card.when=label(card,68,-30,250,11);card.when:SetTextColor(.72,.82,.88)
        card.mine=pill(card,300,-12,128)
        card.kind=pill(card,10,-66,108);card.kind.text:SetTextColor(theme.accent[1],theme.accent[2],theme.accent[3])
        card.published=pill(card,124,-66,150)
        card.countValue=label(card,10,-90,80,16);card.countValue:SetTextColor(1,1,1);card.countLabel=label(card,10,-108,80,10);card.countLabel:SetTextColor(.6,.7,.78)
        card.pinValue=label(card,100,-90,90,16);card.pinValue:SetTextColor(theme.accent[1],theme.accent[2],theme.accent[3]);card.pinLabel=label(card,100,-108,90,10);card.pinLabel:SetTextColor(.6,.7,.78)
        card.pinButton=button('PIN posten',10,-122,96,function() local r=card.raid;if r and (r.prioPin or '')~='' then GL.PostPrioPin({raid=r.raid,name=r.name,date=r.date,clock=r.clock,pin=r.prioPin}) end end,card);card.pinButton:SetHeight(22);card.pinButton.label:SetFont(STANDARD_TEXT_FONT,11)
        card.delete=button('Löschen',112,-122,96,function() if card.raid and not card.raid.pending then openDelete(card.raid) end end,card);card.delete:SetHeight(22);card.delete.label:SetFont(STANDARD_TEXT_FONT,11);card.delete.background:SetColorTexture(.36,.12,.15,1)
        card.master=button('Plündermeister',218,-120,104,function() if card.raid then GL.ShowMasterList(card.raid.id) end end,card);card.master:SetHeight(24);card.master.label:SetFont(STANDARD_TEXT_FONT,11)
        card.open=button('Prio eintragen →',328,-120,102,function() if card.raid then openForm(card.raid) end end,card);card.open:SetHeight(24)
        card.open.background:SetColorTexture(theme.accent[1],theme.accent[2],theme.accent[3],1);card.open.label:SetTextColor(.05,.08,.12);card.open.label:SetFont(STANDARD_TEXT_FONT,11)
        card:EnableMouse(true);card:SetScript('OnMouseUp',function() if card.raid and not card.raid.pending then openForm(card.raid) end end)
        cards[i]=card
    end
    local empty=label(view,16,-135,850,15)
    local pages=label(view,365,-594,250,13)
    button('<',0,-586,64,function() page=math.max(1,page-1);view:Refresh() end)
    button('>',826,-586,64,function() page=page+1;view:Refresh() end)
    local hint=label(view,0,-56,890,11);hint:SetText(random and 'RMD Raid = Random-Raid ohne Gilde: PrioPIN an die Spieler, Lead-PIN nur für die Raidleitung. Absenden → /reload → Sync-App → /reload.' or 'Absenden → /reload → Sync-App überträgt → weiteres /reload übernimmt die Serverbestätigung.')
    function view:Refresh()
        local profile=GL.db.guildProfiles[GL.db.selectedGuild] or {};local data=profile.activeRaids;local rows={};local personal=GL.DisplayProfile()
        local source=sourceRows()
        -- Erstellte (oder per PIN geöffnete) Raids, die noch nicht im Sync-Import sind, als Platzhalter voranstellen
        local today=date('%Y-%m-%d')
        for _,e in ipairs(createdEntries()) do
            if tostring(e.date or '')>=today then
                local found=false
                for _,r in ipairs(source) do
                    if ((e.playerPin or '')~='' and r.prioPin==e.playerPin) or ((e.leadPin or '')~='' and r.leadPin==e.leadPin) or (e.serverId and r.id==e.serverId) or ((e.raid or '')~='' and r.raid==e.raid and r.date==e.date and (r.clock==e.clock or r.clock=='')) then
                        found=true;if (e.playerPin or '')=='' and (r.prioPin or '')~='' then e.playerPin=r.prioPin end;break
                    end
                end
                local rc=(GL.db.outgoingReceipts or {})[e.requestId or '']
                local queued=e.requestId~=nil and (GL.db.outgoingRequests or {})[e.requestId]~=nil
                -- Erfolgreich, aber ohne random-Kennung: von einer älteren Sync-Version als Gildenraid angelegt, gehört nicht in den RMD-Bereich.
                local staleGuildRaid=random and rc and rc.state=='success' and rc.random~=true and not e.joined
                -- Weder Auftrag noch Quittung mehr vorhanden (z. B. fehlgeschlagene Erstellung, Quittung bereits aufgeräumt): kein Platzhalter.
                local resolved=not e.joined and not queued and rc==nil
                if not found and not staleGuildRaid and not resolved and not (rc and rc.state=='failed') then
                    rows[#rows+1]={id='pending:'..tostring(e.requestId or e.playerPin or e.leadPin),name=e.joined and ('Random-Raid · '..((e.playerPin or '')~='' and ('PrioPIN '..e.playerPin) or 'Lead-PIN')) or (e.name..(e.mode=='prio' and (' · '..(e.group or 'Random')) or '')),date=e.date,clock=e.clock or '',raid=e.raid or '',kind=e.mode=='prio' and 'Prio-Raid' or (e.mode=='p0' and 'P0-Anmeldung' or 'Raid'),count=0,signup=0,prioPin=e.playerPin,pending=true,joined=e.joined==true,pendingState=rc and rc.state or 'wait'}
                end
            end
        end
        for _,r in ipairs(source) do rows[#rows+1]=r end
        heading:SetText(random and 'RMD Raids · ohne Gilde' or ('Aktive Raids · '..GL.GuildName(GL.db.selectedGuild)))
        context:SetText(data and ('Stand '..date('%d.%m.%Y %H:%M',data.exportedAt)..(personal and (' · Dein Charakter: '..personal.player..' – '..personal.realm) or '')..(random and ' · Random-Datenbank von lichtloot.de' or '')) or 'In GuildLoot Sync „Jetzt synchronisieren“ anklicken, danach /reload.')
        countLabel:SetText(random and (#rows..' RMD Raids · erstellt oder per PrioPIN geöffnet') or (#rows..' bevorstehende Raids der Gilde'))
        local max=math.max(1,math.ceil(#rows/6));page=math.min(page,max);pages:SetText('Seite '..page..' / '..max)
        empty:SetShown(#rows==0);empty:SetText(random and 'Noch keine RMD Raids. „+ RMD Raid erstellen“ oder „Per PrioPIN öffnen“ (GuildLoot Sync ab 0.3.20).' or (data and 'Keine bevorstehenden Raids im aktuellen Gildenexport.' or 'Noch keine Raidübersicht synchronisiert. Benötigt GuildLoot Sync ab 0.1.3.'))
        local weekdays={'So','Mo','Di','Mi','Do','Fr','Sa'}
        for i,card in ipairs(cards) do
            local r=rows[(page-1)*6+i];card:SetShown(r~=nil)
            if r then
                card.raid=r
                local year,month,day=r.date:match('^(%d+)%-(%d+)%-(%d+)$')
                local when=day and (weekdays[tonumber(date('%w',time({year=tonumber(year),month=tonumber(month),day=tonumber(day),hour=12})))+1]..' '..day..'.'..month..'.'..year) or r.date
                card.title:SetText(r.name);card.when:SetText(when..' · '..(r.clock~='' and (r.clock..' Uhr') or 'Zeit folgt'))
                local key=tostring(r.raid or ''):match('^(zg)') or r.raid;card.icon:SetTexture(GL.RaidIcon(key))
                local mine
                for _,event in ipairs(personal and personal.calendar or {}) do if event.id==r.id or event.id=='p0:'..r.id then mine=event;break end end
                if r.pending then card.mine.text:SetText(r.joined and 'Wird geladen · /reload' or (r.pendingState=='success' and 'Angelegt · nächster /reload' or 'Wird angelegt · /reload'));card.mine.text:SetTextColor(1,.8,.25)
                elseif r.random==1 then
                    local own=false;for _,row in ipairs(((data and data.lists or {})[r.id] or {}).rows or {}) do if personal and row.player==personal.player and row.realm==personal.realm then own=true end end
                    card.mine.text:SetText(own and 'Prio eingetragen ✓' or 'Keine Prio');card.mine.text:SetTextColor(own and .47 or .6,own and .9 or .7,own and .64 or .78)
                else card.mine.text:SetText(mine and (mine.hasPrio and 'Angemeldet · Prio ✓' or 'Angemeldet · Prio fehlt') or 'Nicht angemeldet')
                card.mine.text:SetTextColor(mine and (mine.hasPrio and .47 or 1) or .6,mine and (mine.hasPrio and .9 or .8) or .7,mine and (mine.hasPrio and .64 or .25) or .78) end
                card.open:SetShown(not r.pending);card.master:SetShown(not r.pending);card.delete:SetShown(not r.pending)
                -- Gildenraids löschen nur mit Gildenleitungszugang; RMD Raids mit Lead-PIN (bei eigenen automatisch)
                local canDelete=random or (GL.HasGuildMasterAccess and GL.HasGuildMasterAccess())
                card.delete:SetEnabled(canDelete);card.delete:SetAlpha(canDelete and 1 or .35)
                card.kind.text:SetText(r.kind or 'Raid')
                local list=data.lists and data.lists[r.id];local published=list and list.published==1
                card.published.text:SetText(r.pending and 'Noch nicht übertragen' or (published and 'Prioliste veröffentlicht' or 'Prioliste verborgen'));card.published.text:SetTextColor(published and .47 or .72,published and .9 or .82,published and .64 or .88)
                card.countValue:SetText(tostring(r.count or 0));card.countLabel:SetText(r.kind=='P0-Anmeldung' and 'P0-Einträge' or 'Angemeldet')
                local pin=(r.prioPin or '')~='' and r.prioPin or nil
                card.pinValue:SetText(pin or '—');card.pinLabel:SetText('PrioPIN');card.pinButton:SetShown(pin~=nil)
            end
        end
    end
    local form=CreateFrame('Frame',nil,view);form:SetAllPoints();form:EnableMouse(true)
    if form.SetFrameLevel and view.GetFrameLevel then form:SetFrameLevel(view:GetFrameLevel()+10) end
    local bg=form:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.025,.06,.09,1)
    local title=label(form,12,-8,730,20);if random then title:SetTextColor(.78,.62,1) else title:SetTextColor(.05,.9,.8) end
    local identity=label(form,44,-35,560,18)
    -- Charakter wechseln direkt im Prio-Formular (lädt eigene Prios und Auswahl des neuen Charakters)
    button('Charakter wechseln',620,-34,130,function() GL.CyclePersonalProfile();if selectedRaid then openForm(selectedRaid) end end,form)
    local classIcon=form:CreateTexture(nil,'ARTWORK');classIcon:SetPoint('TOPLEFT',12,-34);classIcon:SetSize(24,24)
    button('Schließen',756,-8,120,function() form:Hide() end,form)
    local selectedRaid,catalog,list,selected=nil,{},{},{}
    local leadMenu=CreateFrame('Frame',nil,form);leadMenu:SetPoint('TOPLEFT',560,-34);leadMenu:SetSize(316,206)
    if leadMenu.SetFrameLevel and form.GetFrameLevel then leadMenu:SetFrameLevel(form:GetFrameLevel()+40) end
    local lmbg=leadMenu:CreateTexture(nil,'BACKGROUND');lmbg:SetAllPoints();lmbg:SetColorTexture(.08,.18,.22,1)
    local leadActions={
        {'Prioliste der Raidleitung',function() GL.ShowMasterList(selectedRaid.id) end},
        {'Prio auf GuildLoot öffnen',function() GL.masterRaidId=selectedRaid.id;GL.ShowPublishDialog() end},
        {'Prio3 exportieren',function() GL.ShowPrio3Export(selectedRaid.id) end},
        {'PrioPIN im Raidchat posten',function() if (selectedRaid.prioPin or '')~='' then GL.PostPrioPin({raid=selectedRaid.raid,name=selectedRaid.name,date=selectedRaid.date,clock=selectedRaid.clock,pin=selectedRaid.prioPin}) else feedbackText('Für diesen Raid ist kein PrioPIN im Import enthalten (GuildLoot Sync ab 0.3.19).') end end},
        {'Prio für einen Spieler eintragen',function() openCreatorForLead(selectedRaid) end},
        {'Aufzeichnung (Plündermeister)',function() GL.masterRaidId=selectedRaid.id;GL.ShowMaster() end},
        {'Raid löschen (archivieren)',function() if not random and not (GL.HasGuildMasterAccess and GL.HasGuildMasterAccess()) then feedbackText('Löschen nur mit Gildenleitungs-PIN: einmal unter Plündermeister mit dem Gildenleitungs-PIN anmelden.');return end;form:Hide();openDelete(selectedRaid) end},
    }
    for i,a in ipairs(leadActions) do button(a[1],6,-6-(i-1)*28,304,function() leadMenu:Hide();if selectedRaid then a[2]() end end,leadMenu) end
    leadMenu:Hide()
    button('Raidleitung ▾',620,-8,130,function() leadMenu:SetShown(not leadMenu:IsShown()) end,form)
    local editingProfile
    local priorityRules,ownRules
    local function level(key)
        for _,v in ipairs(priorityRules and priorityRules.levels or {}) do if v.key==key then return v end end
        return {enabled=true,label=key:upper()}
    end
    local function allowed(key,item)
        if not selectedRaid or not priorityRules then return false end
        if selectedRaid.raid=="ony" and key~="p1" then return false end
        if key=="p0" or key=="plus" then
            for _,v in ipairs((priorityRules.items or {})[selectedRaid.raid] or {}) do if (not item or v.name==item.name) and v[key] then return true end end
            return false
        end
        return level(key).enabled~=false
    end
    local function selectionAllowed(key,item)
        if not allowed(key,item) then return false end
        local recruit=priorityRules and priorityRules.recruit
        if recruit and recruit.enabled then
            for _,raid in ipairs(recruit.raids or {}) do if raid==selectedRaid.raid then
                local released=ownRules and ownRules.recruitReleases and ownRules.recruitReleases[raid]
                if released~=true and key~='p0' then
                    for _,v in ipairs(recruit.allowedPriorities or {}) do if v==(key=='plus' and 'p0plus' or key) then return true end end
                    return false
                end
            end end
        end
        return true
    end
    local statusIndex,roleIndex,pickerPage,listPage=1,1,1,1
    local statuses={{'Angemeldet','signed'},{'Bank','bench'},{'Verspätet','late'},{'Vielleicht','tentative'},{'Abgemeldet','absent'}}
    local roles={{'Schaden','dd'},{'Heilung','heal'},{'Tank','tank'}}
    local feedback=label(form,12,-523,865,12);feedback:SetTextColor(1,.8,.3)
    function feedbackText(text) feedback:SetText(text) end
    local function queue(kind,payload)
        local p=GL.DisplayProfile();if not p or not editingProfile or p.player~=editingProfile.player or p.realm~=editingProfile.realm then feedback:SetText('Charakter gewechselt. Bitte den Raid erneut öffnen.');return end
        local ok,err=pcall(GL.QueueWebsiteAction,selectedRaid,kind,payload)
        feedback:SetText(ok and 'Vorgemerkt · /reload zum Senden · Serverbestätigung nach erneutem /reload.' or tostring(err))
    end
    local statusButton,roleButton
    statusButton=button('Angemeldet >',12,-64,200,function() statusIndex=statusIndex%#statuses+1;statusButton.label:SetText(statuses[statusIndex][1]..' >') end,form)
    roleButton=button('Schaden >',222,-64,175,function() roleIndex=roleIndex%#roles+1;roleButton.label:SetText(roles[roleIndex][1]..' >') end,form)
    local signup=button('Anmeldung absenden',407,-64,238,function() queue('signup',{status=statuses[statusIndex][2],role=roles[roleIndex][2]}) end,form)
    local pureHint=label(form,12,-66,620,13)
    local sheetButton=button('Raidsheet',650,-64,226,function() if selectedRaid then GL.ShowRaidSheet(selectedRaid.id) end end,form);sheetButton:SetShown(not random)
    local function edit(x,y,w)
        local e=CreateFrame('EditBox',nil,form,'InputBoxTemplate');e:SetPoint('TOPLEFT',x,y);e:SetSize(w,24);e:SetAutoFocus(false);e:SetFontObject('ChatFontNormal');return e
    end
    label(form,12,-94,420,17):SetText('Möglicher Loot')
    label(form,460,-94,410,17):SetText('Aktuelle Prioliste')
    local search=edit(18,-116,422);local rosterSearch=edit(466,-116,404)
    local selection=label(form,12,-143,430,11);local publication=label(form,460,-143,410,11)
    local picker,roster={},{};local pickerRefresh,rosterRefresh
    local rosterScroll,updatingRosterScroll
    local qualityNames={['Schlecht']=0,['Gewöhnlich']=1,['Normal']=1,['Ungewöhnlich']=2,['Selten']=3,['Episch']=4,['Legendär']=5}
    local fallbackColors={[0]={.62,.62,.62},[1]={1,1,1},[2]={.12,1,0},[3]={0,.44,.87},[4]={.64,.21,.93},[5]={1,.5,0}}
    local function decorate(b,item)
        b.item=item;b.itemId=item and tonumber(item.id) or nil
        if not item then b.label:SetText('');return end
        local name,link,quality,_,_,_,_,_,_,icon
        local get=GetItemInfo or (C_Item and C_Item.GetItemInfo)
        if get then name,link,quality,_,_,_,_,_,_,icon=get(item.id) end
        quality=quality or tonumber(item.quality) or qualityNames[item.quality]
        local color=quality and fallbackColors[quality] or {.72,.82,.88}
        b.label:SetText(name or item.name);b.label:SetTextColor(unpack(color))
        if b.icon then b.icon:SetTexture(icon or (item.icon and item.icon~='' and ('Interface\\Icons\\'..item.icon)) or 'Interface\\Icons\\INV_Misc_QuestionMark') end
    end
    local function tooltip(b)
        b:SetScript('OnEnter',function(self) if self.itemId and GameTooltip then GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetHyperlink('item:'..self.itemId);if self.item and self.item.rewards and self.item.rewards~='' then GameTooltip:AddLine('Questbelohnungen',1,.8,.3);for reward in self.item.rewards:gmatch('[^\n]+') do GameTooltip:AddLine(reward,.75,.5,1,true) end end;GameTooltip:Show() end end)
        b:SetScript('OnLeave',function() if GameTooltip then GameTooltip:Hide() end end)
    end
    local chosen={}
    local function selectedRefresh()
        for i,b in ipairs(chosen) do
            local key=({'p1','p2','p3','p0'})[i];local item=selected[key]
            b:SetShown(allowed(key) or (key=='p0' and allowed('plus')))
            decorate(b,item);if not item then b.label:SetText((i==4 and 'P0 / P0+' or level('p'..i).label)..': nicht gewählt') else b.label:SetText((i==4 and (selected.plus and 'P0+: ' or 'P0: ') or level('p'..i).label..': ')..b.label:GetText()) end
        end
    end
    for i=1,4 do
        local key=({'p1','p2','p3','p0'})[i]
        local b=button('',12+(i-1)*218,-460,212,function() selected[key]=nil;selectedRefresh();pickerRefresh() end,form);tooltip(b);chosen[i]=b
    end
    for i=1,8 do
        local b=button('',12,-158-(i-1)*34,430,function() end,form);b:SetSize(430,32)
        b.label:SetPoint('TOPLEFT',32,-5);b.label:SetWidth(200);b.label:SetHeight(26);b.label:SetFont(STANDARD_TEXT_FONT,12)
        b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',4,-4);b.icon:SetSize(24,24);tooltip(b)
        b.prios={}
        for j,key in ipairs({'p1','p2','p3','p0','plus'}) do
            local pbutton=button(({p1='P1',p2='P2',p3='P3',p0='P0',plus='P0+'})[key],236+(j-1)*38,0,36,function()
                if not b.item or not selectionAllowed(key,b.item) then return end
                if key=='p0' or key=='plus' then selected.p0=b.item;selected.plus=key=='plus';selected.p1=nil;selected.p2=nil;selected.p3=nil
                else selected.p0=nil;selected.plus=nil;selected[key]=b.item end
                selectedRefresh();pickerRefresh()
            end,b);pbutton:SetSize(34,32);pbutton.label:SetFont(STANDARD_TEXT_FONT,10);pbutton.label:SetPoint('TOPLEFT',3,-10);pbutton.label:SetWidth(32);b.prios[key]=pbutton
        end
        picker[i]=b
    end
    local function searchKey(text)
        text=tostring(text or ''):gsub('Ä','a'):gsub('Ö','o'):gsub('Ü','u'):gsub('ä','a'):gsub('ö','o'):gsub('ü','u'):gsub('ß','ss'):lower()
        return text:gsub('[^a-z0-9]+',' ')
    end
    pickerRefresh=function()
        local filtered={};local term=searchKey(search:GetText())
        for _,item in ipairs(catalog) do
            local haystack=item.search or searchKey(item.name..' '..tostring(item.id)..' '..(item.slot or '')..' '..(item.boss or ''))
            local matches=true;for word in term:gmatch('%S+') do if not haystack:find(word,1,true) then matches=false;break end end
            if matches then filtered[#filtered+1]=item end
        end
        local function rank(item)
            for index,key in ipairs({'p1','p2','p3','p0'}) do if selected[key] and selected[key].id==item.id then return index end end
            return 5
        end
        table.sort(filtered,function(a,b) local ar,br=rank(a),rank(b);if ar~=br then return ar<br end;return a.name<b.name end)
        pickerPage=math.min(pickerPage,math.max(1,math.ceil(#filtered/8)))
        selection:SetText('Item, Token, Quest, Klasse oder Boss · '..#filtered..' Items · Seite '..pickerPage)
        for i,b in ipairs(picker) do
            local item=filtered[(pickerPage-1)*8+i];b:SetShown(item~=nil)
            if item then
                decorate(b,item)
                local position=0
                for _,key in ipairs({'p1','p2','p3','p0','plus'}) do local p=b.prios[key]
                    local show=selectionAllowed(key,item);p:SetShown(show)
                    if show then p:ClearAllPoints();p:SetPoint('TOPLEFT',236+position*38,0);position=position+1 end
                    p.label:SetText((key=='p0' and 'P0') or (key=='plus' and 'P0+') or level(key).label)
                    local chosenItem=selected[key=='plus' and 'p0' or key]
                    local active=chosenItem and chosenItem.id==item.id and (key~='plus' or selected.plus) and (key~='p0' or not selected.plus)
                    p.background:SetColorTexture(active and .68 or .045,active and .48 or .12,active and .08 or .16,1)
                    p.label:SetTextColor(active and 1 or .72,active and .9 or .82,active and .45 or .88)
                end
            end
        end
    end
    local classes={Krieger='WARRIOR',Druide='DRUID',Schurke='ROGUE',Magier='MAGE',Priester='PRIEST',Paladin='PALADIN',['Jäger']='HUNTER',Hexenmeister='WARLOCK',Schamane='SHAMAN'}
    for i=1,8 do
        local row=CreateFrame('Frame',nil,form);row:SetPoint('TOPLEFT',460,-158-(i-1)*34);row:SetSize(410,34)
        local background=row:CreateTexture(nil,'BACKGROUND');background:SetAllPoints();background:SetColorTexture(.065,.12,.17,1)
        row.number=label(row,3,-3,25,11);row.number:SetTextColor(.6,.7,.78)
        row.name=label(row,30,-3,375,12);row.cells={}
        for j=1,4 do local b=button('',(j-1)*101,-16,100,function() end,row);b:SetSize(100,18);b.label:SetPoint('TOPLEFT',4,-2);b.label:SetFont(STANDARD_TEXT_FONT,10);b.label:SetHeight(16);b.label:SetWordWrap(false);tooltip(b);row.cells[j]=b end
        roster[i]=row
    end
    local function lookup(id,name)
        for _,item in ipairs(catalog) do if (id and id>0 and item.id==id) or (name~='' and item.name==name) then return item end end
        if id and id>0 then return {id=id,name=name} end
    end
    rosterRefresh=function()
        local rows={};local term=(rosterSearch:GetText() or ''):lower()
        for _,r in ipairs(list.rows or {}) do if (r.player..' '..r.realm..' '..r.className):lower():find(term,1,true) then rows[#rows+1]=r end end
        table.sort(rows,function(a,b)
            local ac,bc=classes[a.className] or a.className or '',classes[b.className] or b.className or ''
            if ac~=bc then return ac<bc end
            return (a.player..a.realm)<(b.player..b.realm)
        end)
        listPage=math.max(1,math.min(listPage,math.max(1,#rows-7)))
        if rosterScroll then updatingRosterScroll=true;rosterScroll:SetMinMaxValues(1,math.max(1,#rows-7));rosterScroll:SetValue(listPage);rosterScroll:SetShown(#rows>8);updatingRosterScroll=false end
        publication:SetText((list.published==1 and 'Veröffentlicht' or 'Prios verborgen · P0-Auswahl sichtbar')..' · '..#rows..' Spieler')
        for i,row in ipairs(roster) do
            local r=rows[listPage-1+i];row:SetShown(r~=nil)
            if r then
                row.number:SetText(tostring(listPage-1+i)..'.');row.name:SetText(r.player..' · '..r.realm)
                local color=RAID_CLASS_COLORS and RAID_CLASS_COLORS[classes[r.className] or r.className];row.name:SetTextColor(color and color.r or .72,color and color.g or .82,color and color.b or .88)
                for j,b in ipairs(row.cells) do
                    b:SetShown(j==4 and (allowed('p0') or allowed('plus')) or (j<4 and allowed('p'..j)))
                    local key=j==4 and 'p0' or 'p'..j;local name=r[key] or '';local visible=j==4 or list.published==1 or r.own==true
                    local item=visible and lookup(r[key..'Id'],name)
                    decorate(b,item)
                    if not item then b.label:SetText((j==4 and (r.p0Plus==1 and 'P0+ ' or 'P0 ') or level('p'..j).label..' ')..(name~='' and (visible and name or 'gesetzt') or '—')) end
                end
            end
        end
    end
    search:SetScript('OnTextChanged',function() pickerPage=1;pickerRefresh() end)
    rosterSearch:SetScript('OnTextChanged',function() listPage=1;rosterRefresh() end)
    button('<',12,-432,48,function() pickerPage=math.max(1,pickerPage-1);pickerRefresh() end,form):SetSize(48,20)
    button('>',394,-432,48,function() pickerPage=pickerPage+1;pickerRefresh() end,form):SetSize(48,20)
    local function scrollRoster(_,delta)
        listPage=math.max(1,listPage+(delta<0 and 1 or -1));rosterRefresh()
    end
    -- Catch the wheel over rows and item buttons, including empty list space.
    local rosterArea=CreateFrame('Frame',nil,form);rosterArea:SetPoint('TOPLEFT',460,-158);rosterArea:SetSize(410,272)
    if rosterArea.SetFrameLevel and form.GetFrameLevel then rosterArea:SetFrameLevel(form:GetFrameLevel()) end
    rosterArea:EnableMouseWheel(true);rosterArea:SetScript('OnMouseWheel',scrollRoster)
    for _,row in ipairs(roster) do
        row:EnableMouseWheel(true);row:SetScript('OnMouseWheel',scrollRoster)
        for _,cell in ipairs(row.cells) do cell:EnableMouseWheel(true);cell:SetScript('OnMouseWheel',scrollRoster) end
    end
    rosterScroll=CreateFrame('Slider',nil,form);rosterScroll:SetPoint('TOPLEFT',874,-158);rosterScroll:SetSize(12,268);rosterScroll:SetOrientation('VERTICAL');rosterScroll:SetValueStep(1)
    local track=rosterScroll:CreateTexture(nil,'BACKGROUND');track:SetAllPoints();track:SetColorTexture(.06,.09,.12,1)
    local thumb=rosterScroll:CreateTexture(nil,'OVERLAY');thumb:SetSize(12,28);thumb:SetColorTexture(.55,.65,.72,1);rosterScroll:SetThumbTexture(thumb)
    rosterScroll:SetScript('OnValueChanged',function(_,value) if not updatingRosterScroll then listPage=math.floor(value+.5);rosterRefresh() end end)
    rosterScroll:EnableMouseWheel(true);rosterScroll:SetScript('OnMouseWheel',scrollRoster)
    label(form,460,-435,410,11):SetText('Mausrad: Prioliste scrollen')
    button('Prios absenden',12,-494,430,function()
        for key,item in pairs(selected) do if key~='plus' and item and not selectionAllowed(key=='p0' and selected.plus and 'plus' or key,item) then feedback:SetText('Diese Auswahl ist nicht mehr freigegeben. Bitte neu auswählen.');return end end
        local mode=selected.p0 and (selected.plus and 'p0plus' or 'p0') or 'normal'
        local first=selected.p0 or selected.p1 or selected.p2 or selected.p3
        if not first then feedback:SetText('Bitte eine verfügbare Priorität auswählen.');return end
        queue('prio',{mode=mode,p1=selected.p0 and selected.p0.id or (selected.p1 and selected.p1.id or 0),p2=selected.p2 and selected.p2.id or 0,p3=selected.p3 and selected.p3.id or 0})
    end,form)
    label(form,460,-494,410,11):SetText('Ausgewähltes Item anklicken: entfernen.\nFreigaben und Fristen prüft die Website beim Absenden.')
    label(form,12,-544,865,11):SetText('Item-Tooltip: Maus über das Item · Datenabruf alle 30 Sekunden bei geöffneter Sync-App · /reload lädt den neuen Stand.')
    openForm=function(raid)
        selectedRaid=raid;local p=GL.DisplayProfile();local profile=GL.db.guildProfiles[GL.db.selectedGuild] or {};local data=profile.activeRaids or {}
        priorityRules=random and RANDOM_RULES or data.priorityRules
        catalog=data.catalogs and data.catalogs[raid.raid] or {};list=data.lists and data.lists[raid.id] or {};selected={}
        title:SetText(raid.name..' · '..raid.date..' '..raid.clock)
        editingProfile=p
        local own
        for _,record in ipairs(data.ownPrios or {}) do if p and record.player==p.player and record.realm==p.realm then own=record;break end end
        ownRules=own
        local class=own and own.className
        local entries={};local ownRow
        for _,row in ipairs(list.rows or {}) do
            local copy={};for k,v in pairs(row) do copy[k]=v end
            if p and row.player==p.player and row.realm==p.realm then class=class or row.className;ownRow=copy end
            entries[#entries+1]=copy
        end
        local saved
        for _,row in ipairs(own and own.rows or {}) do if row.raidId==raid.id or row.externalRaidId==raid.id then saved=row;break end end
        if saved then
            if not ownRow then ownRow={player=p.player,realm=p.realm,className=class or ''};entries[#entries+1]=ownRow end
            for _,key in ipairs({'p1','p2','p3','p0','p0Plus'}) do ownRow[key]=saved[key] end
            ownRow.own=true
        end
        list={published=list.published,rows=entries}
        if ownRow then
            for _,key in ipairs({'p1','p2','p3','p0'}) do
                if (allowed(key) or (key=='p0' and allowed('plus'))) and (key=='p0' or saved or list.published==1) then selected[key]=lookup(ownRow[key..'Id'],ownRow[key] or '') end
            end
            selected.plus=ownRow.p0Plus==1
            -- P0 submissions also carry duplicate P1–P3 values on the website.
            if selected.p0 then selected.p1=nil;selected.p2=nil;selected.p3=nil end
        end
        local token=classes[class] or class
        if not token and p and UnitName and UnitName('player')==p.player and UnitClass then local _,current=UnitClass('player');token=current end
        local color=RAID_CLASS_COLORS and RAID_CLASS_COLORS[token]
        identity:SetText(p and (p.player..' – '..p.realm..' · '..(random and 'Random-Raid ohne Gilde' or GL.GuildName(GL.db.selectedGuild))) or 'Bitte zuerst einen Charakter synchronisieren')
        identity:SetTextColor(color and color.r or .8,color and color.g or .85,color and color.b or .9)
        classIcon:SetTexture(token and ('Interface\\Icons\\ClassIcon_'..token) or 'Interface\\Icons\\INV_Misc_QuestionMark')
        statusIndex=1;roleIndex=1;pickerPage=1;listPage=1
        statusButton.label:SetText('Angemeldet >');roleButton.label:SetText('Schaden >')
        statusButton:SetShown(raid.signup==1);roleButton:SetShown(raid.signup==1);signup:SetShown(raid.signup==1);signup:SetEnabled(p~=nil)
        pureHint:SetShown(raid.signup~=1);pureHint:SetText(random and 'Prio-Anmeldung · Auswahl direkt am Item · gespeichert in der Random-Datenbank (PrioPIN '..tostring(raid.prioPin or '')..').' or 'Prio-Anmeldung · Auswahl direkt am Item. Ohne Rolle und Teilnahmestatus.')
        feedback:SetText(priorityRules and GL.WebsiteActionStatus(raid.id) or 'Gildenregeln fehlen: GuildLoot Sync aktualisieren, synchronisieren und /reload eingeben.');search:SetText('');rosterSearch:SetText('');selectedRefresh();pickerRefresh();rosterRefresh();leadMenu:Hide();form:Show()
    end
    form:RegisterEvent('GET_ITEM_INFO_RECEIVED');form:SetScript('OnEvent',function() if form:IsShown() and view:IsShown() then pickerRefresh();rosterRefresh();selectedRefresh() end end)
    form:Hide();leadMenu:Hide();view:SetScript('OnHide',function() form:Hide();leadMenu:Hide();search:ClearFocus();rosterSearch:ClearFocus();if GameTooltip then GameTooltip:Hide() end end)
    view:EnableMouseWheel(true);view:SetScript('OnMouseWheel',function(_,delta) if form:IsShown() then pickerPage=math.max(1,pickerPage+(delta<0 and 1 or -1));pickerRefresh() else page=math.max(1,page+(delta<0 and 1 or -1));view:Refresh() end end)
    -- Raid erstellen: Schritte, Instanz- und Anmeldeart-Knöpfe, Vorschau, Prio für einen Spieler (Raidleitung).
    local creator=CreateFrame('Frame',nil,view);creator:SetAllPoints();creator:EnableMouse(true)
    if creator.SetFrameLevel and view.GetFrameLevel then creator:SetFrameLevel(view:GetFrameLevel()+20) end
    local cbg=creator:CreateTexture(nil,'BACKGROUND');cbg:SetAllPoints();cbg:SetColorTexture(.025,.06,.09,1)
    local function panel(x,y,w,h,titleText)
        local f=CreateFrame('Frame',nil,creator);f:SetPoint('TOPLEFT',x,y);f:SetSize(w,h)
        if f.SetFrameLevel and creator.GetFrameLevel then f:SetFrameLevel(creator:GetFrameLevel()+1) end
        local bg=f:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.045,.1,.13,1)
        local line=f:CreateTexture(nil,'ARTWORK');line:SetPoint('TOPLEFT',0,-28);line:SetPoint('TOPRIGHT',0,-28);line:SetHeight(1);line:SetColorTexture(.12,.23,.27,1)
        f.title=label(f,10,-8,w-20,13);f.title:SetText(titleText);f.title:SetTextColor(.95,.77,.3);return f
    end
    local creatorTitle=label(creator,16,-10,600,20);if random then creatorTitle:SetTextColor(.78,.62,1) else creatorTitle:SetTextColor(.05,.9,.8) end
    local createContext=label(creator,16,-34,600,12)
    button('Schließen',756,-8,120,function() creator:Hide() end,creator)
    local steps={}
    local stepX=16
    for i,text in ipairs({'1 Raid','2 Termin','3 Discord','4 Prüfen & absenden'}) do
        local w=({100,104,128,160})[i]
        local b=button(text,stepX,-54,w,function() end,creator);b:SetHeight(22);steps[i]=b;stepX=stepX+w+8
    end
    local left=panel(16,-84,440,372,'Schritt 1 · Raid und Art')
    local right=panel(472,-84,402,160,'Vorschau')
    local lead=panel(472,-254,402,236,'Prio für einen Spieler eintragen · Raidleitung')
    local createFeedback=label(creator,16,-500,860,12);createFeedback:SetTextColor(1,.8,.3)
    local draft={raid='mc',mode='raid',template='',channel=''};local options={};local copyBox;local createdSelected
    local function pinCode(n) local chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';local out={};for i=1,n do local k=math.random(1,#chars);out[i]=chars:sub(k,k) end;return table.concat(out) end
    local types={{id='mc',title='Geschmolzener Kern',short='MC'},{id='bwl',title='Pechschwingenhort',short='BWL'},{id='aq40',title="Ahn’Qiraj 40",short='AQ40'},{id='naxx',title='Naxxramas',short='Naxx'},{id='ony',title='Onyxia',short='Ony'},{id='zg',title="Zul’Gurub",short='ZG'},{id='aq20',title="Ahn’Qiraj 20",short='AQ20'}}
    local function typeOf(id) for _,t in ipairs(types) do if t.id==id then return t end end;return types[1] end
    -- Auswahlliste mit Suche (Vorlagen, Channels, Raids, Items)
    local popup=CreateFrame('Frame',nil,creator);popup:SetPoint('TOPLEFT',472,-84);popup:SetSize(402,406)
    if popup.SetFrameLevel and creator.GetFrameLevel then popup:SetFrameLevel(creator:GetFrameLevel()+30) end
    local popbg=popup:CreateTexture(nil,'BACKGROUND');popbg:SetAllPoints();popbg:SetColorTexture(.08,.18,.22,1)
    local popupTitle=label(popup,10,-8,300,13);popupTitle:SetTextColor(.95,.77,.3)
    button('×',362,-6,32,function() popup:Hide() end,popup)
    local popupSearch=CreateFrame('EditBox',nil,popup,'InputBoxTemplate');popupSearch:SetPoint('TOPLEFT',14,-30);popupSearch:SetSize(376,22);popupSearch:SetAutoFocus(false);popupSearch:SetFontObject('ChatFontNormal')
    local popupEmpty=label(popup,12,-62,378,13)
    local poprows={};local popupItems={};local popupCallback;local popPage=1;local popupSource={}
    local function paintPopup()
        local term=searchKey(popupSearch:GetText());popupItems={}
        for _,item in ipairs(popupSource) do
            local hay=item.search or searchKey((item.title or item.name or '')..' '..tostring(item.id or ''))
            local ok=true;for word in term:gmatch('%S+') do if not hay:find(word,1,true) then ok=false;break end end
            if ok then popupItems[#popupItems+1]=item end
        end
        popupEmpty:SetShown(#popupItems==0);popupEmpty:SetText(#popupSource==0 and 'Keine Einträge im Import. Bitte synchronisieren und /reload eingeben.' or 'Kein Treffer.')
        popPage=math.min(popPage,math.max(1,math.ceil(#popupItems/9)))
        for i,b in ipairs(poprows) do local item=popupItems[(popPage-1)*9+i];b.item=item;b:SetShown(item~=nil);if item then b.label:SetText(item.title or item.name or item.id);b:SetEnabled(not item.header);b.label:SetTextColor(item.header and 1 or .72,item.header and .8 or .82,item.header and .3 or .88) end end
        popup.pages:SetText(#popupItems..' Einträge · Seite '..popPage..' / '..math.max(1,math.ceil(#popupItems/9)))
    end
    for i=1,9 do local b;b=button('',8,-60-(i-1)*30,386,function() if b.item and not b.item.header then popupCallback(b.item);popup:Hide() end end,popup);b:SetHeight(28);poprows[i]=b end
    button('<',8,-336,58,function() popPage=math.max(1,popPage-1);paintPopup() end,popup);button('>',336,-336,58,function() popPage=popPage+1;paintPopup() end,popup)
    popup.pages=label(popup,74,-341,256,11)
    popupSearch:SetScript('OnTextChanged',function() popPage=1;paintPopup() end);popupSearch:SetScript('OnEscapePressed',function() popup:Hide() end)
    popup:EnableMouseWheel(true);popup:SetScript('OnMouseWheel',function(_,delta) popPage=math.max(1,popPage+(delta<0 and 1 or -1));paintPopup() end)
    local function choose(titleText,items,callback)
        popupTitle:SetText(titleText);popupSource=items;popupCallback=callback;popPage=1;popupSearch:SetText('');paintPopup();popup:Show();if #items>9 then popupSearch:SetFocus() end
    end
    -- Linke Seite
    local instanceButtons={}
    label(left,10,-38,200,11):SetText('Instanz')
    for i,t in ipairs(types) do
        local b=button(t.short,10+(i-1)*61,-54,58,function() draft.raid=t.id;draft.template='';creator:Refresh() end,left);b:SetHeight(24);instanceButtons[i]=b
    end
    local modeLabel=label(left,10,-88,200,11);modeLabel:SetText('Anmeldeart')
    local modeButtons={}
    -- Gildenraids: voller Raid oder P0-Anmelder. RMD-Bereich: nur Prio-Raid (Random-Datenbank), daher keine Auswahl.
    local modes=random and {{'prio','Prio-Raid (RMD) · ohne Gilde'}} or {{'raid','Voller Raid'},{'p0','P0-Anmelder'}}
    for i,m in ipairs(modes) do
        local b=button(m[2],10+(i-1)*143,-104,random and 300 or 140,function() draft.mode=m[1];creator:Refresh() end,left);b:SetHeight(24);modeButtons[i]=b
    end
    local templateLabel=label(left,10,-138,300,11);templateLabel:SetText('Raidvorlage · nur beim vollständigen Raid')
    local groupLabel=label(left,10,-138,300,11);groupLabel:SetText('Gruppe · erscheint auf lichtloot.de beim Random-Raid')
    local groupEdit=CreateFrame('EditBox',nil,left,'InputBoxTemplate');groupEdit:SetPoint('TOPLEFT',16,-154);groupEdit:SetSize(414,24);groupEdit:SetAutoFocus(false);groupEdit:SetFontObject('ChatFontNormal');groupEdit:SetMaxLetters(60)
    local templateButton=button('Vorlage auswählen …',10,-154,420,function()
        local rows={};for _,t in ipairs(options.templates or {}) do if t.raid==draft.raid then rows[#rows+1]=t end end
        choose('Raidvorlage · '..typeOf(draft.raid).title,rows,function(item) draft.template=item.id;creator:Refresh() end)
    end,left)
    label(left,10,-188,200,11):SetText('Datum · JJJJ-MM-TT');label(left,190,-188,120,11):SetText('Uhrzeit · HH:MM')
    local function creatorEdit(owner,x,y,w)
        local e=CreateFrame('EditBox',nil,owner,'InputBoxTemplate');e:SetPoint('TOPLEFT',x,y);e:SetSize(w,24);e:SetAutoFocus(false);e:SetFontObject('ChatFontNormal');return e
    end
    local createDate=creatorEdit(left,16,-204,160);local createTime=creatorEdit(left,196,-204,70)
    button('Heute',276,-205,70,function() createDate:SetText(date('%Y-%m-%d'));creator:Refresh() end,left)
    button('+7 Tage',352,-205,78,function() local y,m,d=createDate:GetText():match('^(%d+)%-(%d+)%-(%d+)$');local base=y and time({year=tonumber(y),month=tonumber(m),day=tonumber(d),hour=12}) or time();createDate:SetText(date('%Y-%m-%d',base+7*86400));creator:Refresh() end,left)
    createDate:SetScript('OnTextChanged',function() creator:Refresh() end);createTime:SetScript('OnTextChanged',function() creator:Refresh() end)
    local channelLabel=label(left,10,-240,200,11);channelLabel:SetText('Discord-Channel')
    local channelButton=button('Channel auswählen …',10,-256,420,function() choose('Discord-Channel',options.channels or {},function(item) draft.channel=item.id;creator:Refresh() end) end,left)
    local createButton=button('Raid erstellen und absenden',10,-300,300,function()
        local d,t=createDate:GetText(),createTime:GetText()
        if not d:match('^%d%d%d%d%-%d%d%-%d%d$') or not t:match('^%d%d:%d%d$') then createFeedback:SetText('Bitte Datum und Uhrzeit im angegebenen Format eingeben.');return end
        if draft.mode~='prio' and (draft.channel=='' or (draft.mode=='raid' and draft.template=='')) then createFeedback:SetText('Bitte Channel und bei vollständigem Raid eine passende Vorlage auswählen.');return end
        local playerPin,leadPin=pinCode(3),pinCode(4)
        local group=draft.mode=='prio' and ((groupEdit:GetText() or ''):gsub('^%s+',''):gsub('%s+$','')) or nil
        local ok,err=pcall(GL.QueueWebsiteAction,{id='create'},'create',{raid=draft.raid,mode=draft.mode,template=draft.mode=='raid' and draft.template or '',channel=draft.mode=='prio' and '' or draft.channel,date=d,clock=t,group=group,playerPin=playerPin,leadPin=leadPin})
        if ok then
            GL.db.createdRaids=GL.db.createdRaids or {}
            local entry={requestId=err,at=GetServerTime(),guild=GL.db.selectedGuild,raid=draft.raid,name=typeOf(draft.raid).title,date=d,clock=t,group=(group and group~='') and group or 'Random',mode=draft.mode,playerPin=playerPin,leadPin=leadPin,random=draft.mode=='prio'}
            table.insert(GL.db.createdRaids,1,entry);while #GL.db.createdRaids>20 do table.remove(GL.db.createdRaids) end
            createdSelected=entry
        end
        creator:Refresh()
        createFeedback:SetText(ok and 'Erstellung vorgemerkt. /reload zum Senden. Ergebnis anschließend in GuildLoot Sync prüfen.' or tostring(err))
    end,left);createButton:SetHeight(30)
    button('Abbrechen',316,-300,114,function() creator:Hide() end,left):SetHeight(30)
    label(left,10,-340,420,11):SetText('Nach /reload überträgt die geöffnete Sync-App. Ein weiteres /reload lädt den erstellten Raid.')
    local function createdInfo(e) return {raid=e.raid,name=e.name,date=e.date,clock=e.clock,pin=e.playerPin,leadPin=e.leadPin,group=e.group} end
    local createdList=button('Erstellte Raids …',300,-6,92,function()
        local rows={{id='preview',title='Vorschau der Eingabe'}}
        for _,e in ipairs(createdEntries()) do if not e.joined then rows[#rows+1]={id=e,title=e.name..' · '..e.date..' '..(e.clock or '')..' · PIN '..e.playerPin} end end
        choose('Erstellte Raids',rows,function(item) createdSelected=item.id~='preview' and item.id or nil;creator:Refresh() end)
    end,right);createdList:SetHeight(20)
    local pinLine=label(right,10,-58,382,13);pinLine:SetTextColor(.95,.77,.3)
    local pinStatus=label(right,10,-76,382,11);pinStatus:SetHeight(14);pinStatus:SetWordWrap(false)
    local postCreated=button('PIN posten',10,-98,90,function() if createdSelected then GL.PostPrioPin(createdInfo(createdSelected)) end end,right)
    local whisperTo=creatorEdit(right,112,-98,120)
    local whisperButton=button('Flüstern',238,-98,70,function()
        local name=(whisperTo:GetText() or ''):gsub('^%s+',''):gsub('%s+$','')
        if createdSelected and name~='' then for _,line in ipairs(GL.PrioPinLines(createdInfo(createdSelected))) do SendChatMessage(line:sub(1,255),'WHISPER',nil,name) end;createFeedback:SetText('PrioPIN an '..name..' geflüstert.') else createFeedback:SetText('Bitte einen Spielernamen zum Flüstern eingeben.') end
    end,right)
    local copyButton=button('Text',314,-98,78,function() if createdSelected then popup:Hide();copyBox:Open(createdSelected) end end,right)
    local pinHint=label(right,10,-126,382,10);pinHint:SetHeight(26);pinHint:SetText('PrioPIN an die Spieler: posten, flüstern oder als Text kopieren.\nLead-PIN nur an die Raidleitung.')
    -- Kopierbarer Text (Strg+C) für Discord
    copyBox=CreateFrame('Frame',nil,creator);copyBox:SetPoint('TOPLEFT',472,-84);copyBox:SetSize(402,406)
    if copyBox.SetFrameLevel and creator.GetFrameLevel then copyBox:SetFrameLevel(creator:GetFrameLevel()+30) end
    local cpbg=copyBox:CreateTexture(nil,'BACKGROUND');cpbg:SetAllPoints();cpbg:SetColorTexture(.08,.18,.22,1)
    label(copyBox,10,-8,300,13):SetText('Text für Discord · Strg+A, Strg+C');button('×',362,-6,32,function() copyBox:Hide() end,copyBox)
    local copyEdit=CreateFrame('EditBox',nil,copyBox);copyEdit:SetPoint('TOPLEFT',12,-32);copyEdit:SetSize(378,300);copyEdit:SetMultiLine(true);copyEdit:SetAutoFocus(false);copyEdit:SetFontObject('ChatFontNormal');copyEdit:SetMaxLetters(0)
    copyEdit:SetScript('OnEscapePressed',function() copyBox:Hide() end)
    function copyBox:Open(e)
        local info=createdInfo(e);local lines=GL.PrioPinLines(info)
        local y,m,d=tostring(e.date):match('^(%d+)%-(%d+)%-(%d+)$');local when=y and (d..'.'..m..'.'..y) or e.date
        copyEdit:SetText('GuildLoot Random Raid: '..e.name..'\nGruppe: '..(e.group or 'Random')..'\nTermin: '..when..' um '..(e.clock or '')..' Uhr\nPrioPIN: '..e.playerPin..'\nPrios eintragen: https://www.lichtloot.de → Random-Raid öffnen → PrioPIN eingeben\n\n--- nur Raidleitung ---\nLead-PIN: '..e.leadPin..'\nRaid verwalten: https://www.lichtloot.de/raidlead-panel.html?guild='..(e.guild or '')..'&leadPin='..e.leadPin..'&random=1')
        self:Show();copyEdit:SetFocus();copyEdit:HighlightText()
    end
    copyBox:Hide()
    -- Vorschau
    local previewName=label(right,10,-38,380,15);previewName:SetTextColor(.95,.77,.3)
    local previewLines=label(right,10,-60,382,12);previewLines:SetHeight(84)
    -- Prio für einen Spieler (Raidleitung)
    local leadDraft={raid=nil,player='',server='',className='',p1=nil,p2=nil,p3=nil,p0Plus=false}
    local postSelected=button('PIN posten',300,-36,92,function() local r=leadDraft.raid;if r and (r.prioPin or '')~='' then GL.PostPrioPin({raid=r.raid,name=r.name,date=r.date,clock=r.clock,pin=r.prioPin}) else createFeedback:SetText('Für diesen Raid ist kein PrioPIN im Import enthalten (GuildLoot Sync ab 0.3.19 synchronisieren).') end end,lead)
    local leadRaidButton=button('Raid auswählen …',10,-36,286,function()
        local rows={};for _,r in ipairs(sourceRows()) do rows[#rows+1]={id=r.id,title=r.name..' · '..r.date..(r.clock~='' and (' '..r.clock) or ''),raid=r} end
        choose('Raid für die Prio',rows,function(item) leadDraft.raid=item.raid;leadDraft.p1=nil;leadDraft.p2=nil;leadDraft.p3=nil;creator:Refresh() end)
    end,lead)
    local leadPlayer=creatorEdit(lead,16,-62,150);local leadServer=creatorEdit(lead,172,-62,120)
    local classNames={'Krieger','Paladin','Jäger','Schurke','Priester','Schamane','Magier','Hexenmeister','Druide'}
    local leadClass=button('Klasse …',298,-62,94,function()
        local rows={};for _,c in ipairs(classNames) do rows[#rows+1]={id=c,title=c} end
        choose('Klasse',rows,function(item) leadDraft.className=item.id;creator:Refresh() end)
    end,lead)
    leadPlayer:SetScript('OnTextChanged',function(self) leadDraft.player=self:GetText() end);leadServer:SetScript('OnTextChanged',function(self) leadDraft.server=self:GetText() end)
    local leadSlots={}
    for i=1,3 do
        local key='p'..i
        local b=button('P'..i..': wählen …',10,-92-(i-1)*26,260,function()
            if not leadDraft.raid then createFeedback:SetText('Bitte zuerst den Raid für die Prio auswählen.');return end
            local data=(GL.db.guildProfiles[GL.db.selectedGuild] or {}).activeRaids or {}
            local items={};for _,item in ipairs(data.catalogs and data.catalogs[leadDraft.raid.raid] or {}) do items[#items+1]={id=item.id,title=item.name,search=item.search,item=item} end
            choose('P'..i..' · '..leadDraft.raid.name,items,function(entry) leadDraft[key]=entry.item;creator:Refresh() end)
        end,lead);b:SetHeight(24);leadSlots[i]=b
        button('×',276,-92-(i-1)*26,30,function() leadDraft[key]=nil;creator:Refresh() end,lead):SetHeight(24)
    end
    local leadPlus=button('P0+: nein',312,-92,80,function() leadDraft.p0Plus=not leadDraft.p0Plus;creator:Refresh() end,lead);leadPlus:SetHeight(24)
    label(lead,10,-172,120,11):SetText(random and 'Lead-PIN des RMD Raids' or 'Lead-PIN (leer = gespeichert)')
    local leadPin=creatorEdit(lead,150,-170,110);leadPin:SetMaxLetters(100)
    if leadPin.SetPassword then leadPin:SetPassword(true) end
    button('Prio speichern',268,-170,124,function()
        local raid=leadDraft.raid;if not raid then createFeedback:SetText('Bitte den Raid für die Prio auswählen.');return end
        local player=(leadDraft.player or ''):gsub('^%s+',''):gsub('%s+$','');local server=(leadDraft.server or ''):gsub('^%s+',''):gsub('%s+$','')
        if player=='' or server=='' or leadDraft.className=='' then createFeedback:SetText('Bitte Spieler, Server und Klasse angeben.');return end
        if not leadDraft.p1 then createFeedback:SetText('Bitte mindestens P1 auswählen.');return end
        if raid.raid~='ony' and not leadDraft.p0Plus and (not leadDraft.p2 or not leadDraft.p3) then createFeedback:SetText('Bitte P1, P2 und P3 auswählen oder P0+ setzen.');return end
        local secret=leadPin:GetText() or ''
        if random and secret:match('^%s*$') and not (GL.KnownLeadPin and GL.KnownLeadPin(raid.id)) then createFeedback:SetText('Bitte den Lead-PIN des RMD Raids eingeben (kein Gildenleitungszugang möglich).');return end
        local ok,err=pcall(GL.QueueWebsiteAction,{id=raid.id},'leadprio',{leadPin=secret,useSavedMaster=secret:match('^%s*$')~=nil,player=player,server=server,className=leadDraft.className,
            p1=leadDraft.p1 and tonumber(leadDraft.p1.id) or 0,p2=leadDraft.p2 and tonumber(leadDraft.p2.id) or 0,p3=leadDraft.p3 and tonumber(leadDraft.p3.id) or 0,p0Plus=leadDraft.p0Plus})
        if ok then leadPin:SetText('') end
        createFeedback:SetText(ok and ('Prio für '..player..' vorgemerkt. /reload zum Senden; die Website prüft den Lead-PIN.') or tostring(err))
    end,lead):SetHeight(24)
    label(lead,10,-198,382,10):SetText('Wie „Prio speichern“ im Raidlead-Panel: für Spieler, die ihre Prio nicht selbst eintragen können. „PIN posten“ schreibt PrioPIN und lichtloot.de in den Raidchat. Benötigt GuildLoot Sync ab 0.3.19.')
    local weekdays={'Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'}
    function creator:Refresh()
        local p=GL.DisplayProfile()
        creatorTitle:SetText(random and 'RMD Raid erstellen · ohne Gilde' or ('Raid erstellen · '..GL.GuildName(GL.db.selectedGuild)))
        createContext:SetText((p and (p.player..' – '..p.realm) or 'Kein Charakter ausgewählt')..' · '..(random and 'Random-Raid wie „Random-Raid erstellen“ auf lichtloot.de · keine Gildenrechte nötig · GuildLoot Sync ab 0.3.20' or (options.available==1 and 'Erstellerrechte vorhanden' or 'Erstellung nicht verfügbar: synchronisieren und Erstellerrechte auf GuildLoot prüfen')))
        local d,t=createDate:GetText(),createTime:GetText()
        local dateOk=d:match('^%d%d%d%d%-%d%d%-%d%d$')~=nil and t:match('^%d%d:%d%d$')~=nil
        local templateOk=draft.mode~='raid' or draft.template~=''
        local channelOk=draft.mode=='prio' or draft.channel~=''
        local done={true,dateOk,channelOk,dateOk and channelOk and templateOk}
        steps[3].label:SetText(draft.mode=='prio' and '3 Kein Discord' or '3 Discord')
        for i,b in ipairs(steps) do b.background:SetColorTexture(done[i] and .12 or .13,done[i] and .42 or .23,done[i] and .31 or .27,1);b.label:SetTextColor(done[i] and 1 or .72,done[i] and 1 or .82,done[i] and 1 or .88) end
        for i,b in ipairs(instanceButtons) do local on=types[i].id==draft.raid;b.background:SetColorTexture(on and .68 or .13,on and .48 or .23,on and .08 or .27,1) end
        for i,b in ipairs(modeButtons) do local on=modes[i][1]==draft.mode;b.background:SetColorTexture(on and .68 or .13,on and .48 or .23,on and .08 or .27,1) end
        modeLabel:SetText(random and 'Art · Prio-Raid (RMD), Prios über PrioPIN, keine Gilde nötig' or 'Anmeldeart')
        templateLabel:SetShown(draft.mode=='raid');groupLabel:SetShown(draft.mode=='prio');groupEdit:SetShown(draft.mode=='prio');channelLabel:SetShown(draft.mode~='prio');channelButton:SetShown(draft.mode~='prio')
        local template;for _,x in ipairs(options.templates or {}) do if x.id==draft.template then template=x end end
        templateButton.label:SetText(template and (template.title or template.name) or 'Vorlage auswählen …');templateButton:SetShown(draft.mode=='raid')
        local channel;for _,x in ipairs(options.channels or {}) do if x.id==draft.channel then channel=x end end
        channelButton.label:SetText(channel and (channel.title or channel.name) or 'Channel auswählen …')
        createButton:SetEnabled((random or options.available==1) and p~=nil and done[4])
        -- Erstellter Raid: PINs sofort sichtbar, Status aus der Sync-Quittung
        local e=createdSelected
        local showCreated=e~=nil
        for _,w in ipairs({pinLine,pinStatus,postCreated,whisperTo,whisperButton,copyButton,pinHint}) do w:SetShown(showCreated) end
        previewName:SetShown(true);previewLines:SetShown(not showCreated)
        createdList.label:SetText(showCreated and 'Vorschau' or ('Erstellte Raids ('..#(GL.db.createdRaids or {})..')'))
        if e then
            right.title:SetText('Erstellter Raid')
            previewName:SetText(e.name..' · '..e.date..(e.clock and e.clock~='' and (' '..e.clock..' Uhr') or '')..(e.mode=='prio' and (' · '..(e.group or 'Random')) or ''))
            pinLine:SetText('PrioPIN: '..tostring(e.playerPin)..'     Lead-PIN: '..tostring(e.leadPin or '—'))
            local rc=(GL.db.outgoingReceipts or {})[e.requestId or '']
            pinStatus:SetText(rc and (rc.state=='success' and '|cff79e6a2Auf GuildLoot angelegt.|r' or rc.state=='failed' and ('|cffff6060Fehlgeschlagen: '..tostring(rc.message):sub(1,60)..'|r') or ('Status: '..tostring(rc.message):sub(1,60))) or 'Wartet auf /reload und die Übertragung durch GuildLoot Sync.')
            pinStatus:SetTextColor(.72,.82,.88)
        else right.title:SetText('Vorschau') end
        local y,m,dd=d:match('^(%d+)%-(%d+)%-(%d+)$');local when=y and (weekdays[tonumber(date('%w',time({year=tonumber(y),month=tonumber(m),day=tonumber(dd),hour=12})))+1]..', '..dd..'.'..m..'.'..y) or 'Datum fehlt'
        previewName:SetText(typeOf(draft.raid).title)
        previewLines:SetText(when..' · '..(t~='' and (t..' Uhr') or 'Uhrzeit fehlt')..'\n'..(draft.mode=='raid' and ('Vorlage '..(template and (template.title or template.name) or '—')..' · Anmeldung mit Rolle · Prios') or draft.mode=='p0' and 'Reiner P0-Anmelder · Item-Anmeldungen ohne Rolle' or ('Prio-Raid (RMD) · Gruppe '..((groupEdit:GetText() or '')~='' and groupEdit:GetText() or 'Random')..' · nur PrioPIN, keine Gilde nötig'))..'\n'..(draft.mode=='prio' and 'Kein Discord-Post · PrioPIN nach /reload hier und im Raidchat' or ('Discord-Post in '..(channel and (channel.title or channel.name) or '—')))..'\n|cff7f9aa6Raid-ID wird von GuildLoot vergeben.|r')
        leadRaidButton.label:SetText(leadDraft.raid and (leadDraft.raid.name..' · '..leadDraft.raid.date) or 'Raid auswählen …')
        leadClass.label:SetText(leadDraft.className~='' and leadDraft.className or 'Klasse …')
        for i,b in ipairs(leadSlots) do local item=leadDraft['p'..i];b.label:SetText('P'..i..': '..(item and item.name or 'wählen …'));b:SetShown(i==1 or ((not leadDraft.raid or leadDraft.raid.raid~='ony') and not leadDraft.p0Plus)) end
        leadPlus.label:SetText('P0+: '..(leadDraft.p0Plus and 'ja' or 'nein'));leadPlus:SetShown(not leadDraft.raid or leadDraft.raid.raid~='ony')
    end
    local function openCreator(leadRaid)
        form:Hide();local p=GL.DisplayProfile();options=((GL.db.guildProfiles[GL.db.selectedGuild] or {}).activeRaids or {}).creation or {}
        draft={raid='mc',mode=random and 'prio' or 'raid',template='',channel=''};groupEdit:SetText('Random');createdSelected=nil;whisperTo:SetText('')
        createDate:SetText(date('%Y-%m-%d'));createTime:SetText('20:00');popup:Hide()
        leadDraft={raid=nil,player='',server=p and p.realm or '',className='',p1=nil,p2=nil,p3=nil,p0Plus=false};leadPlayer:SetText('');leadServer:SetText(leadDraft.server);leadPin:SetText('')
        local rows=sourceRows();leadDraft.raid=rows[1]
        createFeedback:SetText((random or options.available==1) and GL.WebsiteActionStatus('create') or 'Raid-Erstellung nicht verfügbar. Prio für Spieler bleibt möglich.')
        if leadRaid then leadDraft.raid=leadRaid end
        creator:Refresh();creator:Show()
    end
    openCreatorForLead=openCreator
    button(random and '+ RMD Raid erstellen' or '+ Raid erstellen',466,0,194,function() openCreator() end)
    local joinBox,joinEdit
    -- Raid löschen: auf GuildLoot archivieren (Random-Raid nur mit Lead-PIN, Gildenraid mit Lead-PIN oder gespeichertem Gildenleitungszugang)
    local deleteBox=CreateFrame('Frame',nil,view);deleteBox:SetPoint('TOPLEFT',246,-30);deleteBox:SetSize(440,100);deleteBox:EnableMouse(true)
    if deleteBox.SetFrameLevel and view.GetFrameLevel then deleteBox:SetFrameLevel(view:GetFrameLevel()+40) end
    local dbg=deleteBox:CreateTexture(nil,'BACKGROUND');dbg:SetAllPoints();dbg:SetColorTexture(.2,.08,.1,1)
    local deleteTitle=label(deleteBox,10,-8,420,12);deleteTitle:SetTextColor(1,.8,.3)
    local deleteHint=label(deleteBox,10,-26,420,10)
    local deleteEdit=creatorEdit(deleteBox,16,-48,120);deleteEdit:SetMaxLetters(100);if deleteEdit.SetPassword then deleteEdit:SetPassword(true) end
    local deleteTarget
    local function confirmDelete()
        local raid=deleteTarget;if not raid then deleteBox:Hide();return end
        local pin=random and ((deleteEdit:GetText() or ''):gsub('^%s+',''):gsub('%s+$','')) or ''
        if random and not pin:upper():match('^[A-Z2-9][A-Z2-9][A-Z2-9][A-Z2-9]$') and not (GL.KnownLeadPin and GL.KnownLeadPin(raid.id)) then countLabel:SetText('Bitte den Lead-PIN des RMD Raids eingeben (4 Zeichen).');return end
        if not random and not (GL.HasGuildMasterAccess and GL.HasGuildMasterAccess()) then countLabel:SetText('Löschen nur mit Gildenleitungs-PIN: einmal unter Plündermeister mit dem Gildenleitungs-PIN anmelden.');deleteBox:Hide();return end
        local ok,err=pcall(GL.QueueWebsiteAction,{id=raid.id},'delete',{leadPin=pin,useSavedMaster=pin=='',random=raid.random==1})
        if not ok then countLabel:SetText(tostring(err));return end
        GL.db.deletedRaids=GL.db.deletedRaids or {};GL.db.deletedRaids[raid.id]={at=GetServerTime(),requestId=err}
        local kept={};for _,e in ipairs(GL.db.createdRaids or {}) do if not (e.serverId==raid.id or ((e.playerPin or '')~='' and e.playerPin==raid.prioPin)) then kept[#kept+1]=e end end;GL.db.createdRaids=kept
        deleteEdit:SetText('');deleteBox:Hide();view:Refresh()
        countLabel:SetText('Löschen vorgemerkt: '..raid.name..'. /reload zum Senden; GuildLoot Sync archiviert den Raid auf GuildLoot.')
    end
    button('Raid löschen',146,-48,120,confirmDelete,deleteBox).background:SetColorTexture(.55,.16,.2,1);button('Abbrechen',272,-48,90,function() deleteBox:Hide() end,deleteBox)
    deleteBox:SetSize(440,86)
    deleteEdit:SetScript('OnEnterPressed',confirmDelete);deleteEdit:SetScript('OnEscapePressed',function() deleteBox:Hide() end)
    deleteBox:Hide()
    openDelete=function(raid)
        if not raid or raid.pending then return end
        if not random and not (GL.HasGuildMasterAccess and GL.HasGuildMasterAccess()) then countLabel:SetText('Löschen nur mit Gildenleitungs-PIN: einmal unter Plündermeister mit dem Gildenleitungs-PIN anmelden.');return end
        deleteTarget=raid;creator:Hide();if joinBox then joinBox:Hide() end;deleteEdit:SetShown(random)
        deleteTitle:SetText('Raid löschen: '..tostring(raid.name)..' · '..tostring(raid.date)..(raid.clock~='' and (' '..raid.clock) or ''))
        deleteHint:SetText(random and ((GL.KnownLeadPin and GL.KnownLeadPin(raid.id)) and 'Der Raid wird auf GuildLoot archiviert; PrioPIN und Lead-PIN gelten danach nicht mehr. Lead-PIN ist bekannt (selbst erstellt), Feld kann leer bleiben.' or 'Der Raid wird auf GuildLoot archiviert; PrioPIN und Lead-PIN gelten danach nicht mehr. Lead-PIN des Raids eingeben.') or 'Der Raid wird mit deinem gespeicherten Gildenleitungszugang auf GuildLoot archiviert (Anmeldungen und Prios bleiben im Archiv).')
        deleteEdit:SetText('');deleteBox:Show();deleteEdit:SetFocus()
    end
    -- RMD: bestehenden Random-Raid per PrioPIN öffnen (Sync lädt ihn beim nächsten Abgleich)
    if random then
        joinBox=CreateFrame('Frame',nil,view);joinBox:SetPoint('TOPLEFT',246,-30);joinBox:SetSize(420,74);joinBox:EnableMouse(true)
        if joinBox.SetFrameLevel and view.GetFrameLevel then joinBox:SetFrameLevel(view:GetFrameLevel()+40) end
        local jbg=joinBox:CreateTexture(nil,'BACKGROUND');jbg:SetAllPoints();jbg:SetColorTexture(.08,.18,.22,1)
        label(joinBox,10,-8,400,12):SetText('PrioPIN (3 Zeichen, Spieler) oder Lead-PIN (4 Zeichen, Raidleitung)')
        joinEdit=creatorEdit(joinBox,16,-30,120);joinEdit:SetMaxLetters(4)
        local function join()
            local pin=(joinEdit:GetText() or ''):upper():gsub('%s','')
            local isLead=pin:match('^[A-Z2-9][A-Z2-9][A-Z2-9][A-Z2-9]$')~=nil
            if not isLead and not pin:match('^[A-Z2-9][A-Z2-9][A-Z2-9]$') then countLabel:SetText('Bitte eine gültige PIN eingeben: PrioPIN 3 Zeichen, Lead-PIN 4 Zeichen (Buchstaben und Ziffern 2–9).');return end
            GL.db.createdRaids=GL.db.createdRaids or {}
            for _,e in ipairs(GL.db.createdRaids) do if e.mode=='prio' and ((not isLead and e.playerPin==pin) or (isLead and e.leadPin==pin)) then joinBox:Hide();view:Refresh();return end end
            table.insert(GL.db.createdRaids,1,{at=GetServerTime(),guild=GL.db.selectedGuild,raid='',name='Random-Raid',date=date('%Y-%m-%d'),clock='',group='',mode='prio',playerPin=isLead and '' or pin,leadPin=isLead and pin or '',joined=true,random=true})
            while #GL.db.createdRaids>20 do table.remove(GL.db.createdRaids) end
            joinBox:Hide();view:Refresh();countLabel:SetText((isLead and 'Lead-PIN' or 'PrioPIN')..' vorgemerkt. /reload, GuildLoot Sync lädt den Raid, danach erneut /reload.')
        end
        button('Öffnen',146,-30,90,join,joinBox);button('Abbrechen',242,-30,90,function() joinBox:Hide() end,joinBox)
        joinEdit:SetScript('OnEnterPressed',join);joinEdit:SetScript('OnEscapePressed',function() joinBox:Hide() end)
        joinBox:Hide()
        button('Per PrioPIN öffnen',246,0,200,function() creator:Hide();form:Hide();joinEdit:SetText('');joinBox:Show();joinEdit:SetFocus() end)
    end
    popup:Hide();creator:Hide()
    view:SetScript('OnHide',function() form:Hide();creator:Hide();popup:Hide();deleteBox:Hide();deleteEdit:ClearFocus();if joinBox then joinBox:Hide();joinEdit:ClearFocus() end;search:ClearFocus();rosterSearch:ClearFocus();createDate:ClearFocus();createTime:ClearFocus();groupEdit:ClearFocus();popupSearch:ClearFocus();whisperTo:ClearFocus();copyEdit:ClearFocus();copyBox:Hide();leadPlayer:ClearFocus();leadServer:ClearFocus();leadPin:ClearFocus();if GameTooltip then GameTooltip:Hide() end end)
    return view
end
