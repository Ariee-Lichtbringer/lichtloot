local _,GL=...
local function pattern(format)
 local parts,order={},{};local i,auto=1,0
 while i<=#format do
  local tail=format:sub(i);local token,index,kind=tail:match('^(%%(%d+)%$([sd]))')
  if not token then token,kind=tail:match('^(%%([sd]))');if token then auto=auto+1;index=auto end end
  if token then parts[#parts+1]=kind=='d' and '(%d+)' or '(.-)';order[#order+1]=tonumber(index);i=i+#token
  else local c=format:sub(i,i);parts[#parts+1]=(c:gsub('([%^%$%(%)%%%.%[%]%*%+%-%?])','%%%1'));i=i+1 end
 end
 return '^'..table.concat(parts)..'$',order
end
function GL.RecordChatEvidence(event,text,sender,lineId)
 local r=GL.Active();if not r or not IsInRaid() or type(text)~='string' or #text>3000 then return end
 local e={raw=text,observedAt=GetServerTime(),channel=event}
 if event=='CHAT_MSG_RAID' or event=='CHAT_MSG_RAID_LEADER' or event=='CHAT_MSG_RAID_WARNING' then
  local member=GL.RaidMember(sender);if not member then return end
  local id,name=text:match('|Hitem:(%d+)[^|]*|h%[(.-)%]|h')
  local priority,players=text:match('ist gesetzt als Priorität ([123]) für%s+(.+)%s*$')
  if not id or not priority then return end
  e.kind='priority';e.itemId=tonumber(id);e.itemName=name;e.priority='P'..priority;e.players=players;e.sender=member
 elseif event=='CHAT_MSG_SYSTEM' and RANDOM_ROLL_RESULT then
  local p,order=pattern(RANDOM_ROLL_RESULT);local found={text:match(p)};if #found==0 then return end
  local a={};for n,v in ipairs(found) do a[order[n]]=v end
  local player=GL.RaidMember(a[1]);if not player then return end
  e.kind='roll';e.sender=player;e.roll=tonumber(a[2]);e.minimum=tonumber(a[3]);e.maximum=tonumber(a[4])
  if not e.roll or not e.minimum or not e.maximum or e.roll<e.minimum or e.roll>e.maximum then return end
  -- A system roll does not carry an item ID. Keep it unassigned for PM review.
 else return end
 GL.evidenceLines=GL.evidenceLines or {}
 local key=r.sessionId..':'..tostring(lineId)
 if type(lineId)=='number' and lineId>0 then if GL.evidenceLines[key] then return end;GL.evidenceLines[key]=true end
 r.chatEvidence=r.chatEvidence or {};if #r.chatEvidence>=5000 then r.captureWarning=true;return end
 e.id=r.sessionId..':evidence:'..(#r.chatEvidence+1);r.chatEvidence[#r.chatEvidence+1]=e
end
local f=CreateFrame('Frame')
for _,event in ipairs({'CHAT_MSG_RAID','CHAT_MSG_RAID_LEADER','CHAT_MSG_RAID_WARNING','CHAT_MSG_SYSTEM'}) do f:RegisterEvent(event) end
f:SetScript('OnEvent',function(_,event,text,sender,...) GL.RecordChatEvidence(event,text,sender,select(9,...)) end)
