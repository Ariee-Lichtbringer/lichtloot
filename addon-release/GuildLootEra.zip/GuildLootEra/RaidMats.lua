local _,GL=...
local C=GL.RaidChecklist
local M={};GL.RaidMats=M
M.items={{17029,'Heilige Kerze'},{17028,'Heilige Kerze (niedriger Rang)'},{17026,'Wilder Dornwurz'},{17021,'Wilde Beeren'},{17020,'Arkanes Pulver'},{21177,'Symbol der Könige'},{17033,'Symbol der Offenbarung'},{17031,'Rune der Teleportation'},{17032,'Rune der Portale'}}
function M.Store()
 local s=C.Store();if not s then return end
 s.mats=s.mats or {enabled=true,targets={}};s.mats.targets=s.mats.targets or {};return s.mats
end
function M.Set(id,value)
 local n=tonumber(value);if not n or n%1~=0 or n<0 or n>999 then return false end
 M.Store().targets[id]=n;return true
end
local function say(message)M.message=message;if M.status then M.status:SetText(message)end end
function M.Stop(message)
 M.running=false;M.pending=nil
 if message then say(message);print('|cff79e6c5GuildLoot Mats:|r '..message)end
end
local function merchantInfo(i)
 if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
  local v=C_MerchantFrame.GetItemInfo(i);if v then return v.price,v.stackCount,v.numAvailable,v.isPurchasable,v.hasExtendedCost end
 elseif GetMerchantItemInfo then
  local _,_,price,quantity,available,purchasable,_,extended=GetMerchantItemInfo(i)
  return price,quantity,available,purchasable,extended
 end
end
function M.Step(dt)
 if not M.running then return end
 local s=M.Store();if not s or s.enabled==false then M.Stop();return end
 local counts,readable=C.Inventory();if not readable then M.Stop('Taschen konnten nicht geprüft werden.');return end
 if M.pending then
  local p=M.pending;p.age=p.age+dt
  if (counts[p.id]or 0)<p.before+p.quantity then
   if p.age>=3 then M.Stop('Nachkauf gestoppt: Kauf nicht bestätigt. Bitte Taschen und Gold prüfen.')end
   return
  end
  M.bought=M.bought+p.quantity;M.pending=nil
 end
 for _,item in ipairs(M.items)do
  local id=item[1];local target=tonumber(s.targets[id])or 0;local missing=target-(counts[id]or 0)
  if missing>0 then for i=1,GetMerchantNumItems()do
   if GL.GearItemID(GetMerchantItemLink(i))==id then
    local price,bundle,available,purchasable,extended=merchantInfo(i)
    if price and bundle and bundle>0 and purchasable and not extended and available~=0 then
     local max=GetMerchantItemMaxStack(i)or bundle
     local amount=math.min(missing,max,available and available>=0 and available or missing)
     if price>0 then amount=math.min(amount,math.floor(GetMoney()*bundle/price))end
     -- Merchant quantities are item counts; buy only complete vendor bundles.
     amount=math.floor(amount/bundle)*bundle
     if amount>0 then
      M.pending={id=id,before=counts[id]or 0,quantity=amount,age=0}
      BuyMerchantItem(i,amount);return
     end
    end
   end
  end end
 end
 local missing=false
 for _,item in ipairs(M.items)do if (counts[item[1]]or 0)<(tonumber(s.targets[item[1]])or 0)then missing=true end end
 M.Stop(M.bought>0 and ('Nachgekauft: '..M.bought..' Reagenzien.'..(missing and ' Nicht alle Soll-Mengen konnten aufgefüllt werden.'or ''))or nil)
end
function M.Open(parent)
 if not M.panel then
  local p=CreateFrame('Frame',nil,parent);M.panel=p;p:SetPoint('TOPLEFT',12,-45);p:SetPoint('BOTTOMRIGHT',-12,12);p:SetFrameLevel(parent:GetFrameLevel()+20);p:EnableMouse(true)
  local bg=p:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.025,.045,.065,1)
  local function label(text,x,y,w)local f=p:CreateFontString(nil,'OVERLAY','GameFontHighlight');f:SetPoint('TOPLEFT',x,y);f:SetWidth(w);f:SetJustifyH('LEFT');f:SetText(text);return f end
  label('Mats · Reagenzien automatisch nachkaufen',18,-16,760):SetTextColor(.45,.9,.78)
  local back=CreateFrame('Button',nil,p);back:SetPoint('TOPRIGHT',-12,-10);back:SetSize(90,28);local bg=back:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.12,.20,.26,1);local text=back:CreateFontString(nil,'OVERLAY','GameFontHighlight');text:SetPoint('CENTER');text:SetText('Zurück');back:SetScript('OnClick',function()p:Hide()end)
  M.enabled=CreateFrame('CheckButton',nil,p,'UICheckButtonTemplate');M.enabled:SetPoint('TOPLEFT',18,-50);M.enabled:SetSize(24,24);label('Beim Händler automatisch auf Soll-Menge auffüllen',48,-55,780)
  M.enabled:SetScript('OnClick',function(self)M.Store().enabled=self:GetChecked()==true;if not M.Store().enabled then M.Stop()end end)
  label('Pro Charakter gespeichert · 0 = nicht kaufen · zählt nur den Vorrat in deinen Taschen',18,-90,860)
  label('Reagenz',18,-128,450);label('Soll-Menge',530,-128,110);label('Dabei',690,-128,110)
  M.rows={}
  for index,item in ipairs(M.items)do
   local id=item[1];local y=-157-(index-1)*40
   local name=label(item[2],18,y-5,490)
   local edit=CreateFrame('EditBox',nil,p,'InputBoxTemplate');edit:SetPoint('TOPLEFT',535,y);edit:SetSize(88,26);edit:SetAutoFocus(false);edit:SetNumeric(true);edit:SetMaxLetters(3)
   local function save(self)if not M.Set(id,self:GetText())then self:SetText(tostring(M.Store().targets[id]or 0))end end
   edit:SetScript('OnTextChanged',function(self,user)if user then M.Set(id,self:GetText())end end)
   edit:SetScript('OnEditFocusLost',save);edit:SetScript('OnEnterPressed',function(self)save(self);self:ClearFocus()end);edit:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
   M.rows[#M.rows+1]={id=id,name=name,edit=edit,count=label('',690,y-5,110)}
  end
  M.status=label('',18,-540,850)
  label('Kauft beim nächsten Öffnen eines Händlers, der diese Reagenzien verkauft.\nFehlendes Gold, volle Taschen oder begrenzter Vorrat können das Auffüllen begrenzen.',18,-580,860)
 end
 local s=M.Store();M.enabled:SetChecked(s.enabled~=false);local counts=C.Inventory()
 for _,row in ipairs(M.rows)do row.edit:SetText(tostring(s.targets[row.id]or 0));row.count:SetText(tostring(counts[row.id]or 0));local name=GetItemInfo(row.id);if name then row.name:SetText(name)end end
 M.status:SetText(M.message or 'Gewünschte Gesamtmenge je Reagenz eintragen.');M.panel:Show()
end
local frame=CreateFrame('Frame');frame:RegisterEvent('MERCHANT_SHOW');frame:RegisterEvent('MERCHANT_CLOSED');frame:RegisterEvent('UI_ERROR_MESSAGE');frame:RegisterEvent('BAG_UPDATE_DELAYED')
frame:SetScript('OnEvent',function(_,event)
 if event=='BAG_UPDATE_DELAYED' then
  if M.panel and M.panel:IsShown()then local counts=C.Inventory();for _,row in ipairs(M.rows)do row.count:SetText(tostring(counts[row.id]or 0))end end;return
 end
 if event=='MERCHANT_CLOSED' then M.Stop();return end
 if event=='UI_ERROR_MESSAGE' then if M.pending then M.Stop('Nachkauf gestoppt. Bitte die Fehlermeldung des Spiels prüfen.')end;return end
 if not GL.db then return end;local s=M.Store();if not s or s.enabled==false then return end
 M.running=true;M.pending=nil;M.bought=0;M.elapsed=0
end)
frame:SetScript('OnUpdate',function(_,dt)
 if not M.running then return end;M.elapsed=(M.elapsed or 0)+dt;if M.elapsed<.35 then return end
 local elapsed=M.elapsed;M.elapsed=0;M.Step(elapsed)
end)
