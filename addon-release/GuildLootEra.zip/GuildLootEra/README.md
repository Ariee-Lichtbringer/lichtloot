# GuildLoot Era 0.24.12-beta

Für WoW Classic Era (Interface 11509).

## Installation
Den Ordner GuildLootEra in World of Warcraft/_classic_era_/Interface/AddOns/ kopieren.
Danach WoW vollständig neu starten. Öffnen mit /gle oder /guildloot.

## Website-Verbindung
GuildLoot Sync 0.3.12 herunterladen: https://lichtloot.de/start.html
Dort „Addon Download & Installation“ wählen, Sync installieren, den Addonordner verbinden und das Gildenprofil einrichten.
Nach dem Synchronisieren in WoW /reload eingeben. Sync muss für die Übertragung geöffnet bleiben.
Ohne erkannte Synchronisierung sind die Website-Aktionen und der GuildLoot-Berufsbereich ausgegraut.
Whisper und Buffs können ohne Sync verwendet werden.

## Neu in dieser Version
- Buff-Meldung im Raidchat nur noch nach eigenem Zauber: Das Addon meldet „hat Gruppe … gebufft“ ausschließlich, wenn der eigene Charakter den Gruppenbuff tatsächlich gewirkt hat. Fremde Auffrischungen lösen keine Meldung mehr aus.
- Berufe ohne GuildLoot-Account: Berufsfenster, Datenbank, Skillguides und Berufe-Symbol funktionieren ohne Sync. Nur „Berufe synchronisieren“ (charübergreifende Speicherung auf GuildLoot) benötigt weiterhin einen Lichtloot- oder Nachtloot-Account mit GuildLoot Sync.

Enthält keine persönlichen Gilden-, Spieler- oder Synchronisierungsdaten.

## Persönlicher GuildLoot Raidcheck
Koffersymbol frei ziehen, anklicken oder /glcheck. Eigene Listen pro Raidtyp und importiertem Raidtermin; Gegenstände per Item-ID/Link oder aus der Tasche eintragen, Menge und Kategorie wählen. Gespeicherte Ausrüstungssets lassen sich übernehmen. Taschen und angelegte Ausrüstung zählen, Bank nicht. Im Spiel erfolgt einmal pro importierter eigener Raid-Anmeldung ab 30 Minuten vorher eine Erinnerung. Für aktuelle Termine muss der Kalender über GuildLoot Sync importiert sein; die Taschenprüfung selbst funktioniert ohne Sync. © Ariee - Everlook

## Raidcheck-Datenquellen
Raidcheck data built 2026-09-11. Item identities from GuildLoot Classic profession data (existing PROFESSION-DATA-SOURCE.txt) and factual item IDs/categories inspected in locally installed NovaConsumesHelper Classic_DB.lua (Novaspark). No Nova addon implementation copied. German names, icon paths and item descriptions loaded through GuildLoot public searchPublicClassicItems service (WoW Classic item data). Season of Discovery IDs excluded. The WoW client supplies live bag/equipment and tooltip data. Bank data is a per-character snapshot from visiting the bank.

## Bank-Auffüllen
Bei geöffneter eigener Bank im Raidcheck eine Liste auswählen und „Von Bank auffüllen“ klicken. Nur die fehlenden Soll-Mengen werden übernommen, vorhandene und angelegte Items zählen mit. Banktaschen und passende Spezialtaschen werden berücksichtigt. Der Vorgang stoppt beim Schließen der Bank, im Kampf, beim Listenwechsel oder bei belegtem Mauszeiger. „Auffüllen stoppen“ bricht ab. Fehlende Bankbestände und voller Taschenplatz werden angezeigt.
