local _,GL=...
-- Presence is supported by local combat evidence, never inferred from a signup
-- or absence from a partial recording. Store identities including their realm.
local units={}
local function roster()
    units={};local own=UnitGUID('player');if own then units[own]='player' end
    for i=1,GetNumGroupMembers() do local unit='raid'..i;local guid=UnitGUID(unit);if guid then units[guid]=unit end end
end
function GL.RecordParticipant(guid,evidence)
    local r=GL.Active();if not r or not GL.InInstance(r) or not guid then return end
    local unit=units[guid]
    if not unit or UnitGUID(unit)~=guid then return end
    local name,realm=UnitFullName(unit);if not name then return end
    realm=(realm and realm~='') and realm or GetRealmName()
    r.participants=r.participants or {};local now=GetServerTime()
    for _,p in ipairs(r.participants) do if p.guid==guid then p.lastSeen=now;if evidence=='combat' then p.evidence=evidence end;return end end
    r.participants[#r.participants+1]={guid=guid,player=name,realm=realm,firstSeen=now,lastSeen=now,evidence=evidence}
end
local previous=GL.CaptureStarted
function GL.CaptureStarted(r)
    roster();if previous then previous(r) end
    GL.RecordParticipant(UnitGUID('player'),'self')
end
local frame=CreateFrame('Frame');frame:RegisterEvent('COMBAT_LOG_EVENT_UNFILTERED');frame:RegisterEvent('PLAYER_ENTERING_WORLD');frame:RegisterEvent('GROUP_ROSTER_UPDATE')
frame:SetScript('OnEvent',function(_,event)
    if event=='GROUP_ROSTER_UPDATE' then roster();return end
    if event=='PLAYER_ENTERING_WORLD' then roster();GL.RecordParticipant(UnitGUID('player'),'self');return end
    local _,kind,_,source,_,_,_,destination=CombatLogGetCurrentEventInfo()
    if kind and (kind:find('_DAMAGE',1,true) or kind:find('_HEAL',1,true) or kind:find('_MISSED',1,true) or kind=='SPELL_CAST_SUCCESS') then
        GL.RecordParticipant(source,'combat');GL.RecordParticipant(destination,'combat')
    end
end)
