local _,GL=...
-- A closed/accepted window is not proof of a successful exchange.
-- Only Blizzard's localized completion message commits the last offer.
function GL.SnapshotTrade()
 local t=GL.tradeWindow;if not t or t.closedAt then return end
 local rows={}
 for _,side in ipairs({'Player','Target'}) do
  for slot=1,6 do -- slot seven is an enchantment, not an item transfer
   local link=_G['GetTrade'..side..'ItemLink'](slot)
   local name,_,quantity=_G['GetTrade'..side..'ItemInfo'](slot)
   local id=link and tonumber(link:match('item:(%d+)'))
   if id and quantity and quantity>0 then
    rows[#rows+1]={giver=side=='Player' and t.player or t.partner,recipient=side=='Player' and t.partner or t.player,itemId=id,itemName=name or link:match('%[(.-)%]') or tostring(id),quantity=quantity}
   end
  end
 end
 t.rows=rows
end
function GL.CommitTrade(t)
  local r=t.raid;r.trades=r.trades or {}
  if #r.trades+#t.rows>5000 then r.captureWarning=true;return end
  for _,e in ipairs(t.rows) do
   r.tradeSequence=(r.tradeSequence or 0)+1
   e.id=r.sessionId..':trade:'..r.tradeSequence;e.observedAt=GetServerTime()
   r.trades[#r.trades+1]=e
  end
end
function GL.ConnectGargulTrades()
 if GL.gargulTradeConnected or not Gargul or not Gargul.Events or not Gargul.Events.register then return end
 Gargul.Events:register('GuildLootEraTrades','GL.TRADE_COMPLETED',function(_,details)
  local r=GL.Active();if not r or not IsInRaid() or type(details)~='table' then return end
  local partner=GL.RaidMember(details.partner);local player=GL.FullName('player')
  if not partner or partner==player then return end
  local t={raid=r,rows={}}
  for _,side in ipairs({'MyItems','TheirItems'}) do
   for slot=1,6 do
    local e=(details[side] or {})[slot]
    if e and tonumber(e.itemID) and tonumber(e.quantity) and e.quantity>0 then
     t.rows[#t.rows+1]={giver=side=='MyItems' and player or partner,recipient=side=='MyItems' and partner or player,itemId=tonumber(e.itemID),itemName=e.name or tostring(e.itemID),quantity=tonumber(e.quantity)}
    end
   end
  end
  GL.CommitTrade(t);GL.tradeWindow=nil
 end)
 GL.gargulTradeConnected=true
end
function GL.TradeEvent(event,...)
 if event=='TRADE_SHOW' then
  GL.tradeWindow=nil
  local r=GL.Active();if not r or not IsInRaid() then return end
  local partner=GL.RaidMember(GL.FullName('NPC'))
  local player=GL.FullName('player');if not partner or partner==player then return end
  GL.tradeWindow={raid=r,player=player,partner=partner,rows={}}
  GL.SnapshotTrade()
 elseif event=='TRADE_PLAYER_ITEM_CHANGED' or event=='TRADE_TARGET_ITEM_CHANGED' or event=='TRADE_ACCEPT_UPDATE' then
  GL.SnapshotTrade()
 elseif event=='TRADE_CLOSED' then
  if GL.tradeWindow then GL.tradeWindow.closedAt=GetServerTime() end
 elseif event=='UI_INFO_MESSAGE' then
  local _,message=...
  if ERR_TRADE_CANCELLED and message==ERR_TRADE_CANCELLED then GL.tradeWindow=nil;return end
  if not ERR_TRADE_COMPLETE or message~=ERR_TRADE_COMPLETE then return end
  if GL.gargulTradeConnected then return end
  local t=GL.tradeWindow;GL.tradeWindow=nil
  if not t or GL.Active()~=t.raid or (t.closedAt and GetServerTime()-t.closedAt>5) then return end
  GL.CommitTrade(t)
 end
end
local f=CreateFrame('Frame')
for _,event in ipairs({'TRADE_SHOW','TRADE_PLAYER_ITEM_CHANGED','TRADE_TARGET_ITEM_CHANGED','TRADE_ACCEPT_UPDATE','TRADE_CLOSED','UI_INFO_MESSAGE','ADDON_LOADED','PLAYER_LOGIN'}) do f:RegisterEvent(event) end
f:SetScript('OnEvent',function(_,event,...) if event=='ADDON_LOADED' or event=='PLAYER_LOGIN' then GL.ConnectGargulTrades() else GL.TradeEvent(event,...) end end)
