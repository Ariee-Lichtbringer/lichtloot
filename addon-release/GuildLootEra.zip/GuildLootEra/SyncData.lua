GuildLootSyncInbox = nil
