local _,GL=...
function GL.MainWindowScale(value,width,height)
 local upper=math.min(1.35,math.max(.1,(width-24)/940),math.max(.1,(height-24)/740))
 return math.max(math.min(.55,upper),math.min(tonumber(value) or 1.15,upper))
end
function GL.EnableMainWindowSizing(f)
 local function save()
  GL.db.mainWindowScale=f:GetScale()
  local point,_,relative,x,y=f:GetPoint();GL.db.mainWindowPosition={point,relative,x,y}
 end
 local function resize(value)
  if InCombatLockdown() then return end
  f:SetScale(GL.MainWindowScale(value,UIParent:GetWidth(),UIParent:GetHeight()));save()
 end
 local pos=GL.db.mainWindowPosition
 resize(GL.db.mainWindowScale)
 if pos then f:ClearAllPoints();f:SetPoint(pos[1],UIParent,pos[2],pos[3],pos[4]);save() end
 f:HookScript('OnDragStop',save)
 local function control(label,x,callback)
  local b=CreateFrame('Button',nil,f,'UIPanelButtonTemplate');b:SetPoint('BOTTOMRIGHT',x,10);b:SetSize(30,22);b:SetText(label);b:SetScript('OnClick',callback);return b
 end
 control('−',-104,function() resize(f:GetScale()-.05) end)
 control('+',-70,function() resize(f:GetScale()+.05) end)
 local reset=control('1:1',-36,function() resize(1) end);reset:SetWidth(34)
 local grip=CreateFrame('Button',nil,f);grip:SetPoint('BOTTOMRIGHT',-6,6);grip:SetSize(24,24)
 grip:SetNormalTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up');grip:SetHighlightTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight')
 local dragging
 grip:SetScript('OnMouseDown',function(_,button)
  if button~='LeftButton' or InCombatLockdown() then return end
  local cursorX,cursorY=GetCursorPosition();local ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale();local left,top=f:GetLeft()*ratio,f:GetTop()*ratio
  f:ClearAllPoints();f:SetPoint('TOPLEFT',UIParent,'BOTTOMLEFT',left,top)
  dragging={x=cursorX,y=cursorY,scale=f:GetScale(),width=940*f:GetEffectiveScale(),height=740*f:GetEffectiveScale()}
 end)
 local function stop() if dragging then dragging=nil;save() end end
 grip:SetScript('OnMouseUp',stop);f:HookScript('OnHide',stop)
 grip:SetScript('OnUpdate',function()
  if not dragging then return end
  if InCombatLockdown() or not IsMouseButtonDown('LeftButton') then stop();return end
  local x,y=GetCursorPosition();local dx=(x-dragging.x)/dragging.width;local dy=(dragging.y-y)/dragging.height
  resize(dragging.scale*(1+(math.abs(dx)>math.abs(dy) and dx or dy)))
 end)
 grip:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_TOP');GameTooltip:SetText('Fenstergröße');GameTooltip:AddLine('Ecke ziehen oder − / + verwenden. Größe und Position werden gespeichert.',1,1,1,true);GameTooltip:Show() end)
 grip:SetScript('OnLeave',function() GameTooltip:Hide() end)
end
