local _,GL=...
function GL.MainWindowScale(value,width,height)
 local upper=math.min(1.35,math.max(.1,(width-24)/1110),math.max(.1,(height-24)/740))
 return math.max(math.min(.55,upper),math.min(tonumber(value) or 1.15,upper))
end
function GL.EnableMainWindowSizing(f)
 local function save()
  GL.db.mainWindowScale=f:GetScale()
  local point,_,relative,x,y=f:GetPoint();GL.db.mainWindowPosition={point,relative,x,y}
 end
 local function resize(value)
  if InCombatLockdown() then return end
  f:SetScale(GL.MainWindowScale(value,UIParent:GetWidth(),UIParent:GetHeight()));save()
 end
 local pos=GL.db.mainWindowPosition
 resize(GL.db.mainWindowScale)
 if pos then f:ClearAllPoints();f:SetPoint(pos[1],UIParent,pos[2],pos[3],pos[4]);save() end
 f:HookScript('OnDragStop',save)
 local function control(label,x,callback)
  local b=CreateFrame('Button',nil,f,'UIPanelButtonTemplate');b:SetPoint('BOTTOMRIGHT',x,10);b:SetSize(30,22);b:SetText(label);b:SetScript('OnClick',callback);return b
 end
 control('−',-104,function() resize(f:GetScale()-.05) end)
 control('+',-70,function() resize(f:GetScale()+.05) end)
 local reset=control('1:1',-36,function() resize(1) end);reset:SetWidth(34)
 local grip=CreateFrame('Button',nil,f);grip:SetPoint('BOTTOMRIGHT',-6,6);grip:SetSize(24,24)
 grip:SetNormalTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up');grip:SetHighlightTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight')
 local dragging
 grip:SetScript('OnMouseDown',function(_,button)
  if button~='LeftButton' or InCombatLockdown() then return end
  local cursorX,cursorY=GetCursorPosition();local ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale();local left,top=f:GetLeft()*ratio,f:GetTop()*ratio
  f:ClearAllPoints();f:SetPoint('TOPLEFT',UIParent,'BOTTOMLEFT',left,top)
  dragging={x=cursorX,y=cursorY,scale=f:GetScale(),width=1110*f:GetEffectiveScale(),height=740*f:GetEffectiveScale()}
 end)
 local function stop() if dragging then dragging=nil;save() end end
 grip:SetScript('OnMouseUp',stop);f:HookScript('OnHide',stop)
 grip:SetScript('OnUpdate',function()
  if not dragging then return end
  if InCombatLockdown() or not IsMouseButtonDown('LeftButton') then stop();return end
  local x,y=GetCursorPosition();local dx=(x-dragging.x)/dragging.width;local dy=(dragging.y-y)/dragging.height
  resize(dragging.scale*(1+(math.abs(dx)>math.abs(dy) and dx or dy)))
 end)
 grip:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_TOP');GameTooltip:SetText('Fenstergröße');GameTooltip:AddLine('Ecke ziehen oder − / + verwenden. Größe und Position werden gespeichert.',1,1,1,true);GameTooltip:Show() end)
 grip:SetScript('OnLeave',function() GameTooltip:Hide() end)
end

-- Einheitlicher Stil der Werkzeugfenster (Mini-Addons) wie GuildHeal: heller Schiefergrund, feiner Rahmen,
-- Schließen-Knopf oben rechts und ein Griff unten rechts, der die Fenstergröße (Skalierung) ändert.
GL.TOOL_BG={.16,.22,.29,.96};GL.TOOL_BORDER={.45,.56,.66,.9}
-- Hintergrund der Werkzeugfenster: zentrale Einstellung (GuildLoot → Einstellungen · Sync → Werkzeugfenster), Vorgaben oder eigene Farbe.
GL.TOOL_PRESETS={{key='dark',name='Dunkel',c={.06,.09,.12}},{key='slate',name='Schiefer',c={.16,.22,.29}},{key='charcoal',name='Anthrazit',c={.05,.05,.06}},{key='warm',name='Warmes Dunkel',c={.11,.07,.05}}}
function GL.ToolTheme()
 if not GL.db then return {preset='slate',alpha=.96} end
 GL.db.toolTheme=GL.db.toolTheme or {};local t=GL.db.toolTheme
 t.preset=t.preset or 'slate';t.alpha=math.max(.2,math.min(1,tonumber(t.alpha) or .96));return t
end
function GL.ToolBackground()
 local t=GL.ToolTheme();local c
 if t.preset=='custom' and type(t.custom)=='table' then c=t.custom else for _,p in ipairs(GL.TOOL_PRESETS) do if p.key==t.preset then c=p.c end end end
 c=c or GL.TOOL_PRESETS[2].c;return c[1],c[2],c[3],t.alpha
end
local styledWindows=setmetatable({},{__mode='k'})
function GL.ApplyToolTheme()
 local r,g,b,a=GL.ToolBackground()
 for f in pairs(styledWindows) do if not f.keepOwnBg and type(f.chromeBg)=='table' and f.chromeBg.SetColorTexture then f.chromeBg:SetColorTexture(r,g,b,a) end end
end
function GL.SetToolTheme(changes)
 local t=GL.ToolTheme()
 if changes.preset then t.preset=changes.preset end
 if type(changes.custom)=='table' then t.custom={math.max(0,math.min(1,tonumber(changes.custom[1]) or 0)),math.max(0,math.min(1,tonumber(changes.custom[2]) or 0)),math.max(0,math.min(1,tonumber(changes.custom[3]) or 0))};t.preset='custom' end
 if changes.alpha then t.alpha=math.max(.2,math.min(1,tonumber(changes.alpha) or t.alpha)) end
 GL.ApplyToolTheme();return t
end
-- WoW-Farbwähler öffnen (neue und alte API); onChange(r,g,b) bei jeder Änderung, onCancel(r,g,b) mit den Ausgangswerten.
function GL.OpenColorPicker(r,g,b,onChange,onCancel)
 if not ColorPickerFrame then return false end
 local function current() if ColorPickerFrame.GetColorRGB then return ColorPickerFrame:GetColorRGB() end;return r,g,b end
 local function apply() onChange(current()) end
 local function cancel() if onCancel then onCancel(r,g,b) end end
 if ColorPickerFrame.SetupColorPickerAndShow then ColorPickerFrame:SetupColorPickerAndShow({r=r,g=g,b=b,hasOpacity=false,swatchFunc=apply,cancelFunc=cancel})
 else ColorPickerFrame.func=apply;ColorPickerFrame.swatchFunc=apply;ColorPickerFrame.opacityFunc=nil;ColorPickerFrame.hasOpacity=false;ColorPickerFrame.cancelFunc=cancel;ColorPickerFrame.previousValues={r=r,g=g,b=b};ColorPickerFrame:SetColorRGB(r,g,b);ColorPickerFrame:Hide();ColorPickerFrame:Show() end
 return true
end
local TOOL_TEMPLATE_CHROME={'TitleBg','TitleText','CloseButton','Bg','NineSlice','Inset','TopEdge','BottomEdge','LeftEdge','RightEdge','TopLeftCorner','TopRightCorner','BottomLeftCorner','BottomRightCorner','TitleContainer','TopBorder','BottomBorder','LeftBorder','RightBorder','BotLeftCorner','BotRightCorner','TopTileStreaks','InsetBg','PortraitContainer'}
function GL.ToolWindowScale(key,value)
 GL.db.toolScales=GL.db.toolScales or {}
 if value~=nil then GL.db.toolScales[key]=math.max(.5,math.min(1.6,tonumber(value) or 1)) end
 return math.max(.5,math.min(1.6,tonumber(GL.db.toolScales[key]) or 1))
end
function GL.StyleToolWindow(f,opts)
 opts=opts or {};if f.flatStyled then return f end;f.flatStyled=true
 f.chromeExtra=type(f.chromeExtra)=='table' and f.chromeExtra or {}
 -- Vorlagenteile (Rahmen, Titelleiste, Schließen der BasicFrameTemplate) dauerhaft ausblenden
 for _,key in ipairs(TOOL_TEMPLATE_CHROME) do local r=f[key];if type(r)=='table' and r.Hide then r:Hide() end end
 if f.SetBackdrop then f:SetBackdrop(nil) end
 styledWindows[f]=true
 if opts.keepBg then f.keepOwnBg=true else
  if not (type(f.chromeBg)=='table' and f.chromeBg.SetColorTexture) then f.chromeBg=f:CreateTexture(nil,'BACKGROUND');f.chromeBg:SetAllPoints() end
  f.chromeBg:SetColorTexture(GL.ToolBackground())
 end
 -- Feiner Rahmen aus vier Kanten (eine Vollflächen-Textur würde den Hintergrund überdecken).
 for _,edge in ipairs({{'TOPLEFT','TOPRIGHT',0,1},{'BOTTOMLEFT','BOTTOMRIGHT',0,1},{'TOPLEFT','BOTTOMLEFT',1,0},{'TOPRIGHT','BOTTOMRIGHT',1,0}}) do
  local t=f:CreateTexture(nil,'BORDER');t:SetPoint(edge[1],f,edge[1],edge[3]==1 and (edge[1]:find('LEFT') and -1 or 1) or 0,edge[4]==1 and (edge[1]:find('TOP') and 1 or -1) or 0)
  t:SetPoint(edge[2],f,edge[2],edge[3]==1 and (edge[2]:find('LEFT') and -1 or 1) or 0,edge[4]==1 and (edge[2]:find('TOP') and 1 or -1) or 0)
  if edge[3]==1 then t:SetWidth(1) else t:SetHeight(1) end
  t:SetColorTexture(GL.TOOL_BORDER[1],GL.TOOL_BORDER[2],GL.TOOL_BORDER[3],GL.TOOL_BORDER[4]);f.chromeExtra[#f.chromeExtra+1]=t
 end
 if opts.title then
  local t=f:CreateFontString(nil,'OVERLAY','GameFontNormalLarge');t:SetPoint('TOPLEFT',14,-10);t:SetJustifyH('LEFT');t:SetText(opts.title);t:SetTextColor(1,.8,.25);f.chromeTitle=t
 end
 if opts.close~=false then
  if opts.replaceClose and type(f.chromeClose)=='table' and f.chromeClose.Hide then f.chromeClose:Hide() end
  if opts.replaceClose or not (type(f.chromeClose)=='table') then
   local b=CreateFrame('Button',nil,f);b:SetSize(22,22);b:SetPoint('TOPRIGHT',-8,-8);b:SetFrameLevel(f:GetFrameLevel()+5)
   local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.12,.22,.26,1)
   local l=b:CreateFontString(nil,'OVERLAY','GameFontHighlight');l:SetPoint('CENTER');l:SetText('×')
   b:SetScript('OnEnter',function() bg:SetColorTexture(.2,.32,.34,1) end);b:SetScript('OnLeave',function() bg:SetColorTexture(.12,.22,.26,1) end)
   b:SetScript('OnClick',function() f:Hide() end);f.chromeClose=b
  end
 end
 if opts.scale==false then return f end
 -- Griff unten rechts: Ziehen ändert die Skalierung (Layouts bleiben unverändert), Wert wird gespeichert.
 local key=opts.key or (f.GetName and f:GetName()) or 'tool'
 local getScale=opts.getScale or function() return GL.ToolWindowScale(key) end
 local setScale=opts.setScale or function(v) f:SetScale(GL.ToolWindowScale(key,v)) end
 if not opts.getScale then f:SetScale(GL.ToolWindowScale(key)) end
 local grip=CreateFrame('Button',nil,f);grip:SetPoint('BOTTOMRIGHT',-4,4);grip:SetSize(22,22);grip:SetFrameLevel(f:GetFrameLevel()+5)
 grip:SetNormalTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up');grip:SetHighlightTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight');grip:SetPushedTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down')
 f.chromeExtra[#f.chromeExtra+1]=grip;f.resizeGrip=grip
 local dragging
 grip:SetScript('OnMouseDown',function(_,button)
  if button~='LeftButton' or InCombatLockdown() then return end
  local x,y=GetCursorPosition();local ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale();local left,top=f:GetLeft()*ratio,f:GetTop()*ratio
  f:ClearAllPoints();f:SetPoint('TOPLEFT',UIParent,'BOTTOMLEFT',left,top)
  dragging={x=x,y=y,scale=getScale(),width=f:GetWidth()*f:GetEffectiveScale(),height=f:GetHeight()*f:GetEffectiveScale(),left=left,top=top}
 end)
 local function stop() if dragging then dragging=nil;if opts.onStop then opts.onStop() end end end
 grip:SetScript('OnMouseUp',stop);f:HookScript('OnHide',stop)
 grip:SetScript('OnUpdate',function()
  if not dragging then return end
  if InCombatLockdown() or not IsMouseButtonDown('LeftButton') then stop();return end
  local x,y=GetCursorPosition();local dx=(x-dragging.x)/math.max(1,dragging.width);local dy=(dragging.y-y)/math.max(1,dragging.height)
  setScale(dragging.scale*(1+(math.abs(dx)>math.abs(dy) and dx or dy)))
  local ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale();f:ClearAllPoints();f:SetPoint('TOPLEFT',UIParent,'BOTTOMLEFT',dragging.left/ratio,dragging.top/ratio)
 end)
 grip:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_TOP');GameTooltip:SetText('Fenstergröße');GameTooltip:AddLine('Ecke ziehen. Die Größe wird gespeichert.',1,1,1,true);GameTooltip:Show() end)
 grip:SetScript('OnLeave',function() GameTooltip:Hide() end)
 return f
end
