local _,GL=...
-- Gildenbank-Export: Bank und Taschen des aktuellen Charakters als Text für lichtloot.de (Gildenleitung → Gildenbank).
local function encode(s)
 return (tostring(s or ''):gsub('[^%w%._%-]',function(c) return string.format('%%%02X',c:byte()) end))
end
local function bagCounts()
 local counts={};local api=C_Container or {};local size=api.GetContainerNumSlots or GetContainerNumSlots;local info=api.GetContainerItemInfo or GetContainerItemInfo;local ids=api.GetContainerItemID or GetContainerItemID
 if not size or not info then return counts end
 for bag=0,(NUM_BAG_SLOTS or 4) do for slot=1,(size(bag) or 0) do
  local id,n
  if api.GetContainerItemInfo then local item=info(bag,slot);if item then id=item.itemID or ids and ids(bag,slot);n=item.stackCount end
  else local _,count,_,_,_,_,link=info(bag,slot);id=ids and ids(bag,slot) or GL.GearItemID(link);n=count end
  if id then counts[id]=(counts[id] or 0)+(n or 1) end
 end end
 return counts
end
local function itemName(id)
 local name=GetItemInfo and GetItemInfo(id)
 if not name and C_Item and C_Item.GetItemInfo then name=C_Item.GetItemInfo(id) end
 if not name and C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
 return name
end
-- Bestände aus GBankClassic (Revived) lesen, falls das Addon geladen ist. Die Daten liegen komprimiert in dessen SavedVariables.
local function decompress(encoded)
 local LD=LibStub and LibStub:GetLibrary('LibDeflate',true);local LS=LibStub and LibStub:GetLibrary('LibSerialize',true)
 if not LD or not LS or type(encoded)~='string' then return nil end
 local ok,compressed=pcall(LD.DecodeForPrint,LD,encoded);if not ok or not compressed then return nil end
 local ok2,serialized=pcall(LD.DecompressDeflate,LD,compressed);if not ok2 or not serialized then return nil end
 local ok3,success,data=pcall(LS.Deserialize,LS,serialized);if ok3 and success and type(data)=='table' then return data end
end
function GL.GBankClassicAlts()
 local db=_G.GBCR_DB_V30011;local guilds=db and db.global and db.global.guilds;if type(guilds)~='table' then return nil end
 local guildName=GetGuildInfo('player');local out={};local roster={}
 for _,g in pairs(guilds) do
  if type(g)=='table' and (not guildName or g.guildName==guildName) then
   for _,n in ipairs((g.roster or {}).alts or {}) do roster[#roster+1]=tostring(n) end
   for altName,alt in pairs(g.alts or {}) do
    if type(alt)=='table' then
     local items=alt.items;if type(items)~='table' and alt.itemsCompressed then items=decompress(alt.itemsCompressed) end
     if type(items)=='table' then
      local counts={}
      for _,item in ipairs(items) do
       if type(item)=='table' then
        local id=tonumber(tostring(item.itemString or ''):match('^(%d+)')) or tonumber(item.itemId)
        if id and id>0 then counts[id]=(counts[id] or 0)+(tonumber(item.itemCount) or 1) end
       end
      end
      local name,realm=tostring(altName):match('^([^%-]+)%-?(.*)$')
      out[#out+1]={name=name,realm=(realm~='' and realm) or g.realm or GetRealmName(),counts=counts}
     end
    end
   end
  end
 end
 table.sort(out,function(a,b) return a.name<b.name end)
 return out,roster
end
local function block(guild,name,realm,stamp,counts)
 local lines={table.concat({'GLB1',tostring(guild or ''),encode(name),encode(realm),tostring(stamp)},';')}
 local ids={};for id in pairs(counts) do ids[#ids+1]=id end;table.sort(ids)
 local missing=0
 for _,id in ipairs(ids) do local label=itemName(id);if not label then missing=missing+1 end;lines[#lines+1]=id..';'..counts[id]..';'..encode(label or '') end
 return lines,#ids,missing
end
function GL.GuildBankExport()
 local guild=GL.db.selectedGuild;local now=GetServerTime()
 local name,realm=UnitFullName('player');realm=realm and realm~='' and realm or GetRealmName()
 local C=GL.RaidChecklist;local store=C and C.Store();local bank=store and store.bank
 local alts,roster=GL.GBankClassicAlts()
 local lines,total,missing,sources={},0,0,{}
 if alts and #alts>0 then
  if roster and #roster>0 then local r={};for _,n in ipairs(roster) do r[#r+1]=encode(n) end;lines[#lines+1]='GLBROSTER;'..table.concat(r,';') end
  for _,alt in ipairs(alts) do
   local l,n,m=block(guild,alt.name,alt.realm,now,alt.counts);for _,x in ipairs(l) do lines[#lines+1]=x end;total=total+n;missing=missing+m;sources[#sources+1]=alt.name
  end
 end
 local own=false
 if bank and bank.counts then
  own=true;for _,s in ipairs(sources) do if s:lower()==tostring(name):lower() then own=false end end
 end
 if own then
  local counts={};for id,n in pairs(bank.counts) do counts[id]=(counts[id] or 0)+n end
  for id,n in pairs(bagCounts()) do counts[id]=(counts[id] or 0)+n end
  local l,n,m=block(guild,name,realm,now,counts);for _,x in ipairs(l) do lines[#lines+1]=x end;total=total+n;missing=missing+m;sources[#sources+1]=name..' (eigene Bank)'
 end
 if #lines==0 then error('Noch kein Bankbestand erfasst. Bitte mit dem Bankcharakter die Bank öffnen und /gle bank erneut ausführen, oder GBankClassic mit synchronisierten Bankcharakteren laden.') end
 local age=bank and bank.at and (now-bank.at) or 0
 return table.concat(lines,'\n'),total,missing,age,sources
end
