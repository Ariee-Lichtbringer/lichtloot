local _,GL=...
-- Gildenbank-Export: Bank und Taschen des aktuellen Charakters als Text für lichtloot.de (Gildenleitung → Gildenbank).
local function encode(s)
 return (tostring(s or ''):gsub('[^%w%._%-]',function(c) return string.format('%%%02X',c:byte()) end))
end
local function bagCounts()
 local counts={};local api=C_Container or {};local size=api.GetContainerNumSlots or GetContainerNumSlots;local info=api.GetContainerItemInfo or GetContainerItemInfo;local ids=api.GetContainerItemID or GetContainerItemID
 if not size or not info then return counts end
 for bag=0,(NUM_BAG_SLOTS or 4) do for slot=1,(size(bag) or 0) do
  local id,n
  if api.GetContainerItemInfo then local item=info(bag,slot);if item then id=item.itemID or ids and ids(bag,slot);n=item.stackCount end
  else local _,count,_,_,_,_,link=info(bag,slot);id=ids and ids(bag,slot) or GL.GearItemID(link);n=count end
  if id then counts[id]=(counts[id] or 0)+(n or 1) end
 end end
 return counts
end
local function itemName(id)
 local name=GetItemInfo and GetItemInfo(id)
 if not name and C_Item and C_Item.GetItemInfo then name=C_Item.GetItemInfo(id) end
 if not name and C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
 return name
end
function GL.GuildBankExport()
 local C=GL.RaidChecklist;local store=C and C.Store();local bank=store and store.bank
 if not bank or not bank.counts then error('Noch kein Bankbestand erfasst. Bitte mit diesem Charakter die Bank öffnen, danach /gle bank erneut ausführen.') end
 local counts={};for id,n in pairs(bank.counts) do counts[id]=(counts[id] or 0)+n end
 for id,n in pairs(bagCounts()) do counts[id]=(counts[id] or 0)+n end
 local name,realm=UnitFullName('player');realm=realm and realm~='' and realm or GetRealmName()
 local lines={table.concat({'GLB1',tostring(GL.db.selectedGuild or ''),encode(name),encode(realm),tostring(GetServerTime())},';')}
 local ids={};for id in pairs(counts) do ids[#ids+1]=id end;table.sort(ids)
 local missing=0
 for _,id in ipairs(ids) do local label=itemName(id);if not label then missing=missing+1 end;lines[#lines+1]=id..';'..counts[id]..';'..encode(label or '') end
 local age=GetServerTime()-(bank.at or 0)
 return table.concat(lines,'\n'),#ids,missing,age
end
