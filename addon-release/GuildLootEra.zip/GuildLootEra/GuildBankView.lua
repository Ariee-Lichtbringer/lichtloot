local _,GL=...
-- Gildenbank-Fenster: Bestand der Bankcharaktere (über GuildLoot Sync), Anträge und Export.
local V={};GL.GuildBankView=V
local window,tab,searchBox,gridFrame,detailFrame,listFrame,exportBox,statusText
local state={tab='stock',search='',category=nil,character=nil,selected=nil,page=0}
local COLS,ROWS,SIZE,GAP=7,6,44,6
local classNames={[0]='Verbrauchbar',[1]='Behälter',[2]='Waffe',[3]='Edelstein',[4]='Rüstung',[5]='Reagenz',[6]='Projektil',[7]='Handwerkswaren',[8]='Verbesserung',[9]='Rezept',[11]='Köcher',[12]='Quest',[13]='Schlüssel',[15]='Verschiedenes'}
local function safe(s) return tostring(s or ''):gsub('|','||') end
local function data()
 local p=(GL.db and GL.db.guildProfiles or {})[GL.db and GL.db.selectedGuild];local bank=p and p.activeRaids and p.activeRaids.guildBank
 if type(bank)~='table' then return nil end
 return bank
end
local function itemInfo(id)
 local name,link,quality,_,_,_,_,_,_,icon,_,classID=GetItemInfo(id)
 if not name and GetItemInfoInstant then local _,_,_,_,iconInstant,cid=GetItemInfoInstant(id);icon=icon or iconInstant;classID=classID or cid end
 if not name and C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
 return name,link,quality,icon,classID
end
local function category(id)
 local _,_,_,_,classID=itemInfo(id)
 if classID==nil then return 'Verschiedenes' end
 if GetItemClassInfo then local n=GetItemClassInfo(classID);if n and n~='' then return n end end
 return classNames[classID] or 'Verschiedenes'
end
local function label(parent,text,x,y,w,font)
 local t=parent:CreateFontString(nil,'OVERLAY',font or 'GameFontHighlightSmall');t:SetPoint('TOPLEFT',x,y);if w then t:SetWidth(w) end;t:SetJustifyH('LEFT');t:SetText(text or '');return t
end
local function button(parent,text,x,y,w,fn,h)
 local b=CreateFrame('Button',nil,parent);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,h or 24)
 b.bg=b:CreateTexture(nil,'BACKGROUND');b.bg:SetAllPoints();b.bg:SetColorTexture(.12,.20,.26,.95)
 b.label=b:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');b.label:SetPoint('CENTER');b.label:SetText(text);b:SetScript('OnClick',fn)
 b:SetScript('OnEnter',function(self) self.bg:SetColorTexture(.2,.32,.4,1) end);b:SetScript('OnLeave',function(self) self.bg:SetColorTexture(self.active and .17 or .12,self.active and .34 or .20,self.active and .44 or .26,.95) end)
 function b:Select(on) self.active=on;self.bg:SetColorTexture(on and .17 or .12,on and .34 or .20,on and .44 or .26,.95);self.label:SetTextColor(on and 1 or .82,on and .95 or .88,on and .75 or .92) end
 return b
end
local function visibleItems()
 local bank=data();if not bank then return {} end
 local needle=state.search:lower();local out={}
 for _,item in ipairs(bank.items or {}) do
  local ok=true
  if state.category and category(item.itemId)~=state.category then ok=false end
  if ok and state.character then local found=false;for _,s in ipairs(item.stacks or {}) do if s.name==state.character and (s.quantity or 0)>0 then found=true end end;ok=found end
  if ok and needle~='' then local name=(itemInfo(item.itemId)) or item.name or '';ok=name:lower():find(needle,1,true)~=nil or tostring(item.itemId)==needle end
  if ok then out[#out+1]=item end
 end
 table.sort(out,function(a,b) local qa=select(3,itemInfo(a.itemId)) or 1;local qb=select(3,itemInfo(b.itemId)) or 1;if qa~=qb then return qa>qb end;return (a.name or '')<(b.name or '') end)
 return out
end
local sideButtons={}
local function refreshSide()
 for _,b in ipairs(sideButtons) do b:Hide() end;local i=0
 local bank=data();local counts,order={},{}
 for _,item in ipairs(bank and bank.items or {}) do local c=category(item.itemId);if not counts[c] then counts[c]=0;order[#order+1]=c end;counts[c]=counts[c]+1 end
 table.sort(order)
 local function add(text,on,fn) i=i+1;local b=sideButtons[i];if not b then b=button(window.side,'',6,0,158,nil);sideButtons[i]=b end;b:ClearAllPoints();b:SetPoint('TOPLEFT',6,-(i-1)*27-6);b.label:SetText(text);b:SetScript('OnClick',fn);b:Select(on);b:Show() end
 add('Alles ('..#(bank and bank.items or {})..')',state.category==nil,function() state.category=nil;state.page=0;V.Refresh() end)
 for _,c in ipairs(order) do local cat=c;add(c..' ('..counts[c]..')',state.category==c,function() state.category=cat;state.page=0;V.Refresh() end) end
 i=i+1;local head=sideButtons[i];if not head then head=button(window.side,'',6,0,158,nil);sideButtons[i]=head end;head:ClearAllPoints();head:SetPoint('TOPLEFT',6,-(i-1)*27-14);head.label:SetText('Bankcharakter');head.bg:SetColorTexture(0,0,0,0);head:SetScript('OnClick',nil);head:Show()
 add('Alle',state.character==nil,function() state.character=nil;state.page=0;V.Refresh() end)
 for _,c in ipairs(bank and bank.characters or {}) do local name=c.name;add(name..(c.observedAt and '' or ' (kein Stand)'),state.character==name,function() state.character=name;state.page=0;V.Refresh() end) end
end
local tiles={}
local function tile(i)
 local b=tiles[i];if b then return b end
 b=CreateFrame('Button',nil,gridFrame);b:SetSize(SIZE,SIZE);tiles[i]=b
 b.border=b:CreateTexture(nil,'BACKGROUND');b.border:SetAllPoints();b.border:SetColorTexture(1,1,1,1)
 b.icon=b:CreateTexture(nil,'ARTWORK');b.icon:SetPoint('TOPLEFT',2,-2);b.icon:SetPoint('BOTTOMRIGHT',-2,2)
 b.count=b:CreateFontString(nil,'OVERLAY','NumberFontNormal');b.count:SetPoint('BOTTOMRIGHT',-2,2)
 b:SetHighlightTexture('Interface\\Buttons\\ButtonHilight-Square','ADD');b:RegisterForClicks('LeftButtonUp')
 b:SetScript('OnEnter',function(self) if not self.item then return end;GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetItemByID(self.item.itemId);local where={};for _,s in ipairs(self.item.stacks or {}) do where[#where+1]=safe(s.name)..' '..(s.quantity or 0) end;GameTooltip:AddLine(' ');GameTooltip:AddLine('Auf der Gildenbank: '..(self.item.quantity or 0)..(#where>0 and (' · '..table.concat(where,', ')) or ''),.45,.9,.78,true);GameTooltip:AddLine('Linksklick: auswählen · Shift-Klick: verlinken',.7,.7,.7);GameTooltip:Show() end)
 b:SetScript('OnLeave',function() GameTooltip:Hide() end)
 b:SetScript('OnClick',function(self) if not self.item then return end;if IsShiftKeyDown() then local _,link=itemInfo(self.item.itemId);if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end;return end;state.selected=self.item.itemId;V.Refresh() end)
 return b
end
local function refreshGrid()
 local items=visibleItems();local perPage=COLS*ROWS;local pages=math.max(1,math.ceil(#items/perPage));if state.page>=pages then state.page=pages-1 end
 for i=1,perPage do
  local item=items[state.page*perPage+i];local b=tile(i)
  if item then
   local name,_,quality,icon=itemInfo(item.itemId);b.item=item
   b:ClearAllPoints();b:SetPoint('TOPLEFT',gridFrame,'TOPLEFT',((i-1)%COLS)*(SIZE+GAP)+4,-math.floor((i-1)/COLS)*(SIZE+GAP)-4)
   b.icon:SetTexture(icon or 'Interface\\Icons\\INV_Misc_QuestionMark')
   local r,g,bl=1,1,1;if quality and GetItemQualityColor then r,g,bl=GetItemQualityColor(quality) end;b.border:SetColorTexture(r,g,bl,1)
   local qty=item.quantity or 0;if state.character then qty=0;for _,s in ipairs(item.stacks or {}) do if s.name==state.character then qty=qty+(s.quantity or 0) end end end
   b.count:SetText(qty>1 and tostring(qty) or '');b:Show()
  else b.item=nil;b:Hide() end
 end
 window.pageText:SetText(#items==0 and (data() and 'Kein Gegenstand für diese Auswahl.' or 'Noch kein Bestand synchronisiert. GuildLoot Sync ausführen, danach /reload.') or ('Seite '..(state.page+1)..' / '..pages..' · '..#items..' Gegenstände · Mausrad blättert'))
end
local detailRows={}
local function refreshDetail()
 local d=detailFrame;for _,r in ipairs(detailRows) do r:Hide() end
 local bank=data();local item
 for _,it in ipairs(bank and bank.items or {}) do if it.itemId==state.selected then item=it end end
 if not item then d.title:SetText('Gegenstand auswählen');d.title:SetTextColor(.7,.8,.85);d.sub:SetText('Klicke auf einen Gegenstand im Raster.');d.request:Hide();d.amount:Hide();d.amountLabel:Hide();return end
 local name,_,quality=itemInfo(item.itemId);local r,g,b=1,1,1;if quality and GetItemQualityColor then r,g,b=GetItemQualityColor(quality) end
 d.title:SetText(safe(name or item.name or ('Item #'..item.itemId)));d.title:SetTextColor(r,g,b);d.sub:SetText(category(item.itemId)..' · Verfügbar: '..(item.quantity or 0))
 local y=-58;local i=0
 local function row(text,value) i=i+1;local rw=detailRows[i];if not rw then rw=CreateFrame('Frame',nil,d);rw:SetSize(228,18);rw.l=label(rw,'',0,0,150);rw.v=rw:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');rw.v:SetPoint('TOPRIGHT',0,0);detailRows[i]=rw end;rw:ClearAllPoints();rw:SetPoint('TOPLEFT',10,y);rw.l:SetText(text);rw.v:SetText(value);rw:Show();y=y-18 end
 for _,s in ipairs(item.stacks or {}) do row(safe(s.name),tostring(s.quantity or 0)) end
 local open=0;for _,q in pairs(GL.db.outgoingRequests or {}) do if q.kind=='guildbank' and q.payload and q.payload.itemId==item.itemId and not (GL.db.outgoingReceipts or {})[q.id] then open=open+(tonumber(q.payload.quantity) or 0) end end
 for _,req in ipairs(bank.myRequests or {}) do if req.status=='pending' then for _,m in ipairs(req.materials or {}) do if tonumber(m.itemId)==item.itemId then open=open+(tonumber(m.quantity) or 0) end end end end
 if open>0 then row('Deine offenen Anträge',tostring(open)) end
 d.amountLabel:ClearAllPoints();d.amountLabel:SetPoint('TOPLEFT',10,y-8);d.amountLabel:Show();d.amount:ClearAllPoints();d.amount:SetPoint('TOPLEFT',64,y-4);d.amount:Show();d.amount:SetText('1')
 d.request:ClearAllPoints();d.request:SetPoint('TOPLEFT',10,y-40);d.request:Show();d.request:SetEnabled((item.quantity or 0)>0)
 d.request:SetScript('OnClick',function()
  local qty=tonumber(d.amount:GetText());if not qty or qty<1 or qty~=math.floor(qty) then statusText:SetText('Bitte eine gültige Menge eingeben.');return end
  if qty>(item.quantity or 0) then statusText:SetText('Aktuell nicht verfügbar: Auf der Gildenbank liegen nur '..(item.quantity or 0)..' Stück.');return end
  local ok,err=pcall(GL.QueueWebsiteAction,{id='guildbank:'..item.itemId..':'..GetServerTime()},'guildbank',{itemId=item.itemId,quantity=qty,itemName=name or item.name or ''})
  statusText:SetText(ok and ('Antrag vorgemerkt: '..qty..' × '..safe(name or item.name)..'. Mit /reload wird er über GuildLoot Sync an die Gildenleitung übertragen.') or tostring(err):gsub('^.-:%d+: ',''))
  refreshDetail()
 end)
end
local listRows={}
local function refreshList()
 for _,r in ipairs(listRows) do r:Hide() end
 local bank=data();local entries={}
 for _,q in pairs(GL.db.outgoingRequests or {}) do if q.kind=='guildbank' and q.guild==GL.db.selectedGuild and not (GL.db.outgoingReceipts or {})[q.id] then entries[#entries+1]={status='wartet auf Sync',text=(q.payload and q.payload.quantity or '?')..' × '..safe(q.payload and q.payload.itemName or ('Item #'..tostring(q.payload and q.payload.itemId))),at=q.createdAt} end end
 for _,req in ipairs(bank and bank.myRequests or {}) do local parts={};for _,m in ipairs(req.materials or {}) do parts[#parts+1]=(m.quantity or 1)..' × '..safe(m.name) end;entries[#entries+1]={status=req.status=='approved' and 'freigegeben' or req.status=='rejected' and 'abgelehnt' or 'offen',text=#parts>0 and table.concat(parts,', ') or safe(req.itemName),at=req.createdAt,note=req.reviewNote} end
 table.sort(entries,function(a,b) return (tonumber(a.at) or 0)>(tonumber(b.at) or 0) end)
 if #entries==0 then listFrame.empty:SetText('Noch keine Gildenbankanträge.');listFrame.empty:Show() else listFrame.empty:Hide() end
 for i,e in ipairs(entries) do if i>18 then break end
  local r=listRows[i];if not r then r=CreateFrame('Frame',nil,listFrame);r:SetSize(640,26);r.status=label(r,'',0,-6,110);r.text=label(r,'',120,-6,420);r.note=label(r,'',540,-6,100);listRows[i]=r end
  r:ClearAllPoints();r:SetPoint('TOPLEFT',10,-(i-1)*28-10);r.status:SetText(e.status);r.status:SetTextColor(e.status=='freigegeben' and .3 or e.status=='abgelehnt' and 1 or 1,e.status=='freigegeben' and .9 or e.status=='abgelehnt' and .45 or .8,.4)
  r.text:SetText(e.text..(e.at and (' · '..date('%d.%m.%Y',tonumber(e.at) or 0)) or ''));r.note:SetText(e.note and safe(e.note) or '');r:Show()
 end
end
local function refreshExport()
 local ok,text,count,missing,age,sources=pcall(GL.GuildBankExport)
 if not ok then exportBox:SetText('');window.exportInfo:SetText(tostring(text):gsub('^.-:%d+: ',''));return end
 exportBox:SetText(text);window.exportInfo:SetText(count..' Gegenstände ('..table.concat(sources,', ')..'). Text kopieren und auf lichtloot.de unter Gildenleitung → Gildenbank einfügen, oder unten über GuildLoot Sync übertragen.'..(missing>0 and (' '..missing..' Itemnamen fehlen noch.') or ''))
end
function V.Refresh()
 if not window or not window:IsShown() then return end
 for key,b in pairs(window.tabs) do b:Select(key==state.tab) end
 window.side:SetShown(state.tab=='stock');gridFrame:SetShown(state.tab=='stock');detailFrame:SetShown(state.tab=='stock');window.pageText:SetShown(state.tab=='stock');searchBox:SetShown(state.tab=='stock')
 listFrame:SetShown(state.tab=='requests');window.exportPanel:SetShown(state.tab=='export')
 local bank=data();window.info:SetText(bank and ('Stand '..date('%d.%m.%Y %H:%M',tonumber(bank.at) or 0)..' · '..#(bank.items or {})..' Gegenstände'..(bank.note and bank.note~='' and (' · '..safe(bank.note)) or '')) or 'Noch kein Bestand synchronisiert.')
 if state.tab=='stock' then refreshSide();refreshGrid();refreshDetail() elseif state.tab=='requests' then refreshList() else refreshExport() end
end
function V.Toggle(tabName)
 if InCombatLockdown() then print('GuildLoot: Gildenbank bitte außerhalb des Kampfes öffnen.');return end
 if not window then
  window=CreateFrame('Frame','GuildLootEraGuildBank',UIParent,'BackdropTemplate');window:SetSize(920,600);window:SetPoint('CENTER');window:SetFrameStrata('DIALOG');window:SetClampedToScreen(true);window:SetMovable(true);window:EnableMouse(true)
  window:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=14});window:SetBackdropColor(.025,.045,.065,.97);window:SetBackdropBorderColor(.35,.45,.55,1)
  local drag=CreateFrame('Frame',nil,window);drag:SetPoint('TOPLEFT');drag:SetSize(860,36);drag:EnableMouse(true);drag:RegisterForDrag('LeftButton');drag:SetScript('OnDragStart',function() window:StartMoving() end);drag:SetScript('OnDragStop',function() window:StopMovingOrSizing() end)
  local title=label(window,'GuildLoot · Gildenbank',16,-12,400,'GameFontNormalLarge');title:SetTextColor(.45,.9,.78)
  window.info=label(window,'',300,-16,560);window.info:SetJustifyH('RIGHT');window.info:ClearAllPoints();window.info:SetPoint('TOPRIGHT',-44,-16)
  button(window,'×',884,-8,26,function() window:Hide() end)
  window.tabs={}
  local tabsDef={{'stock','Bestand'},{'requests','Meine Anträge'},{'export','Export'}}
  for i,t in ipairs(tabsDef) do local key=t[1];window.tabs[key]=button(window,t[2],16+(i-1)*130,-40,124,function() state.tab=key;V.Refresh() end) end
  window.side=CreateFrame('Frame',nil,window);window.side:SetPoint('TOPLEFT',12,-72);window.side:SetSize(170,510)
  searchBox=CreateFrame('EditBox',nil,window,'InputBoxTemplate');searchBox:SetPoint('TOPLEFT',196,-70);searchBox:SetSize(300,24);searchBox:SetAutoFocus(false);searchBox:SetScript('OnTextChanged',function(self) state.search=self:GetText() or '';state.page=0;refreshGrid() end);searchBox:SetScript('OnEscapePressed',function(self) self:ClearFocus() end)
  local hint=label(window,'Suche',196,-56,200);hint:SetTextColor(.6,.7,.8)
  gridFrame=CreateFrame('Frame',nil,window);gridFrame:SetPoint('TOPLEFT',192,-100);gridFrame:SetSize(COLS*(SIZE+GAP)+8,ROWS*(SIZE+GAP)+8);gridFrame:EnableMouseWheel(true)
  gridFrame:SetScript('OnMouseWheel',function(_,delta) state.page=math.max(0,state.page-delta);refreshGrid() end)
  window.pageText=label(window,'',196,-416,360);window.pageText:SetTextColor(.6,.7,.8)
  detailFrame=CreateFrame('Frame',nil,window,'BackdropTemplate');detailFrame:SetPoint('TOPLEFT',560,-70);detailFrame:SetSize(346,510);detailFrame:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8'});detailFrame:SetBackdropColor(.04,.09,.15,.9)
  detailFrame.title=label(detailFrame,'',10,-10,326,'GameFontNormal');detailFrame.sub=label(detailFrame,'',10,-32,326);detailFrame.sub:SetTextColor(.65,.75,.85)
  detailFrame.amountLabel=label(detailFrame,'Menge',10,-200,50);detailFrame.amount=CreateFrame('EditBox',nil,detailFrame,'InputBoxTemplate');detailFrame.amount:SetSize(60,24);detailFrame.amount:SetAutoFocus(false);detailFrame.amount:SetNumeric(true);detailFrame.amount:SetMaxLetters(4);detailFrame.amount:SetScript('OnEscapePressed',function(self) self:ClearFocus() end)
  detailFrame.request=button(detailFrame,'Beantragen',10,-240,326,nil,28);detailFrame.request.bg:SetColorTexture(.23,.17,.06,1);detailFrame.request.label:SetTextColor(1,.88,.55)
  statusText=label(detailFrame,'',10,-300,326);statusText:SetTextColor(.45,.9,.78);statusText:SetHeight(120);statusText:SetJustifyV('TOP')
  local foot=label(detailFrame,'Anträge werden bei der nächsten Synchronisierung (/reload) an lichtloot.de übertragen. Die Gildenleitung gibt sie dort frei; freigegebene Anträge stehen unter „Meine Anträge“.',10,-430,326);foot:SetTextColor(.55,.65,.75)
  listFrame=CreateFrame('Frame',nil,window);listFrame:SetPoint('TOPLEFT',12,-72);listFrame:SetSize(896,510);listFrame.empty=label(listFrame,'',10,-10,600)
  window.exportPanel=CreateFrame('Frame',nil,window);window.exportPanel:SetPoint('TOPLEFT',12,-72);window.exportPanel:SetSize(896,510)
  window.exportInfo=label(window.exportPanel,'',4,-4,880);window.exportInfo:SetHeight(44);window.exportInfo:SetJustifyV('TOP')
  local scroll=CreateFrame('ScrollFrame',nil,window.exportPanel,'UIPanelScrollFrameTemplate');scroll:SetPoint('TOPLEFT',4,-56);scroll:SetSize(860,380)
  exportBox=CreateFrame('EditBox',nil,scroll);exportBox:SetMultiLine(true);exportBox:SetWidth(840);exportBox:SetFontObject(ChatFontSmall);exportBox:SetAutoFocus(false);exportBox:SetMaxLetters(0);exportBox:SetScript('OnEscapePressed',function(self) self:ClearFocus() end);scroll:SetScrollChild(exportBox)
  button(window.exportPanel,'Text markieren (Strg+C)',4,-446,220,function() exportBox:SetFocus();exportBox:HighlightText() end)
  button(window.exportPanel,'Über GuildLoot Sync übertragen',232,-446,260,function()
   local text=exportBox:GetText() or '';if text=='' then window.exportInfo:SetText('Kein Export vorhanden.');return end
   local ok,err=pcall(GL.QueueWebsiteAction,{id='guildbankexport:'..GetServerTime()},'guildbankexport',{text=text})
   window.exportInfo:SetText(ok and 'Export vorgemerkt. Mit /reload überträgt GuildLoot Sync den Bestand an lichtloot.de.' or tostring(err):gsub('^.-:%d+: ',''))
  end)
  window:SetScript('OnHide',function() GameTooltip:Hide() end)
 end
 if tabName then state.tab=tabName end
 if window:IsShown() and not tabName then window:Hide() else window:Show();V.Refresh() end
end
function GL.ToggleGuildBank(tabName) V.Toggle(tabName) end

-- Mini-Symbol: frei verschiebbares Gildenbank-Symbol wie bei Berufe und Raidcheck.
local launcher
local function shortcut() GL.db.guildBankShortcut=GL.db.guildBankShortcut or {};return GL.db.guildBankShortcut end
function GL.InitializeGuildBankShortcut()
 if launcher or not GL.db then return end
 local s=shortcut();launcher=CreateFrame('Button',nil,UIParent);launcher:SetSize(36,36);launcher:SetFrameStrata('HIGH');launcher:SetClampedToScreen(true);launcher:SetMovable(true);launcher:EnableMouse(true);launcher:RegisterForDrag('LeftButton')
 local texture=launcher:CreateTexture(nil,'ARTWORK');texture:SetAllPoints();texture:SetTexture('Interface\\AddOns\\GuildLootEra\\Media\\GuildBank')
 launcher:SetPoint('CENTER',UIParent,'CENTER',s.x or 64,s.y or 0)
 launcher:SetScript('OnDragStart',launcher.StartMoving);launcher:SetScript('OnDragStop',function(self) self:StopMovingOrSizing();local x,y=self:GetCenter();local px,py=UIParent:GetCenter();local p=shortcut();p.x=x-px;p.y=y-py end)
 launcher:SetScript('OnClick',function() GL.ToggleGuildBank() end)
 launcher:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetText('Gildenbank · Klicken zum Öffnen, ziehen zum Verschieben');GameTooltip:Show() end);launcher:SetScript('OnLeave',function() GameTooltip:Hide() end)
 launcher:SetShown(s.shown==true)
end
function GL.ToggleGuildBankShortcut()
 GL.InitializeGuildBankShortcut();local s=shortcut();if s.x==nil and s.y==nil then launcher:ClearAllPoints();launcher:SetPoint('CENTER',UIParent,'CENTER',64,0) end
 s.shown=not launcher:IsShown();launcher:SetShown(s.shown);return s.shown
end
function GL.GuildBankShortcutShown() local s=GL.db and GL.db.guildBankShortcut;return s and s.shown==true end
local login=CreateFrame('Frame');login:RegisterEvent('PLAYER_LOGIN');login:SetScript('OnEvent',function() GL.InitializeGuildBankShortcut() end)
