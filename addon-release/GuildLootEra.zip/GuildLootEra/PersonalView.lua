local _,GL=...
local labels={recruit='Rekrutenstatus',p1p3='P1–P3',mc='MC',bwl='BWL',aq40='AQ40',aq20='AQ20',naxx='Naxx',ony='Onyxia',zg='ZG',['zg-mittwoch']='ZG Mittwoch',['zg-prime']='ZG Prime',['zg-late']='ZG Late'}
local releaseOrder={'recruit','p1p3','mc','bwl','ony','zg','aq20','aq40','naxx','zg-mittwoch','zg-prime','zg-late'}
local function same(a,b) return tostring(a or ''):lower():gsub('%s','')==tostring(b or ''):lower():gsub('%s','') end

local classTokens={Krieger='WARRIOR',Druide='DRUID',Schurke='ROGUE',Magier='MAGE',Priester='PRIEST',Paladin='PALADIN',['Jäger']='HUNTER',Hexenmeister='WARLOCK',Schamane='SHAMAN'}
function GL.CharacterIdentity(p)
    if not p then return nil,'' end
    local token,spec
    local data=((GL.db.guildProfiles or {})[GL.db.selectedGuild] or {}).activeRaids or {}
    for _,r in ipairs(data.professionCharacters or {}) do if same(r.player,p.player) and same(r.realm,p.realm) then token=classTokens[r.className] or r.className;break end end
    for _,r in ipairs(data.ownPrios or {}) do if same(r.player,p.player) and same(r.realm,p.realm) then token=classTokens[r.className] or r.className;spec=r.spec;break end end
    -- Talent APIs describe only the currently played character, never another selected profile.
    if UnitName and UnitClass and GetRealmName and same(UnitName('player'),p.player) and same(GetRealmName(),p.realm) then
        local _,current=UnitClass('player');token=current
        if GetTalentTabInfo then
            local points,total,best,bestName={},0,-1,''
            for i=1,3 do local name,_,spent=GetTalentTabInfo(i);spent=tonumber(spent) or 0;points[i]=spent;total=total+spent;if spent>best then best=spent;bestName=name or '' end end
            spec=total>0 and (bestName..' · '..table.concat(points,'/')) or 'Noch keine Talentpunkte verteilt'
        end
    end
    if token=='' then token=nil end
    return token,spec and spec~='' and spec or 'Skillung nicht verfügbar'
end
function GL.PersonalDashboard()
    local p=GL.DisplayProfile();local data={profile=p,releases={},prios={},points={},total=0,approved=0}
    if not p then return data end
    local seen={}
    local function release(key) local value=p.releases[key];if value then seen[key]=true;data.releases[#data.releases+1]={name=labels[key] or key,status=value};if value=='approved' then data.approved=data.approved+1 end end end
    for _,key in ipairs(releaseOrder) do release(key) end
    local extra={};for key in pairs(p.releases) do if not seen[key] then extra[#extra+1]=key end end;table.sort(extra);for _,key in ipairs(extra) do release(key) end
    for _,r in ipairs(p.history or {}) do data.prios[#data.prios+1]={name=r.itemName,detail=r.raid..' · '..r.raidDate..' · '..r.priority,createdAt=r.createdAt} end
    if #data.prios==0 and GL.db.priorities then
        local raid=GL.db.priorities
        for _,r in ipairs(raid.rows) do if r.priority~='Punkte' and same(r.player,p.player) and same(r.realm,p.realm) then
            data.prios[#data.prios+1]={name=r.itemName,itemId=r.itemId,detail=raid.raidName..' · '..raid.raidDate..' · '..r.priority,createdAt=r.createdAt}
        end end
    end
    for _,key in ipairs(GL.PointRaids) do local raid=GL.db.pointRaids and GL.db.pointRaids[key]
        for _,r in ipairs(raid and raid.rows or {}) do if same(r.player,p.player) and same(r.realm,p.realm) then
            data.points[#data.points+1]={name=r.itemName,itemId=r.itemId,detail=labels[key] or key,points=r.points};data.total=data.total+(r.points or 0)
        end end
    end
    table.sort(data.points,function(a,b) if a.detail~=b.detail then return a.detail<b.detail end;if a.name~=b.name then return a.name<b.name end;return a.itemId<b.itemId end)
    return data
end
function GL.CreatePersonalView(parent,actions)
    local view=CreateFrame('Frame',nil,parent);view:SetPoint('TOPLEFT',24,-134);view:SetSize(890,556)
    local function label(owner,x,y,w,size)
        local t=owner:CreateFontString(nil,'OVERLAY','GameFontHighlight');t:SetFont(STANDARD_TEXT_FONT,size or 13);t:SetPoint('TOPLEFT',x,y);t:SetWidth(w);t:SetJustifyH('LEFT');t:SetWordWrap(false);return t
    end
    local function surface(owner,x,y,w,h,r,g,b)
        local f=CreateFrame('Frame',nil,owner);f:SetPoint('TOPLEFT',x,y);f:SetSize(w,h);f.bg=f:CreateTexture(nil,'BACKGROUND');f.bg:SetAllPoints();f.bg:SetColorTexture(r or .06,g or .1,b or .14,.96);return f
    end
    local function button(owner,title,x,y,w,fn)
        local b=CreateFrame('Button',nil,owner);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,28)
        local bg=b:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.12,.22,.26,1)
        b.text=label(b,6,-6,w-12,12);b.text:SetText(title);b.text:SetJustifyH('CENTER')
        b:SetScript('OnClick',fn);b:SetScript('OnEnter',function() bg:SetColorTexture(.2,.32,.34,1) end);b:SetScript('OnLeave',function() bg:SetColorTexture(.12,.22,.26,1) end);if GL.GateSyncButton then GL.GateSyncButton(b,title) end;return b
    end
    local header=surface(view,0,0,890,72)
    local classIcon=header:CreateTexture(nil,'ARTWORK');classIcon:SetPoint('TOPLEFT',16,-10);classIcon:SetSize(26,26)
    local name=label(header,50,-10,560,21);name:SetTextColor(.15,.95,.83)
    local specialization=label(header,50,-34,560,11)
    local subtitle=label(header,16,-54,600,10);subtitle:SetTextColor(.64,.74,.82)
    button(header,'Charakter wechseln',636,-8,150,function() GL.CyclePersonalProfile();view:Refresh(true) end)
    button(header,'Gildenbank',792,-8,84,function() GL.ToggleGuildBank() end)
    button(header,'Ausrüstung',636,-40,92,actions.gear)
    button(header,'Rüstungsteile beantragen',734,-40,142,function() GL.ArmorRequests.Open() end)
    local releaseTitle=label(view,0,-86,600,14);releaseTitle:SetTextColor(1,.8,.25)
    local tiles={};local releasePage=0;local data
    for i=1,12 do
        local tile=surface(view,((i-1)%6)*150,-110-math.floor((i-1)/6)*52,140,46)
        tile.title=label(tile,10,-6,122,12);tile.status=label(tile,10,-25,122,11);tiles[i]=tile
    end
    local function drawReleases()
        releaseTitle:SetText('P0-FREIGABEN   ·   '..data.approved..' freigegeben')
        for i,tile in ipairs(tiles) do local r=data.releases[releasePage*12+i];tile:SetShown(r~=nil)
            if r then
                tile.title:SetText(r.name)
                local approved,pending=r.status=='approved',r.status=='pending'
                tile.bg:SetColorTexture(approved and .06 or .1,approved and .25 or pending and .18 or .13,approved and .18 or .15,1)
                tile.status:SetText(approved and 'Freigegeben' or pending and 'In Prüfung' or 'Offen')
                tile.status:SetTextColor(approved and .45 or pending and 1 or .6,approved and .95 or pending and .8 or .7,approved and .65 or pending and .25 or .78)
            end
        end
        if #data.releases==0 then releaseTitle:SetText('P0-FREIGABEN   ·   noch keine Freigabedaten importiert') end
    end
    local more=button(view,'Weitere Freigaben >',710,-80,180,function() releasePage=(releasePage+1)%math.max(1,math.ceil(#data.releases/12));drawReleases() end)
    local function list(x,title,isPoints)
        local pane=surface(view,x,-230,438,278);local page=0;local rows={};local values={}
        local heading=label(pane,14,-12,400,15);heading:SetTextColor(1,.8,.25)
        local empty=label(pane,14,-63,406,13);empty:SetWordWrap(true);empty:SetHeight(95);empty:SetTextColor(.64,.74,.82)
        local pagination=label(pane,68,-246,300,11);pagination:SetJustifyH('CENTER');pagination:SetTextColor(.6,.7,.78)
        local function render()
            page=math.max(0,math.min(page,math.max(0,math.ceil(#values/4)-1)))
            heading:SetText(title..'  ·  '..#values)
            empty:SetShown(#values==0);empty:SetText(data.profile and (isPoints and 'Noch keine P0+-Punkte für diesen Charakter im Export.' or 'Noch keine eigenen Prios im Export. Trage deine Prios auf der Webseite ein und importiere den neuen Stand.') or 'Importiere deinen persönlichen Export aus Mein Lichtloot/Nachtloot. Deine Daten erscheinen anschließend hier.')
            for i,row in ipairs(rows) do local r=values[page*4+i];row.entry=r;row:SetShown(r~=nil)
                if r then
                    local itemName,_,quality
                    if r.itemId and GL.GearInfo then itemName,_,quality=GL.GearInfo(r.itemId) end
                    local c=quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality]
                    row.name:SetText(itemName or r.name);row.name:SetTextColor(c and c.r or .9,c and c.g or .94,c and c.b or .98)
                    row.detail:SetText(r.detail);row.value:SetText(isPoints and tostring(r.points or 0) or '')
                    row.when:SetText(not isPoints and (r.createdAt and ('Eingetragen: '..date('%d.%m.%Y %H:%M',r.createdAt)) or 'Eintragungszeit nicht enthalten') or '')
                end
            end
            pagination:SetText(#values==0 and 'Keine Einträge' or ('Seite '..(page+1)..' / '..math.ceil(#values/4)))
        end
        for i=1,4 do
            local row=CreateFrame('Button',nil,pane);row:SetPoint('TOPLEFT',10,-40-(i-1)*49);row:SetSize(418,47)
            local bg=row:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.09,.15,.19,1)
            row.name=label(row,8,-4,isPoints and 330 or 400,13);row.detail=label(row,8,-21,400,10);row.detail:SetTextColor(.62,.76,.84)
            row.when=label(row,8,-34,400,10);row.when:SetTextColor(.6,.68,.74)
            row.value=label(row,345,-8,63,19);row.value:SetJustifyH('RIGHT');row.value:SetTextColor(1,.8,.25)
            row:SetScript('OnEnter',function() local r=row.entry;if r then GameTooltip:SetOwner(row,'ANCHOR_RIGHT');if r.itemId then GameTooltip:SetHyperlink('item:'..r.itemId) else GameTooltip:SetText(r.name);if GameTooltip.AddLine then GameTooltip:AddLine(r.detail,1,1,1,true) end end;GameTooltip:Show() end end)
            row:SetScript('OnLeave',function() GameTooltip:Hide() end)
            rows[i]=row
        end
        button(pane,'<',12,-240,42,function() page=page-1;render() end);button(pane,'>',384,-240,42,function() page=page+1;render() end)
        pane:EnableMouseWheel(true);pane:SetScript('OnMouseWheel',function(_,delta) page=page-delta;render() end)
        for _,row in ipairs(rows) do row:EnableMouseWheel(true);row:SetScript('OnMouseWheel',function(_,delta) page=page-delta;render() end) end
        function pane:Refresh(items,reset) values=items;if reset then page=0 end;render() end
        pane.rows=rows;return pane
    end
    local prios=list(0,'MEINE PRIOS',false);local points=list(452,'MEINE P0+-PUNKTE',true)
    local footer=label(view,0,-526,890,12);footer:SetTextColor(.6,.74,.82)
    function view:Refresh(reset)
        data=GL.PersonalDashboard();local p=data.profile
        local token,spec=GL.CharacterIdentity(p);classIcon:SetShown(p~=nil);classIcon:SetTexture(token and ('Interface\\Icons\\ClassIcon_'..token) or 'Interface\\Icons\\INV_Misc_QuestionMark');specialization:SetText(p and spec or '')
        name:SetText(p and (p.player..' – '..p.realm) or 'Willkommen in deinem GuildLoot')
        subtitle:SetText(p and (GL.GuildName(GL.db.selectedGuild)..'  ·  Stand '..date('%d.%m.%Y %H:%M',p.exportedAt)..'  ·  '..data.total..' P0+-Punkte gesamt') or 'Dein Charakter, deine Freigaben und deine Raidplanung an einem Ort.')
        if reset then releasePage=0 end;more:SetShown(#data.releases>12);drawReleases()
        prios:Refresh(data.prios,reset);points:Refresh(data.points,reset)
        footer:SetText('Stand des letzten Imports · Ausrüstung öffnet den aktuell gespielten Charakter · Kalender ergänzt deine importierten Termine.')
    end
    view.prioList=prios;view.pointList=points;view.releaseTiles=tiles
    view:RegisterEvent('GET_ITEM_INFO_RECEIVED');view:RegisterEvent('CHARACTER_POINTS_CHANGED');view:SetScript('OnEvent',function(_,event,_,success) if (event=='CHARACTER_POINTS_CHANGED' or success) and view:IsShown() then view:Refresh(false) end end)
    view:SetScript('OnHide',function() GameTooltip:Hide() end)
    return view
end
