local _,GL=...
local months={'Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'}
function GL.CalendarMonth(year,month,weekStart,filters)
    local first=GL.CalendarCivilDays(year,month,1);local start=weekStart or first-((first+3)%7)
    local days,byDate={},{}
    for i=1,(weekStart and 7 or 42) do local t=date('!*t',(start+i-1)*86400);local key=string.format('%04d-%02d-%02d',t.year,t.month,t.day)
        days[i]={date=key,day=t.day,current=t.month==month,events={}};byDate[key]=days[i]
    end
    local function add(e) if filters and filters[e.kind]==false then return end;local d=byDate[e.date];if d then d.events[#d.events+1]=e end end
    for _,e in ipairs(GL.CalendarPlan(start*86400+43200)) do add(e) end
    local p=GL.DisplayProfile()
    local data=((GL.db.guildProfiles or {})[GL.db.selectedGuild] or {}).activeRaids or {}
    for _,r in ipairs(p and p.calendar or {}) do
        local prio
        for _,owner in ipairs(data.ownPrios or {}) do if p and owner.player==p.player and owner.realm==p.realm then
            for _,row in ipairs(owner.rows or {}) do if row.raidId==r.id or row.externalRaidId==r.id then
                if (row.p0 or '')~='' or row.p0Plus==1 then prio='p0'
                elseif (row.p1 or '')~='' or (row.p2 or '')~='' or (row.p3 or '')~='' then prio='normal' end
            end end
        end end
        add({date=r.date,clock=r.clock,name=r.name,kind='raid',prio=prio,startsAt=r.startsAt,detail=prio=='p0' and 'P0 / P0+ eingetragen' or prio=='normal' and 'P1–P3 eingetragen' or not r.needsPrio and 'Keine Prio erforderlich' or r.hasPrio and 'Prio eingetragen; Typ nach nächster Synchronisierung verfügbar' or 'Prio fehlt – auf der Webseite eintragen'})
    end
    for _,e in ipairs(data.worldbuffs or {}) do add({date=e.date,clock=e.clock or '',name=e.name,kind='worldbuff',startsAt=e.startsAt,detail=e.detail}) end
    if GetNumSavedInstances and GetSavedInstanceInfo then for i=1,GetNumSavedInstances() do
        local name,_,reset,_,locked,_,_,isRaid=GetSavedInstanceInfo(i)
        if locked and isRaid and reset and reset>0 then
            local stamp=GetServerTime()+reset;local t=stamp+GL.CalendarBerlinOffset(stamp)
            add({date=date('!%Y-%m-%d',t),clock=date('!%H:%M',t),name=name..' · ID frei',kind='live',startsAt=stamp,detail='Aktuelle Raid-ID aus WoW; maßgeblich gegenüber der Planung.'})
        end
    end end
    for _,d in ipairs(days) do table.sort(d.events,function(a,b)
        if (a.kind=='raid')~=(b.kind=='raid') then return a.kind=='raid' end
        if (a.startsAt or 0)~=(b.startsAt or 0) then return (a.startsAt or 0)<(b.startsAt or 0) end
        if (a.clock or '')~=(b.clock or '') then return (a.clock or '')<(b.clock or '') end
        return a.name<b.name
    end) end
    return days
end
function GL.CreateCalendarView(parent)
    local view=CreateFrame('Frame',nil,parent);view:SetPoint('TOPLEFT',24,-134);view:SetSize(890,556)
    local now=GetServerTime();local today=date('!*t',now+GL.CalendarBerlinOffset(now));local year,month=today.year,today.month
    local weekMode=false;local anchor=GL.CalendarCivilDays(year,month,today.day);local filters={raid=true,reset=true,live=true,worldbuff=true,dmf=true}
    local function label(owner,x,y,w,size)
        local l=owner:CreateFontString(nil,'OVERLAY','GameFontHighlight');l:SetFont(STANDARD_TEXT_FONT,size or 12);l:SetPoint('TOPLEFT',x,y);l:SetWidth(w);l:SetJustifyH('LEFT');l:SetWordWrap(false);return l
    end
    local function bg(owner,r,g,b)
        local t=owner:CreateTexture(nil,'BACKGROUND');t:SetAllPoints();t:SetColorTexture(r,g,b,1);return t
    end
    local function button(owner,title,x,y,w,fn)
        local b=CreateFrame('Button',nil,owner);b:SetPoint('TOPLEFT',x,y);b:SetSize(w,30);bg(b,.1,.19,.24);b.text=label(b,6,-7,w-12,13);b.text:SetText(title);b.text:SetJustifyH('CENTER');b:SetScript('OnClick',fn);return b
    end
    local heading=label(view,0,-2,450,24);heading:SetTextColor(.15,.95,.83)
    local context=label(view,0,-34,890,11);context:SetTextColor(.64,.75,.83)
    local cells={};local selected;local page=0
    local detail=CreateFrame('Frame',nil,view);detail:SetPoint('TOPLEFT',110,-64);detail:SetSize(670,420);bg(detail,.035,.07,.1);detail:EnableMouse(true);detail:Hide()
    local detailTitle=label(detail,18,-14,560,19);detailTitle:SetTextColor(1,.8,.25)
    local detailRows={}
    for i=1,5 do
        local f=CreateFrame('Frame',nil,detail);f:SetPoint('TOPLEFT',16,-52-(i-1)*61);f:SetSize(638,57);f.bg=bg(f,.08,.14,.18)
        f.title=label(f,10,-7,618,13);f.desc=label(f,10,-29,618,11);f.desc:SetTextColor(.64,.76,.84);detailRows[i]=f
    end
    local pageLabel=label(detail,230,-379,240,11);pageLabel:SetJustifyH('CENTER')
    local function color(e) if e.kind=='raid' then return 1,.8,.25 elseif e.kind=='worldbuff' then return .4,1,.7 elseif e.kind=='dmf' then return .79,.55,1 elseif e.kind=='live' then return .4,.95,.7 elseif e.name:find('Onyxia',1,true) then return 1,.55,.55 elseif e.name:find('ZG / AQ20',1,true) then return .25,.85,.85 else return .5,.72,1 end end
    local function renderDetail()
        if not selected then return end
        page=math.max(0,math.min(page,math.max(0,math.ceil(#selected.events/5)-1)))
        detailTitle:SetText(selected.date..' · '..#selected.events..' Termine')
        for i,f in ipairs(detailRows) do local e=selected.events[page*5+i];f:SetShown(e~=nil)
            if e then f.title:SetText((e.clock~='' and e.clock..'  ' or '')..e.name);f.title:SetTextColor(color(e));f.desc:SetText(e.detail or (e.kind=='dmf' and 'Dunkelmond-Planung · unabhängig vom Import' or 'EU-Resetplanung · aktuelle WoW-Raid-ID hat Vorrang')) end
        end
        pageLabel:SetText(#selected.events==0 and 'An diesem Tag sind keine Termine vorhanden.' or ('Seite '..(page+1)..' / '..math.ceil(#selected.events/5)))
    end
    button(detail,'Schließen',548,-10,106,function() detail:Hide() end)
    button(detail,'<',16,-368,50,function() page=page-1;renderDetail() end);button(detail,'>',604,-368,50,function() page=page+1;renderDetail() end)
    for i,name in ipairs({'MO','DI','MI','DO','FR','SA','SO'}) do local l=label(view,(i-1)*128+7,-98,110,12);l:SetText(name);l:SetTextColor(1,.8,.25) end
    for i=1,42 do
        local cell=CreateFrame('Button',nil,view);cell:SetPoint('TOPLEFT',((i-1)%7)*128,-118-math.floor((i-1)/7)*64);cell:SetSize(122,58);cell.bg=bg(cell,.06,.1,.14)
        cell.day=label(cell,7,-5,110,13);cell.lines={};cell.icons={};for j=1,20 do cell.lines[j]=label(cell,7,-23-(j-1)*18,94,10);local icon=cell:CreateTexture(nil,'OVERLAY');icon:SetPoint('TOPRIGHT',-3,-23-(j-1)*18);icon:SetSize(12,12);icon:SetTexture('Interface\\Icons\\INV_Misc_Bag_10');cell.icons[j]=icon end;cell.more=label(cell,7,-51,110,9);cell.more:SetTextColor(1,.8,.25)
        cell:SetScript('OnClick',function() selected=cell.data;page=0;renderDetail();detail:Show() end)
        cells[i]=cell
    end
    -- Raise detail above the grid without relying on template-specific scroll behavior.
    if detail.SetFrameLevel and view.GetFrameLevel then detail:SetFrameLevel(view:GetFrameLevel()+10) end
    local function shift(delta) if weekMode then anchor=anchor+delta*7;detail:Hide();view:Refresh();return end;month=month+delta;if month==0 then month=12;year=year-1 elseif month==13 then month=1;year=year+1 end;detail:Hide();view:Refresh() end
    button(view,'<',544,-2,44,function() shift(-1) end);button(view,'Heute',596,-2,92,function() local t=GetServerTime();local d=date('!*t',t+GL.CalendarBerlinOffset(t));year,month=d.year,d.month;anchor=GL.CalendarCivilDays(year,month,d.day);detail:Hide();view:Refresh() end);button(view,'>',696,-2,44,function() shift(1) end)
    button(view,'Charakter >',748,-2,142,function() GL.CyclePersonalProfile();detail:Hide();view:Refresh() end)
    local modeButton=button(view,'Woche',0,-60,100,function() weekMode=not weekMode;detail:Hide();view:Refresh() end)
    local filterButtons={}
    for i,opt in ipairs({{'raid','Deine Raids'},{'reset','Resetzeiten'},{'worldbuff','Worldbuffs'},{'dmf','Dunkelmond'}}) do
        local key,title=opt[1],opt[2]
        filterButtons[key]=button(view,title,112+(i-1)*194,-60,182,function() filters[key]=not filters[key];if key=='reset' then filters.live=filters.reset end;detail:Hide();view:Refresh() end)
    end
    local legend=label(view,0,-519,890,11);legend:SetText('|cffffcc40Anmeldung|r · |cffca8cffDunkelmond|r · |cff80b8ffResetplan|r · |cff66f2b3WoW-ID|r · Lila Sack: P1–P3 · Grün: P0 · Tag: alle Termine · Zeiten: Europe/Berlin')
    function view:Refresh()
        local t=GetServerTime();local todayKey=date('!%Y-%m-%d',t+GL.CalendarBerlinOffset(t));local p=GL.DisplayProfile()
        heading:SetText(months[month]..' '..year)
        context:SetText(p and ('Termine für '..p.player..' – '..p.realm..' · Import '..date('%d.%m.%Y %H:%M',p.exportedAt)..' · Allgemeiner Kalender immer verfügbar') or 'EU-Resets und Dunkelmond ohne Import · Persönlicher Import ergänzt Anmeldungen und Prio-Status')
        local start=anchor-((anchor+3)%7)
        if weekMode then heading:SetText(date('!%d.%m.',start*86400)..' – '..date('!%d.%m.%Y',(start+6)*86400)) end
        modeButton.text:SetText(weekMode and 'Monat' or 'Woche')
        for key,b in pairs(filterButtons) do b.text:SetTextColor(filters[key] and .3 or .6,filters[key] and 1 or .6,filters[key] and .7 or .6) end
        local days=GL.CalendarMonth(year,month,weekMode and start or nil,filters)
        for i,cell in ipairs(cells) do local d=days[i];cell:SetShown(d~=nil)
            if d then
                cell:ClearAllPoints();cell:SetPoint('TOPLEFT',((i-1)%7)*128,-118-(weekMode and 0 or math.floor((i-1)/7)*64));cell:SetHeight(weekMode and 386 or 58)
                cell.data=d;cell.day:SetText(d.day);cell.day:SetTextColor(d.current and .95 or .4,d.current and .95 or .5,d.current and .95 or .57)
                cell.bg:SetColorTexture(d.date==todayKey and .19 or .06,d.date==todayKey and .19 or .1,d.date==todayKey and .12 or .14,1)
                local count=weekMode and 19 or 2
                for j,l in ipairs(cell.lines) do local e=d.events[j];local visible=j<=count and e~=nil;l:SetShown(visible);cell.icons[j]:SetShown(visible and e.prio~=nil)
                    l:ClearAllPoints();l:SetPoint('TOPLEFT',7,-23-(j-1)*(weekMode and 18 or 12))
                    cell.icons[j]:ClearAllPoints();cell.icons[j]:SetPoint('TOPRIGHT',-3,-23-(j-1)*(weekMode and 18 or 12))
                    if visible then l:SetText((e.clock~='' and e.clock..' ' or '')..e.name:gsub('Dunkelmond%-Jahrmarkt','Dunkelmond'):gsub(': Reset',''):gsub(' / ','/'));l:SetTextColor(color(e));cell.icons[j]:SetVertexColor(e.prio=='p0' and .2 or .8,e.prio=='p0' and 1 or .35,e.prio=='p0' and .3 or 1) end
                end
                cell.more:ClearAllPoints();cell.more:SetPoint('BOTTOMLEFT',7,2);cell.more:SetText(#d.events>count and ('+'..(#d.events-count)..' weitere …') or '')
            end
        end
    end
    view.cells=cells;view.details=detail
    view:SetScript('OnHide',function() detail:Hide() end)
    return view
end
