local addonName,GH=...
_G.GuildHeal=GH
-- GuildHeal: einfache Heilerframes mit Klickzaubern. Alles Wichtige ist vorbelegt, Feinschliff über /gheal.
GH.MEDIA='Interface\\AddOns\\GuildHeal\\Media\\'
GH.VERSION=GetAddOnMetadata and GetAddOnMetadata(addonName,'Version') or (C_AddOns and C_AddOns.GetAddOnMetadata(addonName,'Version')) or ''

-- Klickbelegungen: Modifikator × Maustaste (1–5) bzw. Mausrad. Attributpräfix in WoW-Reihenfolge alt-ctrl-shift-.
GH.MODIFIERS={{mod='',label='keine'},{mod='alt-',label='Alt'},{mod='ctrl-',label='Strg'},{mod='shift-',label='Umschalt'},{mod='alt-ctrl-',label='Alt + Strg'},{mod='alt-shift-',label='Alt + Umschalt'},{mod='ctrl-shift-',label='Strg + Umschalt'},{mod='alt-ctrl-shift-',label='Alt + Strg + Umschalt'}}
GH.BUTTONS={{key='1',label='Linke Taste'},{key='2',label='Rechte Taste'},{key='3',label='Mittlere Taste'},{key='4',label='Taste 4'},{key='5',label='Taste 5'},{key='wheelup',label='Mausrad auf',wheel='MOUSEWHEELUP'},{key='wheeldown',label='Mausrad ab',wheel='MOUSEWHEELDOWN'}}
GH.BINDINGS={}
for _,m in ipairs(GH.MODIFIERS) do for _,b in ipairs(GH.BUTTONS) do GH.BINDINGS[#GH.BINDINGS+1]={key=b.key,mod=m.mod,label=(m.mod=='' and '' or m.label..' + ')..b.label,wheel=b.wheel} end end
function GH.ModifierKeyPrefix(mod) return (mod:gsub('alt%-','ALT-'):gsub('ctrl%-','CTRL-'):gsub('shift%-','SHIFT-')) end
function GH.BindingId(b) return b.mod..b.key end

-- Zauber-IDs (Rang 1) liefern den lokalisierten Namen; gezaubert wird per Name = höchster bekannter Rang.
local S={
 flashHeal=2061,greaterHeal=2060,heal=2054,lesserHeal=2050,renew=139,shield=17,dispelMagic=527,cureDisease=528,abolishDisease=552,prayerOfHealing=596,
 healingTouch=5185,regrowth=8936,rejuvenation=774,removeCurse=2782,abolishPoison=2893,curePoison=8946,rebirth=20484,innervate=29166,swiftmend=18562,
 holyLight=635,flashOfLight=19750,cleanse=4987,purify=1152,blessingOfProtection=1022,layOnHands=633,holyShock=20473,blessingOfFreedom=1044,
 healingWave=331,lesserHealingWave=8004,chainHeal=1064,shamanCurePoison=526,shamanCureDisease=2870,ancestralSpirit=2008,
 removeLesserCurse=475,
}
GH.SPELLS=S
-- Vorbelegung je Klasse. Jede Belegung ist eine Liste von Alternativen (erste bekannte gewinnt).
GH.DEFAULTS={
 -- Priester nach Vorlage (VuhDo-Belegung von Ariee): feste Ränge, wenn bekannt, sonst höchster Rang.
 PRIEST={['1']={{id=S.greaterHeal,rank=1},S.greaterHeal,S.heal,S.lesserHeal},['2']={{id=S.flashHeal,rank=5},S.flashHeal,S.lesserHeal},['3']={S.shield},['4']={S.dispelMagic},['5']={S.cureDisease,S.abolishDisease},
  ['shift-1']={{id=S.renew,rank=10},S.renew},['shift-2']={{id=S.flashHeal,rank=7},S.flashHeal},['shift-3']={S.prayerOfHealing}},
 DRUID={['1']={S.healingTouch},['2']={S.regrowth,S.healingTouch},['3']={S.rejuvenation},['shift-1']={S.swiftmend},['shift-2']={S.rebirth},['ctrl-1']={S.removeCurse},['ctrl-2']={S.abolishPoison,S.curePoison},['alt-1']={S.innervate},['alt-2']={'target'}},
 PALADIN={['1']={S.flashOfLight,S.holyLight},['2']={S.holyLight},['3']={S.holyShock},['shift-1']={S.blessingOfProtection},['shift-2']={S.layOnHands},['ctrl-1']={S.cleanse,S.purify},['ctrl-2']={S.blessingOfFreedom},['alt-1']={'target'},['alt-2']={'menu'}},
 SHAMAN={['1']={S.lesserHealingWave,S.healingWave},['2']={S.healingWave},['3']={S.chainHeal},['shift-2']={S.ancestralSpirit},['ctrl-1']={S.shamanCurePoison},['ctrl-2']={S.shamanCureDisease},['alt-1']={'target'},['alt-2']={'menu'}},
 MAGE={['1']={'target'},['2']={'menu'},['ctrl-1']={S.removeLesserCurse}},
}
GH.DEFAULT_OTHER={['1']={'target'},['2']={'menu'}}
-- Entfernbare Debuff-Typen je Klasse (für die farbige Umrandung und das Debuff-Symbol).
GH.DISPEL={PRIEST={Magic=true,Disease=true},PALADIN={Magic=true,Poison=true,Disease=true},DRUID={Curse=true,Poison=true},SHAMAN={Poison=true,Disease=true},MAGE={Curse=true}}
GH.DEBUFF_COLORS={Magic={.2,.6,1},Curse={.6,.2,1},Poison={.2,.8,.2},Disease={.9,.15,.15}}
function GH.DebuffColor(kind) local c=GH.DB().colors['debuff'..kind] or GH.DEBUFF_COLORS[kind];if not c then return nil end;return c[1],c[2],c[3] end

local defaults={
 width=84,height=38,horizontal=true,showMana=true,showDebuffs=true,showIncoming=true,locked=true,castOnDown=false,hideSolo=false,scale=1,
 fadeRange=.4,classColors=true,showPets=false,showAuras=true,showCooldowns=true,aggroBorder=true,nameClick=true,
 emergency=true,emergencyThreshold=50,emergencySound=true,
 overhealWarn=true,overhealThreshold=40,overhealSound=true,overhealSkipTanks=true,tanks='',
 unitLayout='vertical',healthText='missing',fontSize=11,barTexture='blizzard',bgAlpha=.92,spacing=3,
 colors={},showTooltips=false,debuffFill=true,debuffOnlyDispellable=false,debuffMax=1,debuffSize=14,debuffTimer=true,debuffStacks=true,debuffSound=false,
 auraSize=12,auraMax=4,auraOwnOnly=true,missingBuffWatch=true,missingBuffSound=false,castbar=true,castbarWidth=240,castbarHeight=22,cdSize=26,cdTrinkets=true,cdPosition=nil,cdReadyWarn=true,cdReadySound=true,
 targetOnHeal=false, showTargetFrame=false,showTankFrames=true,bossDebuffSound=true,healerManaWarn=true,healerManaThreshold=20,healerManaSound=true,healthGradient=false,perCharacter=false,sortMode='group',
 position=nil,classes={},
}
-- Auren (HoTs, Schilde, Schutz-Debuffs), die als kleine Symbole mit Restzeit auf dem Feld erscheinen.
GH.AURA_DEFAULTS={
 PRIEST={139,17,6788,6346,10060},DRUID={774,8936,2893,29166},PALADIN={1022,1044,25771,6940},SHAMAN={29203,16177},
}
function GH.DB()
 GuildHealDB=GuildHealDB or {}
 for k,v in pairs(defaults) do if GuildHealDB[k]==nil then GuildHealDB[k]=(type(v)=='table' and {} or v) end end
 -- Einmalig: „UI bearbeiten“ ist ab dieser Version standardmäßig aus (früher hieß das Frames sperren).
 if not GuildHealDB.editModeReset then GuildHealDB.editModeReset=true;GuildHealDB.locked=true end
 return GuildHealDB
end
function GH.PlayerClass() local _,class=UnitClass('player');return class end
function GH.SpellName(id)
 if type(id)~='number' then return nil end
 local name=GetSpellInfo(id);return name
end
-- Bekannt = im Zauberbuch vorhanden (GetSpellInfo per Name liefert nur bekannte Zauber).
function GH.Known(id)
 local name=GH.SpellName(id);if not name then return false end
 return GetSpellInfo(name)~=nil
end
function GH.SpellIcon(id) local _,_,icon=GetSpellInfo(id);return icon end
-- Aktuelle Belegung: gespeicherte Werte je Klasse, sonst die Vorgabe (erste bekannte Alternative).
function GH.Bindings()
 local class=GH.PlayerClass();local saved=GH.ClassStore();local out={}
 for _,b in ipairs(GH.BINDINGS) do
  local id=GH.BindingId(b);local value=saved[id]
  if value==nil then
   local options=(GH.DEFAULTS[class] or GH.DEFAULT_OTHER)[id]
   if options then for _,opt in ipairs(options) do
    if type(opt)=='table' then local full=GH.RankedSpell(opt.id,opt.rank);if full then value=full;break end
    elseif type(opt)=='string' or GH.Known(opt) then value=opt;break end
   end end
  end
  if value==false then value=nil end
  out[id]=value
 end
 return out
end
function GH.SetBinding(id,value)
 local store=GH.ClassStore();if value==nil then store[id]=false else store[id]=value end
 GH.ApplyBindings()
end
function GH.ResetBindings() local db=GH.DB();local key=GH.ClassStoreKey();local c=db.classes[key] or {};db.classes[key]={keys=c.keys,chains=c.chains,auras=c.auras};GH.ApplyBindings() end
-- Belegung je Klasse, wahlweise je Charakter (Profil 'KLASSE@Name-Realm', startet als Kopie der Klassenbelegung).
local function copyTable(src) if type(src)~='table' then return src end;local out={};for k,v in pairs(src) do out[k]=copyTable(v) end;return out end
function GH.ClassStore()
 local db=GH.DB();local class=GH.PlayerClass()
 if db.perCharacter then
  local key=class..'@'..(UnitName('player') or '?')..'-'..(GetRealmName() or '')
  if not db.classes[key] then db.classes[key]=copyTable(db.classes[class] or {}) end
  return db.classes[key]
 end
 db.classes[class]=db.classes[class] or {};return db.classes[class]
end
function GH.ClassStoreKey() local db=GH.DB();local class=GH.PlayerClass();return db.perCharacter and (class..'@'..(UnitName('player') or '?')..'-'..(GetRealmName() or '')) or class end
-- Mausüber-Tasten: Taste (z. B. F1, SHIFT-F2, BUTTON4) → Zauber oder Aktion, wirkt auf das Feld unter der Maus.
function GH.Keys() local c=GH.ClassStore();c.keys=c.keys or {};return c.keys end
function GH.SetKey(index,key,value)
 local keys=GH.Keys();for i=#keys+1,index do keys[i]=keys[i] or {} end
 if key~=nil then keys[index].key=key end;if key==nil then keys[index].value=value end
 GH.ApplyBindings()
end
function GH.RemoveKey(index) table.remove(GH.Keys(),index);GH.ApplyBindings() end
-- Zauberketten: vor dem Hauptzauber werden Schmuckstücke und Zusatzzauber (ohne GCD, z. B. Innerer Fokus) ausgelöst.
function GH.Chain(id) local c=GH.ClassStore();c.chains=c.chains or {};c.chains[id]=c.chains[id] or {spells={}};return c.chains[id] end
function GH.ChainActive(id) local c=GH.ClassStore();local chain=c.chains and c.chains[id];return chain and (chain.trinket13 or chain.trinket14 or (chain.spells and #chain.spells>0)) end
function GH.TrackedAuras()
 local c=GH.ClassStore();if c.auras then return c.auras end
 local list={};for _,id in ipairs(GH.AURA_DEFAULTS[GH.PlayerClass()] or {}) do local name=GH.SpellName(id);if name then list[#list+1]=name end end
 return list
end
-- Boss-Debuffs (Standard über Zauber-IDs aus MC, BWL, AQ40 und Naxxramas), groß und mit Ton hervorgehoben.
-- 40er-Raids: Molten Core, Blackwing Lair, AQ40, Naxxramas (Zauber-IDs, Namen kommen aus dem Client).
GH.BOSS_DEBUFF_IDS={
 -- Molten Core
 19702,19703,20604,19408,19716,19713,20475,19659,19695,13879,19776,
 -- Blackwing Lair
 23023,18173,24573,23331,23341,22539,23340,23155,23169,23153,23154,23170,23310,23174,23187,22687,22686,
 -- AQ40
 785,26580,25812,25646,720,25993,26180,26050,26053,26052,26102,26103,26476,26029,26143,25471,
 -- Naxxramas
 28785,28783,28796,28794,29484,28622,28776,29213,29212,29998,29204,29107,28679,28835,28832,28833,28834,28169,28374,28059,28084,28542,28547,28522,27808,28410,27819,
}
function GH.BossDebuffs()
 local c=GH.ClassStore();if c.bossDebuffs then return c.bossDebuffs end
 local list,seen={},{};for _,id in ipairs(GH.BOSS_DEBUFF_IDS) do local name=GH.SpellName(id);if name and not seen[name] then seen[name]=true;list[#list+1]=name end end
 return list
end
function GH.SetBossDebuffs(list) GH.ClassStore().bossDebuffs=list;if GH.RefreshAll then GH.RefreshAll() end end
function GH.ResetBossDebuffs() GH.ClassStore().bossDebuffs=nil;if GH.RefreshAll then GH.RefreshAll() end end
GH.HEALER_CLASSES={PRIEST=true,DRUID=true,PALADIN=true,SHAMAN=true}
-- Buffwatch: Buffs, die auf jedem Spieler vorhanden sein sollen (Standard: der eigene Klassenbuff).
GH.MISSING_BUFF_DEFAULTS={PRIEST={1243},MAGE={1459},DRUID={1126},PALADIN={},SHAMAN={},WARLOCK={},WARRIOR={},ROGUE={},HUNTER={}}
function GH.MissingBuffs()
 local c=GH.ClassStore();if c.missingBuffs then return c.missingBuffs end
 local list={};for _,id in ipairs(GH.MISSING_BUFF_DEFAULTS[GH.PlayerClass()] or {}) do local name=GH.SpellName(id);if name then list[#list+1]=name end end
 return list
end
function GH.SetMissingBuffs(list) GH.ClassStore().missingBuffs=list;if GH.RefreshAll then GH.RefreshAll() end end
function GH.ResetMissingBuffs() GH.ClassStore().missingBuffs=nil;if GH.RefreshAll then GH.RefreshAll() end end
-- Ignorierte Debuffs (werden nie angezeigt), z. B. Geschwächte Seele oder Verzicht.
function GH.IgnoredDebuffs() local c=GH.ClassStore();c.ignoredDebuffs=c.ignoredDebuffs or {};return c.ignoredDebuffs end
function GH.SetIgnoredDebuffs(list) GH.ClassStore().ignoredDebuffs=list;if GH.RefreshAll then GH.RefreshAll() end end
-- Buff-Gruppen: Gebet/Einzelbuff zählen gleich (Seelenstärke, Intelligenz, Mal der Wildnis, Schattenschutz).
GH.BUFF_FAMILIES={{1243,21562},{1459,23028},{1126,21850},{976,27683}}
function GH.BuffAliases(name)
 local out={[name]=true}
 for _,family in ipairs(GH.BUFF_FAMILIES) do local hit=false;local names={}
  for _,id in ipairs(family) do local n=GH.SpellName(id);if n then names[#names+1]=n;if n==name then hit=true end end end
  if hit then for _,n in ipairs(names) do out[n]=true end end
 end
 return out
end
function GH.SetTrackedAuras(list) GH.ClassStore().auras=list;if GH.RefreshAll then GH.RefreshAll() end end
function GH.ResetTrackedAuras() GH.ClassStore().auras=nil;if GH.RefreshAll then GH.RefreshAll() end end
-- Makrotext für Ketten: Schmuckstücke und Zusatzzauber zuerst, dann der Hauptzauber auf das Feld unter der Maus.
function GH.MacroText(value,chain,mouseover)
 local lines={}
 if chain then
  if chain.trinket13 then lines[#lines+1]='/use 13' end
  if chain.trinket14 then lines[#lines+1]='/use 14' end
  for _,name in ipairs(chain.spells or {}) do if GH.ValidSpell(name) then lines[#lines+1]='/cast '..name end end
 end
 local main=type(value)=='number' and GH.SpellName(value) or value
 if type(main)=='string' and GH.ValidSpell(main) then lines[#lines+1]='/cast [@mouseover,exists] '..main end
 return table.concat(lines,'\n')
end
-- Freitext wie bei VuhDo: Zaubername (mit Rang), Makroname, Gegenstand oder target/focus/assist/menu.
GH.ACTIONS={target='Ziel anvisieren',focus='Fokus setzen',assist='Assistieren',menu='Einheitenmenü',stopcasting='Zauber abbrechen'}
function GH.ParseInput(text)
 text=(text or ''):match('^%s*(.-)%s*$');if text=='' then return nil end
 local lower=text:lower();if lower=='dropdown' then lower='menu' end
 if GH.ACTIONS[lower] then return lower end
 if GH.ValidSpell(text) then return text end
 if GetMacroIndexByName and GetMacroIndexByName(text)>0 then return 'macro:'..text end
 if GetItemInfo and GetItemInfo(text) then return 'item:'..text end
 return text
end
function GH.BindingText(value)
 if GH.ACTIONS[value] then return GH.ACTIONS[value] end
 if type(value)=='string' and value:sub(1,6)=='macro:' then return 'Makro: '..value:sub(7) end
 if type(value)=='string' and value:sub(1,5)=='item:' then return 'Gegenstand: '..value:sub(6) end
 if type(value)=='number' then local name=GH.SpellName(value);if not name then return 'Unbekannter Zauber' end;if not GH.Known(value) then return name..' (nicht gelernt)' end;return name
 elseif type(value)=='string' and value~='' then local base,rank=value:match('^(.-)%((.-)%)$');if base then return base..' · '..rank..(GH.ValidSpell(value) and '' or ' (unbekannt)') end;return value..(GH.ValidSpell(value) and '' or ' (unbekannt)') end
 return '– leer –'
end
-- Rohtext für das Eingabefeld.
function GH.BindingInput(value)
 if type(value)=='number' then return GH.SpellName(value) or '' end
 if type(value)=='string' then return (value:gsub('^macro:',''):gsub('^item:','')) end
 return ''
end
-- Alle Zauber des Zauberbuchs mit Rängen. 'Name' = höchster Rang, 'Name(Rang 3)' = fester Rang.
-- Das Zauberbuch zeigt ohne die Option „Alle Zauberränge anzeigen“ nur den höchsten Rang. Die Ränge kommen deshalb
-- aus den bekannten Zauber-IDs (IsSpellKnown über alle Classic-IDs, einmal je Login bzw. SPELLS_CHANGED).
-- Der Rangtext (GetSpellSubtext) lädt der Client erst auf Anfrage; bis dahin wird nach ID-Reihenfolge als Rang 1..n gezählt.
local bookCache,bookTime,rankScan
local SCAN_MAX_ID=31000
local RANK_WORD={deDE='Rang',enUS='Rank',enGB='Rank',frFR='Rang',esES='Rango',esMX='Rango',ptBR='Nível',itIT='Grado',ruRU='Уровень'}
local function rankFormat(prefix,suffix)
 if prefix==nil then local w=RANK_WORD[GetLocale()] or 'Rank';prefix,suffix=w..' ','' end
 return function(n) return prefix..n..suffix end
end
local function subtext(id) local t=GetSpellSubtext and id and GetSpellSubtext(id);return t and t~='' and t or nil end
-- name -> Liste bekannter IDs (aufsteigend). Ein Eintrag = kein Rang oder nur ein Rang bekannt.
local function knownRanks()
 if rankScan then return rankScan end
 local byName={};local known=IsSpellKnown or IsPlayerSpell
 if known and GetSpellInfo then
  for id=1,SCAN_MAX_ID do
   if known(id) then local name=GetSpellInfo(id);if name then local l=byName[name];if not l then l={};byName[name]=l end;l[#l+1]=id end end
  end
 end
 rankScan=byName;return byName
end
function GH.SpellbookSpells()
 if bookCache and bookTime==GetTime() then return bookCache end
 local list,byName={},{}
 if not GetSpellBookItemName or not GetSpellTabInfo then return list end
 local book=BOOKTYPE_SPELL or 'spell'
 local tabs=GetNumSpellTabs and GetNumSpellTabs() or 0
 local entries,prefix,suffix={},nil,nil
 for tab=1,tabs do
  local _,_,offset,count=GetSpellTabInfo(tab)
  for i=offset+1,offset+count do
   local name,rank=GetSpellBookItemName(i,book)
   local kind,id=GetSpellBookItemInfo(i,book)
   if name and kind=='SPELL' and not IsPassiveSpell(i,book) then
    rank=(rank and rank~='' and rank) or subtext(id)
    if rank and not prefix then local a,b=rank:match('^(.-)%d+(.-)$');if a then prefix,suffix=a,b end end
    entries[#entries+1]={name=name,rank=rank,id=id}
   end
  end
 end
 local ranks=knownRanks()
 for _,e in ipairs(entries) do
  if not byName[e.name] then
   local _,_,icon=GetSpellInfo(e.name);local s={name=e.name,icon=icon,id=e.id,ranks={}};byName[e.name]=s;list[#list+1]=s
   local ids=ranks[e.name]
   if ids and #ids>1 then
    for _,id in ipairs(ids) do local t=subtext(id);if not t then ids.pending=true end;s.ranks[#s.ranks+1]={id=id,rank=t} end
   elseif e.rank then s.ranks[1]={id=e.id,rank=e.rank} end
  elseif e.rank then
   -- Zauberbuch mit allen Rängen: gleichen Namen ergänzen, falls der Scan nichts geliefert hat.
   local s=byName[e.name];local found=false
   for _,r in ipairs(s.ranks) do if r.id==e.id then r.rank=r.rank or e.rank;found=true end end
   if not found then s.ranks[#s.ranks+1]={id=e.id,rank=e.rank} end
  end
 end
 local fmt=rankFormat(prefix,suffix)
 for _,s in ipairs(list) do
  local complete=true
  for _,r in ipairs(s.ranks) do if not (r.rank and r.rank:match('%d+')) then complete=false end end
  if complete then table.sort(s.ranks,function(a,b) return tonumber(a.rank:match('%d+'))<tonumber(b.rank:match('%d+')) end)
  else
   table.sort(s.ranks,function(a,b) return a.id<b.id end)
   for i,r in ipairs(s.ranks) do if not r.rank then r.rank=fmt(i);if C_Spell and C_Spell.RequestLoadSpellData then pcall(C_Spell.RequestLoadSpellData,r.id) end end end
  end
  for _,r in ipairs(s.ranks) do r.full=s.name..'('..r.rank..')' end
  if #s.ranks>0 then s.id=s.ranks[#s.ranks].id end
 end
 table.sort(list,function(a,b) return a.name<b.name end)
 bookCache,bookTime=list,GetTime();return list
end
-- full=true nach SPELLS_CHANGED (neue Zauber), sonst nur Rangtexte nachgeladen.
function GH.InvalidateSpellbook(full) bookCache=nil;if full then rankScan=nil end end
-- 'Name(Rang N)' aus dem Zauberbuch, falls dieser Rang bekannt ist.
function GH.RankedSpell(id,rank)
 local name=GH.SpellName(id);if not name then return nil end
 for _,s in ipairs(GH.SpellbookSpells()) do
  if s.name==name then for _,r in ipairs(s.ranks) do if tonumber(r.rank:match('%d+'))==rank then return r.full end end end
 end
 return nil
end
function GH.BaseName(value) return (tostring(value or ''):gsub('%(.*%)$','')) end
-- Gültig, wenn der Zauber (ggf. mit Rang) im Zauberbuch steht.
function GH.ValidSpell(value)
 if type(value)~='string' or value=='' then return false end
 for _,s in ipairs(GH.SpellbookSpells()) do
  if s.name==value then return true end
  for _,r in ipairs(s.ranks) do if r.full==value then return true end end
 end
 return false
end
function GH.SpellIconOf(value)
 if type(value)=='number' then return GH.SpellIcon(value) end
 local base=GH.BaseName(value);for _,s in ipairs(GH.SpellbookSpells()) do if s.name==base then return s.icon end end
end
-- Tank-Erkennung: Haupttank/Hauptassistent im Schlachtzug oder Namen aus der Einstellung (kommagetrennt).
function GH.IsTank(unit)
 local name=UnitName(unit);if not name then return false end
 local list=GH.DB().tanks or ''
 for entry in list:gmatch('[^,;]+') do entry=entry:match('^%s*(.-)%s*$');if entry~='' and entry:lower()==name:lower() then return true end end
 if IsInRaid() and GetRaidRosterInfo then
  for i=1,GetNumGroupMembers() do local n,_,_,_,_,_,_,_,_,role=GetRaidRosterInfo(i);if n and (n==name or n:match('^(.-)%-')==name) and (role=='MAINTANK' or role=='MAINASSIST') then return true end end
 end
 if UnitGroupRolesAssigned then local role=UnitGroupRolesAssigned(unit);if role=='TANK' then return true end end
 return false
end
GH.BAR_TEXTURES={blizzard={label='Standard',path='Interface\\TargetingFrame\\UI-StatusBar'},flat={label='Glatt',path='Interface\\Buttons\\WHITE8x8'},raid={label='Raidframe',path='Interface\\RaidFrame\\Raid-Bar-Hp-Fill'},minimal={label='Fein',path='Interface\\TargetingFrame\\UI-TargetingFrame-BarFill'}}
-- Farbakzente: Hintergrund, Lebensbalken (ohne Klassenfarbe), Text, Name, Rahmen (Alpha 0 = kein Rahmen).
GH.COLOR_DEFAULTS={bg={.05,.07,.1},bar={.2,.75,.3},text={1,.85,.4},name={1,1,1},border={.35,.5,.6,0},incoming={.4,.9,.5},castbar={.16,.6,.55}}
GH.COLOR_LABELS={{'bg','Hintergrund'},{'bar','Lebensbalken ohne Klassenfarbe'},{'text','Lebenstext'},{'name','Name bei Klassenfarbe'},{'border','Rahmen um das Feld'},{'incoming','Eingehende Heilung'},{'castbar','Zauberbalken'},{'debuffMagic','Debuff: Magie'},{'debuffCurse','Debuff: Fluch'},{'debuffPoison','Debuff: Gift'},{'debuffDisease','Debuff: Krankheit'}}
for _,k in ipairs({'Magic','Curse','Poison','Disease'}) do GH.COLOR_DEFAULTS['debuff'..k]=GH.DEBUFF_COLORS[k] end
function GH.Color(key) local c=GH.DB().colors[key] or GH.COLOR_DEFAULTS[key];return c[1],c[2],c[3],c[4] end
function GH.SetColor(key,r,g,b,a) GH.DB().colors[key]={r,g,b,a};if GH.ApplyLayout then GH.ApplyLayout() end end
function GH.ResetColors() GH.DB().colors={};if GH.ApplyLayout then GH.ApplyLayout() end end
function GH.BarTexture() local e=GH.BAR_TEXTURES[GH.DB().barTexture or 'blizzard'] or GH.BAR_TEXTURES.blizzard;return e.path end
function GH.Print(msg) print('|cff2ad1bcGuildHeal:|r '..tostring(msg)) end
function GH.ClassColor(unit)
 local _,class=UnitClass(unit);local c=class and (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[class]
 if c then return c.r,c.g,c.b end;return .6,.6,.6
end
function GH.PowerColor(unit)
 local kind=UnitPowerType(unit);local c=PowerBarColor[kind] or PowerBarColor['MANA'];return c.r,c.g,c.b
end
function GH.Short(n)
 if n>=10000 then return string.format('%.0fk',n/1000) elseif n>=1000 then return string.format('%.1fk',n/1000) end;return tostring(n)
end

SLASH_GUILDHEAL1='/gheal';SLASH_GUILDHEAL2='/guildheal'
SlashCmdList.GUILDHEAL=function(msg)
 msg=(msg or ''):lower():match('^%s*(.-)%s*$')
 if msg=='lock' or msg=='sperren' then GH.DB().locked=true;GH.ApplyLayout();if GH.ConfigRefresh then GH.ConfigRefresh() end;GH.Print('UI bearbeiten aus.')
 elseif msg=='unlock' or msg=='entsperren' or msg=='edit' then GH.DB().locked=false;GH.ApplyLayout();if GH.ConfigRefresh then GH.ConfigRefresh() end;GH.Print('UI bearbeiten an: Griffe ziehen, danach /gheal lock oder den Knopf im Fenster.')
 elseif msg=='reset' then GH.DB().position=nil;GH.ApplyLayout();GH.Print('Position zurückgesetzt.')
 elseif msg=='hilfe' or msg=='help' then
  for _,line in ipairs({'|cffffcc40GuildHeal Befehle:|r','/gheal – Einstellungen (Klickzauber, Tasten, Ketten, Anzeige, Warnungen)','/gheal unlock | lock – UI bearbeiten an / aus (Griffe zum Verschieben)','/gheal reset – Position zurücksetzen'}) do print(line) end
 else GH.ToggleConfig() end
end
